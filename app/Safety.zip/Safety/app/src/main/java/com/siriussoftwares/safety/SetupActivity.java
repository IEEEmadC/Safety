package com.siriussoftwares.safety;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Button;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;
import edu.cmu.pocketsphinx.SpeechRecognizerSetup;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Locale;
import java.util.Set;


import static android.widget.Toast.makeText;
import static edu.cmu.pocketsphinx.SpeechRecognizerSetup.defaultSetup;

public class SetupActivity extends AppCompatActivity implements RecognitionListener  {
    String FileName="data",country,save_message="";
    Button save,reset,save1,reset1,save2,reset2,save3,reset3,save4,reset4,save5,reset5,remind_setup_btn,reset_setup_btn,search_police,search_fire,search_ambulance;
    EditText ed,ed1,ed2,ed3,ed5_11,ed5_12,ed5_13,ed5_14,ed5_21,ed5_22,ed5_23,ed5_24,ed5_25,ed7,ed8,ed9,ed10,ed11,ed12,ed13,ed14,ed15,ed16,ed17,ed18,ed19,ed20,ed21,ed22,ed23,ed24;
    private static final int RESULT_PICK_CONTACT1= 1;
    private static final int RESULT_PICK_CONTACT2= 2;
    private static final int RESULT_PICK_CONTACT3= 3;
    public int i=1,flag1=0,reset_button_flag;
    Switch switch2;
    String[] country_array;
    String gender="";
    ProgressBar simpleProgressBar0,simpleProgressBar,simpleProgressBar1,simpleProgressBar2,simpleProgressBar3,simpleProgressBar4;
    ImageButton mic1,mic2,mic3,mic4,mic5,mic6,play1,play2,play3,play4,play5,play6,personal_info_info,medical_info_info,emergency_services_info,emergency_contacts_info,password_deactivation_info,voice_activation_info,disaster_alert_region_info;
    TextView test_tv1,test_tv2,test_tv3,test_tv4,test_tv5,test_tv6,seekBar1_tv,seekBar2_tv,seekBar3_tv,seekBar4_tv,seekBar5_tv,seekBar6_tv;
    public Boolean switch_state2;
    SeekBar seekBar1,seekBar2,seekBar3,seekBar4,seekBar5,seekBar6;
    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 1;
    private static final String KWS_SEARCH = "wakeup";
    private SpeechRecognizer recognizer;
    Calendar myCalendar;
    TextToSpeech t1;
    MediaPlayer mp;
    String threshold1,threshold2,threshold3,threshold4,threshold5,threshold6,progress1,progress2,progress3,progress4,progress5,progress6;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECORD_AUDIO);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_RECORD_AUDIO);
        }

        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                    t1.setSpeechRate((float) 0.9);
                }
            }
        });


        save = findViewById(R.id.saveButton);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=0;
                saveFile();
            }
        });

        reset = findViewById(R.id.resetButton);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=1;
                resetFile();
                saveFile();
            }
        });
        save1 =  findViewById(R.id.saveButton1);
        save1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=0;
                saveFile1();
            }
        });

        reset1 = findViewById(R.id.resetButton1);
        reset1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=1;
                resetFile1();
                saveFile1();
            }
        });

        save2 = findViewById(R.id.saveButton2);
        save2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=0;
                saveFile2();
            }
        });

        save4 = findViewById(R.id.saveButton4);
        save4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=0;
                saveFile3();
            }
        });

        reset2 = findViewById(R.id.resetButton2);
        reset2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=1;
                resetFile2();
                saveFile2();
            }
        });
        reset3 = findViewById(R.id.resetButton3);
        reset3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=1;
                resetFile3();
                saveFile3();
            }
        });
        reset4 = findViewById(R.id.resetButton4);
        reset4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset_button_flag=1;
                resetFile4();
                saveFile3();
            }
        });



        ed =  findViewById(R.id.editText);
        ed1 =  findViewById(R.id.editText1);
        ed2 =  findViewById(R.id.editText2);
        ed3 = findViewById(R.id.editText3);
        ed5_11 =  findViewById(R.id.editText5_11);
        ed5_12 =  findViewById(R.id.editText5_12);
        ed5_13 =  findViewById(R.id.editText5_13);
        ed5_14 =  findViewById(R.id.editText5_14);
        ed5_21 =  findViewById(R.id.editText5_21);
        ed5_22 =  findViewById(R.id.editText5_22);
        ed5_23 =  findViewById(R.id.editText5_23);
        ed5_24 =  findViewById(R.id.editText5_24);
        ed5_25 =  findViewById(R.id.editText5_25);
        ed7 =  findViewById(R.id.editText7);
        ed8 =  findViewById(R.id.editText8);
        ed9 = findViewById(R.id.editText9);
        ed10 =  findViewById(R.id.editText10);
        ed11 =  findViewById(R.id.editText11);
        ed12 = findViewById(R.id.editText12);
        ed13 = findViewById(R.id.editText13);
        ed14 =  findViewById(R.id.editText14);
        ed15 = findViewById(R.id.editText15);
        ed16 =  findViewById(R.id.editText16);
        ed17 =  findViewById(R.id.editText17);
        ed18 =  findViewById(R.id.editText18);
        ed19 = findViewById(R.id.editText19);
        ed20 = findViewById(R.id.editText20);
        ed21 = findViewById(R.id.editText21);
        ed22 = findViewById(R.id.editText22);
        ed23 = findViewById(R.id.editText23);
        ed24 = findViewById(R.id.editText24);
        switch2=findViewById(R.id.switch2);
        mic1=findViewById(R.id.mic1);
        mic2=findViewById(R.id.mic2);
        mic3=findViewById(R.id.mic3);
        mic4=findViewById(R.id.mic4);
        mic5=findViewById(R.id.mic5);
        mic6=findViewById(R.id.mic6);
        test_tv1=findViewById(R.id.test_tv1);
        test_tv2=findViewById(R.id.test_tv2);
        test_tv3=findViewById(R.id.test_tv3);
        test_tv4=findViewById(R.id.test_tv4);
        test_tv5=findViewById(R.id.test_tv5);
        test_tv6=findViewById(R.id.test_tv6);
        simpleProgressBar0 = findViewById(R.id.simpleProgressBar0);
        simpleProgressBar = findViewById(R.id.simpleProgressBar);
        simpleProgressBar1 = findViewById(R.id.simpleProgressBar1);
        simpleProgressBar2 = findViewById(R.id.simpleProgressBar2);
        simpleProgressBar3 = findViewById(R.id.simpleProgressBar3);
        simpleProgressBar4 = findViewById(R.id.simpleProgressBar4);
        personal_info_info=findViewById(R.id.personal_info_info);
        medical_info_info=findViewById(R.id.medical_info_info);
        emergency_services_info=findViewById(R.id.emergency_services_info);
        emergency_contacts_info=findViewById(R.id.emergency_contacts_info);
        password_deactivation_info=findViewById(R.id.password_deactivation_info);
        voice_activation_info=findViewById(R.id.voice_activation_info);
        disaster_alert_region_info=findViewById(R.id.disaster_alert_region_info);
        seekBar1=findViewById(R.id.seekbar1);
        seekBar1_tv=findViewById(R.id.seekbar1_tv);
        seekBar2=findViewById(R.id.seekbar2);
        seekBar2_tv=findViewById(R.id.seekbar2_tv);
        seekBar3=findViewById(R.id.seekbar3);
        seekBar3_tv=findViewById(R.id.seekbar3_tv);
        seekBar4=findViewById(R.id.seekbar4);
        seekBar4_tv=findViewById(R.id.seekbar4_tv);
        seekBar5=findViewById(R.id.seekbar5);
        seekBar5_tv=findViewById(R.id.seekbar5_tv);
        seekBar6=findViewById(R.id.seekbar6);
        seekBar6_tv=findViewById(R.id.seekbar6_tv);
        play1=findViewById(R.id.play1);
        play2=findViewById(R.id.play2);
        play3=findViewById(R.id.play3);
        play4=findViewById(R.id.play4);
        play5=findViewById(R.id.play5);
        play6=findViewById(R.id.play6);

        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt("setup_activity_running",1);
        editor.apply();

        threshold1=sharedPreferences.getString("threshold1","1e-40");
        threshold2=sharedPreferences.getString("threshold2","1e-1");
        threshold3=sharedPreferences.getString("threshold3","1e-15");
        threshold4=sharedPreferences.getString("threshold4","1e-40");
        threshold5=sharedPreferences.getString("threshold5","1e-15");
        threshold6=sharedPreferences.getString("threshold6","1e-15");

        progress1=sharedPreferences.getString("progress1","25");
        progress2=sharedPreferences.getString("progress2","10");
        progress3=sharedPreferences.getString("progress3","50");
        progress4=sharedPreferences.getString("progress4","25");
        progress5=sharedPreferences.getString("progress5","50");
        progress6=sharedPreferences.getString("progress6","50");

        Boolean result = isMyServiceRunning();
        if (result) {
            Intent serviceIntent = new Intent(SetupActivity.this, VoiceService.class);
            stopService(serviceIntent);
        }


        disaster_alert_region_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.disaster_alert_regions);
                String msg=getString(R.string.disaster_alerty_regions_desc);
                info_dialog(title,msg);
            }
        });
        voice_activation_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.voice_command_activation);
                String msg=getString(R.string.voice_command_activation_desc);
                info_dialog(title,msg);
            }
        });
        password_deactivation_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.deactivation_pin);
                String msg=getString(R.string.deactivation_pin_desc);
                info_dialog(title,msg);
            }
        });
        emergency_contacts_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.personal_emergency_contacts);
                String msg=getString(R.string.personal_emergency_contacts_desc);
                info_dialog(title,msg);
            }
        });
        emergency_services_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.public_emergency_services);
                String msg=getString(R.string.public_emergency_services_desc);
                info_dialog(title,msg);
            }
        });
        medical_info_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.medical_information);
                String msg=getString(R.string.medical_information_desc);
                info_dialog(title,msg);
            }
        });
        personal_info_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title=getString(R.string.personal_information);
                String msg=getString(R.string.personal_information_desc);
                info_dialog(title,msg);
            }
        });

        final SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        flag1=sharedPref.getInt("flag1",0);

        myCalendar = Calendar.getInstance();
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        ed2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(SetupActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle(getString(R.string.incorrect_pin));
        builder1.setIcon(R.drawable.ic_lock_black_24dp);
        builder1.setMessage(R.string.please_enter_pin);
        builder1.setCancelable(true);
        builder1.setPositiveButton(
                R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert_dialog1 = builder1.create();

        save3=findViewById(R.id.saveButton3);
        save3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String new_password=ed20.getText().toString();
                String password=ed21.getText().toString();
                SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
                String saved_password=sharedPref.getString("password","");
                if (flag1==0 && !new_password.equals(password)){
                    alert_dialog1.show();
                }
                else if (flag1==1 && !new_password.equals(saved_password)){
                    alert_dialog1.show();
                }
                else if (new_password.equals(password) || new_password.equals(saved_password)){
                    makeText(getApplicationContext(), R.string.pin_saved, Toast.LENGTH_SHORT).show();
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("password", password);
                    editor.putInt("flag1",1);
                    editor.apply();
                    ed20.setHint(R.string.enter_current_pin);
                    ed21.setHint(R.string.enter_new_pin);
                    resetFile3();
                }
            }
        });


        search_ambulance = findViewById(R.id.search_ambulance);
        search_ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url;
                String country=sharedPref.getString("address6", "");
                if(!country.equals("")){
                    url= "https://www.google.co.in/search?q=emergency+number+of+ambulance+in+"+country;
                }
                else{
                    url="https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers";
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
                ed9.requestFocus();
                }
        });
        search_police = findViewById(R.id.search_police);
        search_police.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url;
                String country=sharedPref.getString("address6", "");
                if(!country.equals("")){
                    url= "https://www.google.co.in/search?q=emergency+number+of+police+in+"+country;
                }
                else{
                    url="https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers";
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
                ed8.requestFocus();
            }
        });
        search_fire = findViewById(R.id.search_fire);
        search_fire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url;
                String country=sharedPref.getString("address6", "");
                if(!country.equals("")){
                    url= "https://www.google.co.in/search?q=emergency+number+of+fire+and+rescue+services+in+"+country;
                }
                else{
                    url="https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers";
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
                ed10.requestFocus();
            }
        });

        country_array = getResources().getStringArray(R.array.countries_array);
        final AlertDialog.Builder builder = new AlertDialog.Builder(SetupActivity.this);
        builder.setTitle(R.string.select_region);
        ed22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setItems(country_array, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ed22.setText(country_array[which]);
                        SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("region1",country_array[which]);
                        editor.apply();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        ed23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setItems(country_array, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ed23.setText(country_array[which]);
                        SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("region2",country_array[which]);
                        editor.apply();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        ed24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setItems(country_array, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ed24.setText(country_array[which]);
                        SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("region3",country_array[which]);
                        editor.apply();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        save5=findViewById(R.id.saveButton5);
        save5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ed22.getText().toString().equals(""))info_dialog(getString(R.string.incomplete_information),getString(R.string.select_atleast_one));
                if (!ed22.getText().toString().equals(""))FirebaseMessaging.getInstance().subscribeToTopic(ed22.getText().toString());
                if (!ed23.getText().toString().equals(""))FirebaseMessaging.getInstance().subscribeToTopic(ed23.getText().toString());
                if (!ed24.getText().toString().equals(""))FirebaseMessaging.getInstance().subscribeToTopic(ed24.getText().toString());
            }
        });

        reset5=findViewById(R.id.resetButton5);
        reset5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetFile5();
                SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("region1","");
            }
        });


        switch2.setOnClickListener(new Switch.OnClickListener() {
            public void onClick(View v) {
                SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putBoolean("switch2", switch2.isChecked());
                editor.apply();
                switch_state2=sharedPref.getBoolean("switch2", true);
            }
        });
        if (i == 1) {
            readFile();
            readFile1();
            readFile2();
            readFile3();
            readFile4();
            switch2.setChecked(sharedPref.getBoolean("switch2", true));
        }
        if (flag1==1) {
            ed20.setHint(getString(R.string.enter_current_pin));
            ed21.setHint(getString(R.string.enter_new_pin));
        }
        switch_state2=sharedPref.getBoolean("switch2", true);
        if(switch_state2) {
        }
        AlertDialog.Builder builder3 = new AlertDialog.Builder(this);
        builder3.setTitle(R.string.enable_voice);
        builder3.setIcon(R.drawable.ic_mic_black_24dp);
        builder3.setMessage(R.string.turn_on_enable_voice);
        builder3.setCancelable(true);
        builder3.setPositiveButton(
                getString(R.string.ok),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert_dialog3 = builder3.create();
        mic1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if (!switch_state2)
                    alert_dialog3.show();
                else {
                   new SetupTask(SetupActivity.this).execute();
                   test_tv1.setText(R.string.listening);
                   simpleProgressBar4.setVisibility(View.VISIBLE);
                   mic1.setVisibility(View.GONE);
               }
                        }
        });
        mic2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!switch_state2)
                    alert_dialog3.show();
                else {
                    new SetupTask(SetupActivity.this).execute();
                    test_tv2.setText(R.string.listening);
                    simpleProgressBar3.setVisibility(View.VISIBLE);
                    mic2.setVisibility(View.GONE);
                }
            }
        });
        mic3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!switch_state2)
                    alert_dialog3.show();
                else {
                    new SetupTask(SetupActivity.this).execute();
                    test_tv3.setText(R.string.listening);
                    simpleProgressBar2.setVisibility(View.VISIBLE);
                    mic3.setVisibility(View.GONE);
                }
            }
        });
        mic4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!switch_state2)
                    alert_dialog3.show();
                else {
                    new SetupTask(SetupActivity.this).execute();
                    test_tv4.setText(R.string.listening);
                    simpleProgressBar1.setVisibility(View.VISIBLE);
                    mic4.setVisibility(View.GONE);
                }
            }
        });
        mic5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!switch_state2)
                    alert_dialog3.show();
                else {
                    new SetupTask(SetupActivity.this).execute();
                    test_tv5.setText(R.string.listening);
                    simpleProgressBar.setVisibility(View.VISIBLE);
                    mic5.setVisibility(View.GONE);
                }
            }
        });
        mic6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!switch_state2)
                    alert_dialog3.show();
                else {
                    new SetupTask(SetupActivity.this).execute();
                    test_tv6.setText(R.string.listening);
                    simpleProgressBar0.setVisibility(View.VISIBLE);
                    mic6.setVisibility(View.GONE);
                }
            }
        });

        play1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.equalsIgnoreCase("female")) {
                    t1.speak("Accident Accident", TextToSpeech.QUEUE_FLUSH, null);
                }
                else if (gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.accident_male);
                    mp.start();
                }
                else if(!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.accident_male);
                    mp.start();
                }
            }});

        play2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.equalsIgnoreCase("female")) {
                    t1.speak("Fire Fire", TextToSpeech.QUEUE_FLUSH, null);
                }
                else if (gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.fire_male);
                    mp.start();
                }
                else if(!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male")){
                    t1.speak("Fire Fire", TextToSpeech.QUEUE_FLUSH, null);
                }
            }});

        play3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.equalsIgnoreCase("female")) {
                    t1.speak("Medic Medic", TextToSpeech.QUEUE_FLUSH, null);
                }
                else if (gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.medic_male);
                    mp.start();
                }
                else if(!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.medic_male);
                    mp.start();
                }
            }});

        play4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.equalsIgnoreCase("female")) {
                    t1.speak("Disaster Disaster", TextToSpeech.QUEUE_FLUSH, null);
                }
                else if (gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.disaster_male);
                    mp.start();
                }
                else if(!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male")){
                    t1.speak("Disaster Disaster", TextToSpeech.QUEUE_FLUSH, null);
                }
            }});

        play5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.equalsIgnoreCase("female")) {
                    t1.speak("Alert Alert", TextToSpeech.QUEUE_FLUSH, null);
                }
                else if (gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.alert_male);
                    mp.start();
                }
                else if(!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.alert_male);
                    mp.start();
                }
            }});

        play6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.equalsIgnoreCase("female")) {
                    t1.speak("Crime Crime", TextToSpeech.QUEUE_FLUSH, null);
                }
                else if (gender.equalsIgnoreCase("male")){
                    mp = MediaPlayer.create(SetupActivity.this, R.raw.crime_male);
                    mp.start();
                }
                else if(!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male")){
                    t1.speak("Crime Crime", TextToSpeech.QUEUE_FLUSH, null);
                }
            }});


        seekBar1_tv.setText(progress1);
        seekBar1.setProgress(Integer.parseInt(progress1));
        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean paramBoolean) {
                progress1=String.valueOf(progress);
                threshold1=String.valueOf(Math.pow(10,-50)*Math.pow(10,(2*progress)/5));
                seekBar1_tv.setText(progress1);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold1",threshold1);
                editor.putString("progress1",progress1);
                editor.apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {
                new SetupTask(SetupActivity.this).cancel(true); }
            public void onStopTrackingTouch(SeekBar bar) {
                seekBar1_tv.setText(String.valueOf(progress1));
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold1",threshold1);
                editor.putString("progress1",progress1);
                editor.apply();
                new SetupTask(SetupActivity.this).execute();
            }
        });

        seekBar2_tv.setText(progress2);
        seekBar2.setProgress(Integer.parseInt(progress2));
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean paramBoolean) {
                progress2=String.valueOf(progress);
                threshold2=String.valueOf(Math.pow(10,-50)*Math.pow(10,progress/5));
                seekBar2_tv.setText(progress2);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold2",threshold2);
                editor.putString("progress2",progress2);
                editor.apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {
                new SetupTask(SetupActivity.this).cancel(true);
            }
            public void onStopTrackingTouch(SeekBar bar) {
                seekBar2_tv.setText(progress2);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("threshold2", threshold2);
                editor.putString("progress2", progress2);
                editor.apply();
                new SetupTask(SetupActivity.this).execute();
            }
        });

        seekBar3_tv.setText(progress3);
        seekBar3.setProgress(Integer.parseInt(progress3));
        seekBar3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar, int progress, boolean paramBoolean) {
                progress3=String.valueOf(progress);
                threshold3=String.valueOf(Math.pow(10,-50)*Math.pow(10,progress/3.33));
                seekBar3_tv.setText(progress3);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold3",threshold3);
                editor.putString("progress3",progress3);
                editor.apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {
                new SetupTask(SetupActivity.this).cancel(true);
            }
            public void onStopTrackingTouch(SeekBar bar) {
                seekBar3_tv.setText(progress3);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold3",threshold3);
                editor.putString("progress3",progress3);
                editor.apply();
                new SetupTask(SetupActivity.this).execute();
            }
        });

        seekBar4_tv.setText(progress4);
        seekBar4.setProgress(Integer.parseInt(progress4));
        seekBar4.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean paramBoolean) {
                progress4=String.valueOf(progress);
                threshold4=String.valueOf(Math.pow(10,-50)*Math.pow(10,(2*progress)/5));
                seekBar4_tv.setText(progress4);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold4",threshold4);
                editor.putString("progress4",progress4);
                editor.apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {
                new SetupTask(SetupActivity.this).cancel(true);
            }
            public void onStopTrackingTouch(SeekBar bar) {
                seekBar4_tv.setText(progress4);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold4",threshold4);
                editor.putString("progress4",progress4);
                editor.apply();
                new SetupTask(SetupActivity.this).execute();
            }
        });

        seekBar5_tv.setText(progress5);
        seekBar5.setProgress(Integer.parseInt(progress5));
        seekBar5.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean paramBoolean) {
                progress5=String.valueOf(progress);
                threshold5=String.valueOf(Math.pow(10,-50)*Math.pow(10,progress/3.33));
                seekBar5_tv.setText(progress5);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold5",threshold5);
                editor.putString("progress5",progress5);
                editor.apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {
                new SetupTask(SetupActivity.this).cancel(true);
            }
            public void onStopTrackingTouch(SeekBar bar) {
                seekBar5_tv.setText(progress5);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold5",threshold5);
                editor.putString("progress5",progress5);
                editor.apply();
                new SetupTask(SetupActivity.this).execute();
            }
        });

        seekBar6_tv.setText(progress6);
        seekBar6.setProgress(Integer.parseInt(progress6));
        seekBar6.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean paramBoolean) {
                progress6=String.valueOf(progress);
                threshold6=String.valueOf(Math.pow(10,-50)*Math.pow(10,progress/3.33));
                seekBar6_tv.setText(progress6);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold6",threshold6);
                editor.putString("progress6",progress6);
                editor.apply();
            }
            public void onStartTrackingTouch(SeekBar bar) {
                new SetupTask(SetupActivity.this).cancel(true);
            }
            public void onStopTrackingTouch(SeekBar bar) {
                seekBar6_tv.setText(progress6);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("threshold6",threshold6);
                editor.putString("progress6",progress6);
                editor.apply();
                new SetupTask(SetupActivity.this).execute();
            }
        });

        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
        builder2.setTitle(R.string.reminder);
        builder2.setIcon(R.drawable.ic_notifications_black_24dp);
        builder2.setMessage(R.string.reminder_desc);
        builder2.setCancelable(true);
        builder2.setPositiveButton(
                R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                        final SharedPreferences.Editor editor = settings.edit();
                        final Calendar c = Calendar.getInstance();
                        final int mHour = c.get(Calendar.HOUR_OF_DAY);
                        final int mMinute = c.get(Calendar.MINUTE);
                        TimePickerDialog timePickerDialog = new TimePickerDialog(SetupActivity.this,
                                new TimePickerDialog.OnTimeSetListener() {

                                    @Override
                                    public void onTimeSet(TimePicker view, int hourOfDay,
                                                          int minute) {
                                        String format;
                                        int hourOfDay1=hourOfDay;
                                        if (hourOfDay == 0) {
                                            hourOfDay += 12;
                                            format = "AM";
                                        } else if (hourOfDay == 12) {
                                            format = "PM";
                                        } else if (hourOfDay > 12) {
                                            hourOfDay -= 12;
                                            format = "PM";
                                        } else {
                                            format = "AM";
                                        }
                                        String time=hourOfDay+":"+minute+" "+format;
                                        String time1=hourOfDay1+"."+minute;
                                        editor.putString("setup_reminder_time",time1);
                                        Toast.makeText(SetupActivity.this,"Done. You will be notified at "+time,Toast.LENGTH_LONG).show();
                                        editor.apply();
                                    }

                                }, mHour, mMinute, false);
                        timePickerDialog.show();

                    }
                });
        builder2.setNegativeButton(R.string.cancel,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert_dialog2 = builder2.create();

        remind_setup_btn=findViewById(R.id.remind_setup_btn);
        remind_setup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert_dialog2.show();
            }
        });

        AlertDialog.Builder builder4 = new AlertDialog.Builder(this);
        builder4.setTitle(R.string.reset_setup);
        builder4.setIcon(R.drawable.ic_delete_black_24dp);
        builder4.setMessage(R.string.reset_setup_desc);
        builder4.setCancelable(true);
        builder4.setPositiveButton(
                R.string.ok_continue,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                       resetFile();
                       resetFile1();
                       resetFile2();
                       resetFile3();
                       resetFile4();
                       resetFile5();
                       SharedPreferences.Editor editor=sharedPref.edit();
                       editor.putBoolean("switch2",true);
                       editor.apply();
                    }
                });
        builder4.setNegativeButton(R.string.cancel,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert_dialog4 = builder4.create();
        reset_setup_btn=findViewById(R.id.reset_setup_btn);
        reset_setup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert_dialog4.show();
            }
        });
    }

    private void updateLabel() {
        String myFormat = "dd/MM/yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        ed2.setText(sdf.format(myCalendar.getTime()));
    }

    public void info_dialog(String title,String message){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle(title);
        builder1.setIcon(R.drawable.ic_info_black_24dp);
        builder1.setMessage(message);
        builder1.setCancelable(true);
        builder1.setPositiveButton(
                R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert_dialog1 = builder1.create();
        alert_dialog1.show();
    }


    private static class SetupTask extends AsyncTask<Void, Void, Exception> {

        WeakReference<SetupActivity> activityReference;
        SetupTask(SetupActivity activity) {
            this.activityReference = new WeakReference<>(activity);
        }
        @Override
        protected Exception doInBackground(Void... params) {
            while(!isCancelled()) {
                try {
                    Assets assets = new Assets(activityReference.get());
                    File assetDir = assets.syncAssets();
                    activityReference.get().setupRecognizer(assetDir);
                } catch (IOException e) {
                    return e;
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Exception result) {
                if (result != null) {
                } else {
                    activityReference.get().switchSearch(KWS_SEARCH);
                }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull  int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            }
        }
    }

    @Override
    public void onDestroy() {
        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt("setup_activity_running",0);
        editor.apply();
        super.onDestroy();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.shutdown();
        }
    }

    @Override
    public void onPartialResult(Hypothesis hypothesis) {
        if (hypothesis == null)
            return;
        String text = hypothesis.getHypstr();
        if (text.equals("accident accident")){
            test_tv1.setText("\'Accident Accident\' recognized");
            simpleProgressBar4.setVisibility(View.GONE);
            mic1.setVisibility(View.VISIBLE);
        }
        else if (text.equals("fire fire")){
            test_tv2.setText("\'Fire Fire\' recognized");
            simpleProgressBar3.setVisibility(View.GONE);
            mic2.setVisibility(View.VISIBLE);
        }
        else if (text.equals("medic medic")){
            test_tv3.setText("\'Medic Medic\' recognized");
            simpleProgressBar2.setVisibility(View.GONE);
            mic3.setVisibility(View.VISIBLE);
        }
        else if (text.equals("disaster disaster")){
            test_tv4.setText("\'Disaster Disaster\' recognized");
            simpleProgressBar1.setVisibility(View.GONE);
            mic4.setVisibility(View.VISIBLE);
        }
        else if (text.equals("alert alert")){
            test_tv5.setText("\'Alert Alert\' recognized");
            simpleProgressBar.setVisibility(View.GONE);
            mic5.setVisibility(View.VISIBLE);
        }
        else if (text.equals("crime crime")){
            test_tv6.setText("\'Crime Crime\' recognized");
            simpleProgressBar0.setVisibility(View.GONE);
            mic6.setVisibility(View.VISIBLE);
        }
      switchSearch(KWS_SEARCH);
    }

    @Override
    public void onResult(Hypothesis hypothesis) {

    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onEndOfSpeech() {
        if (recognizer != null) {
            if (!recognizer.getSearchName().equals(KWS_SEARCH)) switchSearch(KWS_SEARCH);
        }
    }

    private void switchSearch(String searchName) {
        recognizer.stop();
        recognizer.startListening(searchName);
    }

    private void setupRecognizer(File assetsDir) throws IOException {
             recognizer = SpeechRecognizerSetup.defaultSetup()
                .setAcousticModel(new File(assetsDir, "en-us-ptm"))
                .setDictionary(new File(assetsDir, "cmudict-en-us.dict"))
                .setRawLogDir(assetsDir) // To disable logging of raw audio comment out this call (takes a lot of space on the device)
                .getRecognizer();
        recognizer.addListener(this);

        try {
            FileOutputStream fileout=openFileOutput("threshold.list", MODE_PRIVATE);
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);
            outputWriter.write("accident accident/"+threshold1+"/\n"+ "fire fire/"+threshold2+"/\n" + "medic medic/"+threshold3+"/\n" + "crime crime/"+threshold4+"/\n" + "disaster disaster/"+threshold5+"/\n" + "alert alert/"+threshold6+"/\n" + "yes/0.8/\n"+"ya/0.8/\n"+"yah/0.8/\n"+"yay/0.8/\n"+"yea/0.8/\n"+"yep/0.8/\n"+"yeah/0.8/\n"+"no/0.8/\n"+"nope/0.8/\n"+"nay/0.8/\n"+"na/0.8/\n");
            outputWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        File file1 = new File(getApplicationContext().getFilesDir(), "threshold.list");
        recognizer.addKeywordSearch(KWS_SEARCH, file1);

    }

    @Override
    public void onError(Exception error) {
    }

    @Override
    public void onTimeout() {
        switchSearch(KWS_SEARCH);
    }


    public void saveFile(){
        String name1=ed.getText().toString();
        String name2=ed1.getText().toString();
        String dob=ed2.getText().toString();
        gender=ed3.getText().toString();
        String address1=ed5_11.getText().toString();
        String address2=ed5_12.getText().toString();
        String address3=ed5_13.getText().toString();
        String address4=ed5_14.getText().toString();
        String mail=ed7.getText().toString();
        if (reset_button_flag==0) {
            save_message=getString(R.string.please_enter_your);
            if (name1.equals("")) {
                save_message+="First Name, ";
            }
            if (name2.equals("")){
                save_message+="Last Name, ";
            }
            if (dob.equals("")){
                save_message+="Date of Birth, ";
            }
            if (gender.equals("")){
                save_message+="Gender, ";
            }
            if (mail.equals("")){
                save_message+="E-Mail, ";
            }
            if (address1.equals("")){
                save_message+="House Name/Number, ";
            }
            if (address2.equals("")){
                save_message+="Street Name/Number, ";
            }
            if (address3.equals("")){
                save_message+="City/Town/Village, ";
            }
            if (address4.equals("")) {
                save_message += "County/State, ";
            }
        }
        if (!save_message.equals(getString(R.string.please_enter_your)) && !save_message.equals("") && reset_button_flag==0){
            save_message=save_message.substring(0,save_message.length()-2)+".\n"+getString(R.string.if_you_are_unable);
            info_dialog(getString(R.string.incomplete_information),save_message);
        }
        if (reset_button_flag==0 && save_message.equals(getString(R.string.please_enter_your))) {
            Toast.makeText(getApplicationContext(), R.string.personal_info_saved, Toast.LENGTH_LONG).show();
        }
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();
        editor.putString("name1",name1);
        editor.putString("name2",name2);
        editor.putString("dob",dob);
        editor.putString("gender",gender);
        editor.putString("address1",address1);
        editor.putString("address2",address2);
        editor.putString("address3",address3);
        editor.putString("address4",address4);
        editor.putString("mail",mail);
        editor.apply();
    }

    public void saveFile3(){
        String medical_info1=ed5_21.getText().toString();
        String medical_info2=ed5_22.getText().toString();
        String medical_info3=ed5_23.getText().toString();
        String medical_info4=ed5_24.getText().toString();
        String medical_info5=ed5_25.getText().toString();
        if(medical_info1.equals("") && reset_button_flag==0) info_dialog(getString(R.string.incomplete_information),getString(R.string.enter_your_blood));
        else Toast.makeText(getApplicationContext(), R.string.medical_info_saved, Toast.LENGTH_LONG).show();
        SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("medical_info1", medical_info1);
        editor.putString("medical_info2", medical_info2);
        editor.putString("medical_info3", medical_info3);
        editor.putString("medical_info4", medical_info4);
        editor.putString("medical_info5", medical_info5);
        editor.apply();
    }


    public void readFile(){
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        String defaultValue = "";
        String name= sharedPref.getString("name1",defaultValue);
        String name2= sharedPref.getString("name2",defaultValue);
        String dob= sharedPref.getString("dob",defaultValue);
        gender= sharedPref.getString("gender",defaultValue);
        String address1= sharedPref.getString("address1",defaultValue);
        String address2= sharedPref.getString("address2",defaultValue);
        String address3= sharedPref.getString("address3",defaultValue);
        String address4= sharedPref.getString("address4",defaultValue);
        String mail= sharedPref.getString("mail",defaultValue);
        ed.setText(name);
        ed1.setText(name2);
        ed2.setText(dob);
        ed3.setText(gender);
        ed5_11.setText(address1);
        ed5_12.setText(address2);
        ed5_13.setText(address3);
        ed5_14.setText(address4);
        ed7.setText(mail);
    }

    public void readFile3(){
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        String defaultValue = "";
        String medical_info1= sharedPref.getString("medical_info1",defaultValue);
        String medical_info2= sharedPref.getString("medical_info2",defaultValue);
        String medical_info3= sharedPref.getString("medical_info3",defaultValue);
        String medical_info4= sharedPref.getString("medical_info4",defaultValue);
        String medical_info5= sharedPref.getString("medical_info5",defaultValue);
        ed5_21.setText(medical_info1);
        ed5_22.setText(medical_info2);
        ed5_23.setText(medical_info3);
        ed5_24.setText(medical_info4);
        ed5_25.setText(medical_info5);
    }

    public void readFile4(){
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        String defaultValue = "";
        String region1= sharedPref.getString("region1",defaultValue);
        String region2= sharedPref.getString("region2",defaultValue);
        String region3= sharedPref.getString("region3",defaultValue);
        ed22.setText(region1);
        ed23.setText(region2);
        ed24.setText(region3);
    }

    public void resetFile(){
        ed.setText("");
        ed1.setText("");
        ed2.setText("");
        ed3.setText("");
        ed5_11.setText("");
        ed5_12.setText("");
        ed5_13.setText("");
        ed5_14.setText("");
        ed7.setText("");
    }

    public void resetFile4(){
        ed5_21.setText("");
        ed5_22.setText("");
        ed5_23.setText("");
        ed5_24.setText("");
        ed5_25.setText("");
    }
    public void saveFile1() {
        String police = ed8.getText().toString();
        String ambulance = ed9.getText().toString();
        String fire = ed10.getText().toString();
        if (reset_button_flag==0) {
            save_message=getString(R.string.enter_emergency_number);
            if (police.equals("")) {
                save_message+="Police, ";
            }
            if (ambulance.equals("")){
                save_message+="Ambulance, ";
            }
            if (fire.equals("")){
                save_message+="Fire & Rescue, ";
            }
        }
        if (!save_message.equals(getString(R.string.enter_emergency_number)) && !save_message.equals("") && reset_button_flag==0){
            save_message=save_message.substring(0,save_message.length()-2)+".\n"+getString(R.string.try_search_eb);
            info_dialog(getString(R.string.incomplete_information),save_message);
        }
        if (reset_button_flag==0 && save_message.equals(getString(R.string.enter_emergency_number))) {
            Toast.makeText(getApplicationContext(), R.string.public_emergency_saved, Toast.LENGTH_LONG).show();
        }
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();
        editor.putString("police",police);
        editor.putString("ambulance",ambulance);
        editor.putString("fire",fire);
        editor.apply();
    }
    public void readFile1() {
        SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        String defaultValue = "";
        String police = sharedPref.getString("police", defaultValue);
        String ambulance = sharedPref.getString("ambulance", defaultValue);
        String fire = sharedPref.getString("fire", defaultValue);
        ed8.setText(police);
        ed9.setText(ambulance);
        ed10.setText(fire);
    }
    public void resetFile1(){
        ed8.setText("");
        ed9.setText("");
        ed10.setText("");
    }
    public void resetFile5(){
        if (!ed22.getText().toString().equals(""))FirebaseMessaging.getInstance().unsubscribeFromTopic(ed22.getText().toString());
        if (!ed23.getText().toString().equals(""))FirebaseMessaging.getInstance().unsubscribeFromTopic(ed23.getText().toString());
        if (!ed24.getText().toString().equals(""))FirebaseMessaging.getInstance().unsubscribeFromTopic(ed24.getText().toString());
        ed22.setText("");
        ed23.setText("");
        ed24.setText("");
    }
    @Override
    protected void onRestart(){
        super.onRestart();
        readFile();
        readFile1();
    }
    private boolean isMyServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (VoiceService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    public void pickContact1 (View v)
    {
            Intent contactPickerIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            startActivityForResult(contactPickerIntent, RESULT_PICK_CONTACT1);
    }
    public void pickContact2 (View v)
    {
        Intent contactPickerIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(contactPickerIntent, RESULT_PICK_CONTACT2);
    }
    public void pickContact3 (View v)
    {
        Intent contactPickerIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(contactPickerIntent, RESULT_PICK_CONTACT3);
    }
        @Override
        protected void onActivityResult ( int requestCode, int resultCode, Intent data){
            if (resultCode == RESULT_OK) {
                switch (requestCode) {
                    case RESULT_PICK_CONTACT1:
                        contactPicked(data,ed11,ed12,ed13);
                        break;
                    case RESULT_PICK_CONTACT2:
                        contactPicked(data,ed14,ed15,ed16);
                        break;
                    case RESULT_PICK_CONTACT3:
                        contactPicked(data,ed17,ed18,ed19);
                        break;
                }
            } else {
            }
        }

        private void contactPicked (Intent data,EditText edit1,EditText edit2,EditText edit3){
            Cursor cursor = null;
            try {
                String phoneNo = null;
                String name = null;
                Uri uri = data.getData();
                cursor = getContentResolver().query(uri, null, null, null, null);
                cursor.moveToFirst();
                int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                name = cursor.getString(nameIndex);
                phoneNo = cursor.getString(phoneIndex);
                edit1.setText(name);
                edit2.setText(phoneNo);
                edit3.requestFocus();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    public void saveFile2(){
        String name1=ed11.getText().toString();
        String phone1=ed12.getText().toString();
        String mail1=ed13.getText().toString();
        String name2=ed14.getText().toString();
        String phone2=ed15.getText().toString();
        String mail2=ed16.getText().toString();
        String name3=ed17.getText().toString();
        String phone3=ed18.getText().toString();
        String mail3=ed19.getText().toString();
        if (reset_button_flag==0) {
            save_message="";
            if (phone1.equals("")) {
                save_message+=getString(R.string.atleast_one_contact);
                info_dialog(getString(R.string.incomplete_information),save_message);
            }
        }
        if (reset_button_flag==0 && save_message.equals("")) {
            Toast.makeText(getApplicationContext(), R.string.personal_emergency_saved, Toast.LENGTH_LONG).show();
        }
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();
        editor.putString("contact_name1",name1);
        editor.putString("contact_number1",phone1);
        editor.putString("contact_mail1",mail1);
        editor.putString("contact_name2",name2);
        editor.putString("contact_number2",phone2);
        editor.putString("contact_mail2",mail2);
        editor.putString("contact_name3",name3);
        editor.putString("contact_number3",phone3);
        editor.putString("contact_mail3",mail3);
        editor.apply();
    }
    public void readFile2() {
            SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
            String defaultValue = "";
            ed11.setText(sharedPref.getString("contact_name1", defaultValue));
            ed12.setText(sharedPref.getString("contact_number1", defaultValue));
            ed13.setText(sharedPref.getString("contact_mail1", defaultValue));
            ed14.setText(sharedPref.getString("contact_name2", defaultValue));
            ed15.setText(sharedPref.getString("contact_number2", defaultValue));
            ed16.setText(sharedPref.getString("contact_mail2", defaultValue));
            ed17.setText(sharedPref.getString("contact_name3", defaultValue));
            ed18.setText(sharedPref.getString("contact_number3", defaultValue));
            ed19.setText(sharedPref.getString("contact_mail3", defaultValue));
    }
    public void resetFile2() {
        ed11.setText("");
        ed12.setText("");
        ed13.setText("");
        ed14.setText("");
        ed15.setText("");
        ed16.setText("");
        ed17.setText("");
        ed18.setText("");
        ed19.setText("");
    }
    public void resetFile3() {
        ed20.setText("");
        ed21.setText("");
    }

    @Override
    protected void onPause() {
        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt("setup_activity_running",0);
        editor.apply();
        super.onPause();
    }
    @Override
    protected void onStop() {
        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt("setup_activity_running",0);
        editor.apply();
        super.onStop();
    }

}





