package com.siriussoftwares.safety;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.renderscript.RenderScript;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.util.Calendar;
import java.util.Random;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;
import edu.cmu.pocketsphinx.SpeechRecognizerSetup;

public class VoiceService extends Service implements RecognitionListener{

    public LinearLayout layout1, activation_layout;
    private static final String KWS_SEARCH = "wakeup";
    private SpeechRecognizer recognizer;
    public SharedPreferences sharedPref;

    String name,date_of_birth;
    public String FileName="data";
    int i=0;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        showNotification();
        return START_STICKY;
    }
    private void showNotification() {
        new SetupTask(this).execute();
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) {
            Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.setAction(Constants.ACTION.MAIN_ACTION);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);


        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setContentTitle("Voice Command Activation is enabled. Tap to disable.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setPriority(-1);

        Notification notification = builder.build();
        startForeground(Constants.NOTIFICATION_ID.FOREGROUND_SERVICE, notification);
    }
        String NOTIFICATION_CHANNEL_ID = "voice_command_activation_status";
        String channelName = "Voice Command Activation Status";
        NotificationChannel chan = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_MIN);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            assert manager != null;
            manager.createNotificationChannel(chan);


            Intent notificationIntent = new Intent(this, MainActivity.class);
            notificationIntent.setAction(Constants.ACTION.MAIN_ACTION);
            notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
            Notification notification1 = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Voice Command Activation is enabled.")
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .setContentIntent(pendingIntent)
                    .build();
            startForeground(2, notification1);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static class SetupTask extends AsyncTask<Void, Void, Exception> {
        WeakReference<VoiceService> serviceReference;
        SetupTask(VoiceService service) {
            this.serviceReference = new WeakReference<>(service);
        }
        @Override
        protected Exception doInBackground(Void... params) {
            try {
                Assets assets = new Assets(serviceReference.get());
                File assetDir = assets.syncAssets();
                serviceReference.get().setupRecognizer(assetDir);

            } catch (IOException e) {
                return e;
            }
            return null;
        }
        @Override
        protected void onPostExecute(Exception result) {
            if (result != null) {

            } else {
                serviceReference.get().switchSearch(KWS_SEARCH);
            }
        }
    }

 /**  @Override
    public void onDestroy() {
        super.onDestroy();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.shutdown();
        }

    }**/

    @Override
    public void onPartialResult(Hypothesis hypothesis) {
        if (hypothesis == null)
            return;

        String text = hypothesis.getHypstr();
        Toast.makeText(this,text, Toast.LENGTH_LONG).show();
        sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        switch (text) {
            case "accident accident": {
                SharedPreferences pref1=getSharedPreferences("activation_data",MODE_PRIVATE);
                SharedPreferences.Editor edit1=pref1.edit();
                edit1.putInt("voice_service_flag", 0);
                edit1.apply();
                AlertDialog.Builder builder4 = new AlertDialog.Builder(getApplicationContext());
                builder4.setTitle("False Alarm");
                builder4.setIcon(R.drawable.ic_delete_black_24dp);
                builder4.setMessage("accident");
                builder4.setCancelable(true);
                builder4.setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert_dialog4 = builder4.create();
                alert_dialog4.show();
                /**Intent dialogIntent = new Intent(VoiceService.this, MainActivity.class);
                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dialogIntent);**/
                break;
            }
            case "fire fire": {
                SharedPreferences pref2=getSharedPreferences("activation_data",MODE_PRIVATE);
                SharedPreferences.Editor edit2=pref2.edit();
                edit2.putInt("voice_service_flag", 1);
                edit2.apply();
                AlertDialog.Builder builder4 = new AlertDialog.Builder(getApplicationContext());
                builder4.setTitle("False Alarm");
                builder4.setIcon(R.drawable.ic_delete_black_24dp);
                builder4.setMessage("fire");
                builder4.setCancelable(true);
                builder4.setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert_dialog4 = builder4.create();
                alert_dialog4.show();
                /**Intent dialogIntent = new Intent(this, MainActivity.class);
                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dialogIntent);**/
                break;
            }
            case "medic medic": {
                SharedPreferences pref3=getSharedPreferences("activation_data",MODE_PRIVATE);
                SharedPreferences.Editor edit3=pref3.edit();
                edit3.putInt("voice_service_flag", 2);
                edit3.apply();
                AlertDialog.Builder builder4 = new AlertDialog.Builder(getApplicationContext());
                builder4.setTitle("False Alarm");
                builder4.setIcon(R.drawable.ic_delete_black_24dp);
                builder4.setMessage("medic");
                builder4.setCancelable(true);
                builder4.setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert_dialog4 = builder4.create();
                alert_dialog4.show();
                /**Intent dialogIntent = new Intent(this, MainActivity.class);
                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dialogIntent);**/
                break;
            }
            case "crime crime": {
                SharedPreferences pref4=getSharedPreferences("data",MODE_PRIVATE);
                SharedPreferences.Editor edit4=pref4.edit();
                edit4.putInt("voice_service_flag", 3);
                edit4.putInt("crime_activation_voice",1);
                edit4.apply();
                AlertDialog.Builder builder4 = new AlertDialog.Builder(getApplicationContext());
                builder4.setTitle("False Alarm");
                builder4.setIcon(R.drawable.ic_delete_black_24dp);
                builder4.setMessage("crime");
                builder4.setCancelable(true);
                builder4.setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert_dialog4 = builder4.create();
                alert_dialog4.show();
                /**Intent dialogIntent = new Intent(this, MainActivity.class);
                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dialogIntent);**/
                break;
            }
            case "disaster disaster": {
                SharedPreferences pref5=getSharedPreferences("activation_data",MODE_PRIVATE);
                SharedPreferences.Editor edit5=pref5.edit();
                edit5.putInt("voice_service_flag", 4);
                edit5.apply();
                AlertDialog.Builder builder4 = new AlertDialog.Builder(getApplicationContext());
                builder4.setTitle("False Alarm");
                builder4.setIcon(R.drawable.ic_delete_black_24dp);
                builder4.setMessage("disaster");
                builder4.setCancelable(true);
                builder4.setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert_dialog4 = builder4.create();
                alert_dialog4.show();
                /**Intent dialogIntent = new Intent(this, MainActivity.class);
                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dialogIntent);**/
                break;
            }
            case "alert alert": {
                SharedPreferences pref6=getSharedPreferences("activation_data",MODE_PRIVATE);
                SharedPreferences.Editor edit6=pref6.edit();
                edit6.putInt("voice_service_flag", 5);
                edit6.apply();
                AlertDialog.Builder builder4 = new AlertDialog.Builder(getApplicationContext());
                builder4.setTitle("False Alarm");
                builder4.setIcon(R.drawable.ic_delete_black_24dp);
                builder4.setMessage("alert");
                builder4.setCancelable(true);
                builder4.setPositiveButton(
                        "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert_dialog4 = builder4.create();
                alert_dialog4.show();
                /**Intent dialogIntent = new Intent(this, MainActivity.class);
                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dialogIntent);**/
                break;
            }
        }
        switchSearch(KWS_SEARCH);
    }
    @Override
    public void onResult(Hypothesis hypothesis) {

    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onEndOfSpeech() {
        if (!recognizer.getSearchName().equals(KWS_SEARCH))
            switchSearch(KWS_SEARCH);
    }

    public void switchSearch(String searchName) {
        recognizer.stop();
        recognizer.startListening(searchName,1000);
    }

    public void setupRecognizer(File assetsDir) throws IOException {
        recognizer = SpeechRecognizerSetup.defaultSetup()
                .setAcousticModel(new File(assetsDir, "en-us-ptm"))
                .setDictionary(new File(assetsDir, "cmudict-en-us.dict"))
                //.setRawLogDir(assetsDir) // To disable logging of raw audio comment out this call (takes a lot of space on the device)
                .getRecognizer();
        recognizer.addListener(this);

        /**String filename = "threshold.list";
        String fileContents = "Hello world!";
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }**/

        try {
            FileOutputStream fileout=openFileOutput("threshold.list", MODE_PRIVATE);
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);
            outputWriter.write("accident accident/1e-40/\n" + "fire fire/0.1/\n" + "medic medic/1e-20/\n" + "crime crime/1e-20/\n" + "disaster disaster/1e-40/\n" + "alert alert/1e-10/\n" + "yes/0.5/");
            outputWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        File file1 = new File(getApplicationContext().getFilesDir(), "threshold.list");

        //File actionGrammar = new File(assetsDir, "keyphrase.list");
        recognizer.addKeywordSearch(KWS_SEARCH, file1);

    }

    @Override
    public void onError(Exception error) {
        System.out.println(error.getMessage());
    }

    @Override
    public void onTimeout() {
        switchSearch(KWS_SEARCH);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        //Restarting the service if it is removed.
      Toast.makeText(this, "Service removed", Toast.LENGTH_LONG).show();
        Intent intent=new Intent(getApplicationContext(), VoiceService.class);
        intent.setPackage(getPackageName());
        PendingIntent service =
        PendingIntent.getService(getApplicationContext(), new Random().nextInt(),intent, PendingIntent.FLAG_ONE_SHOT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        assert alarmManager != null;
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000*30, service);
        super.onTaskRemoved(rootIntent);
  }


}
