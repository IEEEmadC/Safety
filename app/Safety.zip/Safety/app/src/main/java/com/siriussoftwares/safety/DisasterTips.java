package com.siriussoftwares.safety;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import java.util.Locale;

import javax.microedition.khronos.egl.EGLDisplay;

public class DisasterTips extends Activity {

    String title,title1;
    TextView tips_title_tv,tips_text_tv;
    TextToSpeech t1;
    Button speech_settings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disaster_tips);

        tips_title_tv=findViewById(R.id.tips_title_tv);
        tips_text_tv=findViewById(R.id.tips_text_tv);
        speech_settings=findViewById(R.id.speech_settings);

        SharedPreferences sharedPref=getSharedPreferences("data", Context.MODE_PRIVATE);
        title=sharedPref.getString("notification_title","");
        title1=sharedPref.getString("disaster_safety_tips","");

        speech_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction("com.android.settings.TTS_SETTINGS");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.getDefault());
                }
            }
        });

        if(title.contains("Blizzard") || title1.contains("Blizzard")){
            tips_title_tv.setText(getString(R.string.blizzard));
            tips_text_tv.setText(getString(R.string.blizzard_tips));
        }
        if(title.contains("Cold Waves") || title1.contains("Cold Waves")){
            tips_title_tv.setText(getString(R.string.cold_waves));
            tips_text_tv.setText(getString(R.string.cold_waves_tips));
        }
        if(title.contains("Cyclonic Storm") || title1.contains("Cyclonic Storm")){
            tips_title_tv.setText(getString(R.string.cyclonic_storm));
            tips_text_tv.setText(getString(R.string.cyclonic_storm_tips));
        }
        if(title.contains("Earthquake") || title1.contains("Earthquake")){
            tips_title_tv.setText(getString(R.string.earthquake));
            tips_text_tv.setText(getString(R.string.earthquake_tips));
        }
        if(title.contains("Epidemic Hazard") || title1.contains("Epidemic Hazard")){
            tips_title_tv.setText(getString(R.string.epidemic));
            tips_text_tv.setText(getString(R.string.epidemic_tips));
        }
        if(title.contains("Flood") || title1.contains("Flood")){
            tips_title_tv.setText(getString(R.string.flood));
            tips_text_tv.setText(getString(R.string.flood_tips));
        }
        if(title.contains("Hail Storm") || title1.contains("Hail Storm")){
            tips_title_tv.setText(getString(R.string.hail));
            tips_text_tv.setText(getString(R.string.hail_tips));
        }
        if(title.contains("Heat Waves") || title1.contains("Heat Waves")){
            tips_title_tv.setText(getString(R.string.heat_waves));
            tips_text_tv.setText(getString(R.string.heat_waves_tips));
        }
        if(title.contains("Ice Storm") || title1.contains("Ice Storm")){
            tips_title_tv.setText(getString(R.string.ice_storm));
            tips_text_tv.setText(getString(R.string.ice_storm_tips));
        }
        if(title.contains("Landslide") || title1.contains("Landslide")){
            tips_title_tv.setText(getString(R.string.landslide));
            tips_text_tv.setText(getString(R.string.landslide_tips));
        }
        if(title.contains("Limnic Eruption") || title1.contains("Limnic Eruption")){
            tips_title_tv.setText(getString(R.string.limnic));
            tips_text_tv.setText(getString(R.string.limnic_tips));
        }
        if(title.contains("Nuclear Explosion") || title1.contains("Nuclear Explosion")){
            tips_title_tv.setText(getString(R.string.nuclear));
            tips_text_tv.setText(getString(R.string.nuclear_tips));
        }
        if(title.contains("Thunderstorm") || title1.contains("Thunderstorm")){
            tips_title_tv.setText(getString(R.string.thunderstorm));
            tips_text_tv.setText(getString(R.string.thunderstorm_tips));
        }
        if (title.contains("Tsunami") || title1.contains("Tsunami")){
            tips_title_tv.setText(getString(R.string.tsunami));
            tips_text_tv.setText(getString(R.string.tsunami_tips));
        }
        if(title.contains("Volcanic Eruption") || title1.contains("Volcanic Eruption")){
            tips_title_tv.setText(getString(R.string.volcanic));
            tips_text_tv.setText(getString(R.string.volcanic_tips));
        }
        if(title.contains("Wildfire") || title1.contains("Wildfire")){
            tips_title_tv.setText(getString(R.string.wildfire));
            tips_text_tv.setText(getString(R.string.wildfire_tips));
        }
        if(title.equals("") && title1.equals("")){
            tips_title_tv.setText(getString(R.string.not_available));
        }


        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("disaster_safety_tips","");
        editor.apply();
        final FloatingActionButton fab =  findViewById(R.id.fab);
        final FloatingActionButton fab1 = findViewById(R.id.fab1);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.speak(tips_text_tv.getText().toString(),TextToSpeech.QUEUE_FLUSH, null);
                fab.setVisibility(View.GONE);
                fab1.setVisibility(View.VISIBLE);
            }
        });
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.stop();
                fab1.setVisibility(View.GONE);
                fab.setVisibility(View.VISIBLE);
            }
        });
    }
}


