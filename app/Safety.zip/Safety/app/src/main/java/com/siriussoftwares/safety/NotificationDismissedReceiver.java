package com.siriussoftwares.safety;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.widget.Toast;

public class NotificationDismissedReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int notificationId = intent.getExtras().getInt("com.siriussoftwares.safety.notificationId");
        if (notificationId==100){
            SharedPreferences sharedPreferences=context.getSharedPreferences("data",Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putInt("play_alert_tone_flag",0);
            editor.apply();
            Intent playbackServiceIntent = new Intent(context, AudioService.class);
            context.stopService(playbackServiceIntent);
        }
    }
}
