package com.siriussoftwares.safety;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DisasterInform extends AppCompatActivity {
    String FileName="data",name1,num1,mail1,name2,num2,mail2,name3,num3,mail3,myName,myMailid,title,message;
    TextView contact1details,contact2details,contact3details,contact_layout_none;
    EditText input;
    LinearLayout contact_layout1,contact_layout2,contact_layout3;
    Button call_contact1,sms_contact1,email_contact1,call_contact2,sms_contact2,email_contact2,call_contact3,sms_contact3,email_contact3,other_sharing_options;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disaster_inform);

        read_data();

        contact1details=findViewById(R.id.contact1details);
        contact2details=findViewById(R.id.contact2details);
        contact3details=findViewById(R.id.contact3details);
        call_contact1=findViewById(R.id.call_contact1);
        sms_contact1=findViewById(R.id.sms_contact1);
        email_contact1=findViewById(R.id.email_contact1);
        call_contact2=findViewById(R.id.call_contact2);
        sms_contact2=findViewById(R.id.sms_contact2);
        email_contact2=findViewById(R.id.email_contact2);
        call_contact3=findViewById(R.id.call_contact3);
        sms_contact3=findViewById(R.id.sms_contact3);
        email_contact3=findViewById(R.id.email_contact3);
        other_sharing_options=findViewById(R.id.other_sharing_options);
        contact_layout1=findViewById(R.id.contact_layout1);
        contact_layout2=findViewById(R.id.contact_layout2);
        contact_layout3=findViewById(R.id.contact_layout3);
        contact_layout_none=findViewById(R.id.contact_layout_none);

        if (num1.equals("")){
            contact_layout1.setVisibility(View.GONE);
            contact_layout_none.setVisibility(View.VISIBLE);
        }
        if (num2.equals("")){
            contact_layout2.setVisibility(View.GONE);
        }
        if (num2.equals("")){
            contact_layout3.setVisibility(View.GONE);
        }

        contact1details.setText(name1+"\n"+num1+"\n"+mail1);
        contact2details.setText(name2+"\n"+num2+"\n"+mail2);
        contact3details.setText(name3+"\n"+num3+"\n"+mail3);

        call_contact1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(num1);
            }
        });
        call_contact2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(num2);
            }
        });
        call_contact3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(num3);
            }
        });

        sms_contact1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sms_message(name1,title,message,num1);
            }
        });
        sms_contact2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sms_message(name2,title,message,num2);
            }
        });
        sms_contact3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sms_message(name3,title,message,num3);
            }
        });

        email_contact1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email_message(name1,title,message,mail1);
            }
        });
        email_contact2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email_message(name2,title,message,mail2);
            }
        });
        email_contact3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email_message(name3,title,message,mail3);
            }
        });

        other_sharing_options.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String message_share="Hi,\nI received a "+title+" from Safety. This is the alert message- "+message+" I may need your help.";
                sharingIntent.putExtra(Intent.EXTRA_TEXT, message_share);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
            }
        });

    }
    public void read_data() {
        SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        String defaultValue = "";
        name1=sharedPref.getString("contact_name1", defaultValue);
        num1=sharedPref.getString("contact_number1", defaultValue);
        mail1=sharedPref.getString("contact_mail1", defaultValue);
        name2=sharedPref.getString("contact_name2", defaultValue);
        num2=sharedPref.getString("contact_number2", defaultValue);
        mail2=sharedPref.getString("contact_mail2", defaultValue);
        name3=sharedPref.getString("contact_name3", defaultValue);
        num3=sharedPref.getString("contact_number3", defaultValue);
        mail3=sharedPref.getString("contact_mail3", defaultValue);
        myName=sharedPref.getString("name1", defaultValue);
        myMailid = sharedPref.getString("mail", defaultValue);
        title=sharedPref.getString("notification_title","");
        message=sharedPref.getString("notification_message","");
    }
    public void call(String phone) {
        String uri = "tel:" + phone;
        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(uri));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }

    public void sms_message(final String name, String title, String alert_message, final String phoneNo){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Message");
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_message_black_24dp);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(60, 0, 60, 20);
        input = new EditText(DisasterInform.this);
        input.setText("Hi "+name+",\nI received a "+title+" from Safety. This is the alert message- "+alert_message+" I may need your help.\nBye,\n"+myName);
        input.setLayoutParams(lp);
        input.requestFocus();
        container.addView(input);
        builder.setView(container);
        builder.setPositiveButton("SEND", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    ArrayList<String> parts = smsManager.divideMessage(input.getText().toString());
                    smsManager.sendMultipartTextMessage(phoneNo, null, parts,
                            null, null);
                    Toast.makeText(DisasterInform.this, "Message sent to "+name, Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(DisasterInform.this, "Unable to send message to "+name, Toast.LENGTH_LONG).show();
                    ex.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog deactivation_dialog = builder.create();
        deactivation_dialog.show();
    }

    public void email_message(final String name, String title, String message, final String mail){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Message");
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_message_black_24dp);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(60, 0, 60, 20);
        input = new EditText(DisasterInform.this);
        input.setText("Hi "+name+",\nI received a "+title+" from Safety. This is the alert message- "+message+" I may need your help.\nBye,\n"+myName);
        input.setLayoutParams(lp);
        input.requestFocus();
        container.addView(input);
        builder.setView(container);
        builder.setPositiveButton(R.string.send, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                new Thread() {
                    public void run() {
                        String sub = "Disaster Alert for " + myName;
                        String body = input.getText().toString();
                        String send = myMailid;
                        String receive = mail;
                        try {
                            Sender sender = new Sender("alert.safetyapp@gmail.com", "#03SafetyAlert17/");
                            sender.sendMail(sub, body, send, receive);
                            Toast.makeText(DisasterInform.this, "E-Mail sent to "+name, Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog deactivation_dialog = builder.create();
        deactivation_dialog.show();
    }
}
