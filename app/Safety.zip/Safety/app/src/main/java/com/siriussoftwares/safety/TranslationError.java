package com.siriussoftwares.safety;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class TranslationError extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    Button submit,clear;
    EditText errors,corrections,input1,input2;
    Spinner category_spinner;
    String[] category={"English","  Suggest an idea","  Need help","  Other"};
    String mail_id,name1,name2,language,error_message,correction_message,translator_name,translator_mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_translation_error);

        submit=findViewById(R.id.submit_correction);
        clear=findViewById(R.id.clear_correction);
        errors=findViewById(R.id.errors);
        corrections=findViewById(R.id.corrections);
        category_spinner=findViewById(R.id.category_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(TranslationError.this, android.R.layout.simple_spinner_item, category);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category_spinner.setAdapter(adapter);
        category_spinner.setOnItemSelectedListener(this);

        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        name1=sharedPreferences.getString("name1","");
        name2=sharedPreferences.getString("name2","");
        mail_id=sharedPreferences.getString("mail","");
        translator_name=sharedPreferences.getString("translator_name","");
        translator_mail=sharedPreferences.getString("translator_mail","");

        if (translator_name.equals("")) translator_name=name1+name2;
        if (translator_mail.equals("")) translator_mail=mail_id;

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                error_message = errors.getText().toString();
                correction_message = corrections.getText().toString();
                final String receive = "support.safety@siriussoftwares.com";
                if (translator_name.equals("") || translator_mail.equals("")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(TranslationError.this);
                    builder.setTitle(R.string.your_info);
                    builder.setCancelable(true);
                    LinearLayout container = new LinearLayout(TranslationError.this);
                    container.setOrientation(LinearLayout.VERTICAL);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(40, 0, 40, 5);
                    if (translator_name.equals("")){
                        input1 = new EditText(TranslationError.this);
                        input1.setHint("Name");
                        input1.setLayoutParams(lp);
                        input1.requestFocus();
                        container.addView(input1);
                    }
                    if (translator_mail.equals("")){
                        input2 = new EditText(TranslationError.this);
                        input2.setHint("E-mail");
                        input2.setLayoutParams(lp);
                        container.addView(input2);
                    }
                    builder.setView(container);
                    builder.setPositiveButton(R.string.submit, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            translator_name = input1.getText().toString();
                            translator_mail = input2.getText().toString();
                            SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("translator_name", translator_name);
                            editor.putString("translator_mail", translator_mail);
                            editor.apply();
                            new Thread() {
                                public void run() {
                                    try {
                                        Sender sender = new Sender("translate.safetyapp@gmail.com", "fxyadjpjzsidtwoq");
                                        sender.sendMail(language, "Errors\n"+error_message+"\n\nCorrections\n"+correction_message+"\n\nBy,\n"+translator_name+"\n"+translator_mail, translator_mail, receive);
                                    } catch (Exception e) {
                                        Toast.makeText(TranslationError.this, R.string.unable_to_submit, Toast.LENGTH_LONG).show();
                                    }
                                }
                            }.start();
                            Toast.makeText(TranslationError.this,R.string.thank_you_for_help,Toast.LENGTH_LONG).show();

                        }
                    });
                    builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
                    AlertDialog deactivation_dialog = builder.create();
                    deactivation_dialog.show();
                }
                else {
                    new Thread() {
                        public void run() {
                            try {
                                Sender sender = new Sender("translate.safetyapp@gmail.com", "fxyadjpjzsidtwoq");
                                sender.sendMail(language, language+"\n\nErrors\n"+error_message+"\n\nCorrections\n"+correction_message+"\n\nBy,\n"+translator_name+"\n"+translator_mail, translator_mail, receive);
                            } catch (Exception e) {
                                Toast.makeText(TranslationError.this, getString(R.string.unable_to_submit), Toast.LENGTH_LONG).show();
                            }
                        }
                    }.start();
                    Toast.makeText(TranslationError.this,getString(R.string.thank_you_for_help),Toast.LENGTH_LONG).show();
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                errors.setText("");
                corrections.setText("");
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        language= parent.getItemAtPosition(position).toString();
    }
    public void onNothingSelected(AdapterView<?> arg0) {
    }
}
