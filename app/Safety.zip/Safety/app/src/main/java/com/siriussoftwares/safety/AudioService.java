package com.siriussoftwares.safety;



import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Environment;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.util.Random;


public class AudioService extends Service {
    private static final String TAG = "MyService";
    MediaPlayer player;
    int flag,crime_activation_voice;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        flag=sharedPreferences.getInt("play_alert_tone_flag",0);
        crime_activation_voice=sharedPreferences.getInt("crime_activation_voice",0);
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        if (flag==1) {
            player = MediaPlayer.create(this, R.raw.emergency_tone);
            player.setLooping(true);
            player.setVolume(10, 10);
            player.start();
        }
        return START_STICKY;
    }

  /**  @Override
    public void onCreate() {

        SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
        flag=sharedPreferences.getInt("play_alert_tone_flag",0);
        if (flag==1) {
            player = MediaPlayer.create(this, R.raw.emergency_tone);
            player.setLooping(true);
            player.setVolume(10, 10);
            player.start();
        }
    }
**/

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        //Restarting the service if it is removed.
        Toast.makeText(this, "Service removed", Toast.LENGTH_LONG).show();
        Intent intent=new Intent(getApplicationContext(), AudioService.class);
        intent.setPackage(getPackageName());
        PendingIntent service =
                PendingIntent.getService(getApplicationContext(), new Random().nextInt(),intent, PendingIntent.FLAG_ONE_SHOT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        assert alarmManager != null;
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000*30, service);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        if (player!=null) player.stop();
        super.onDestroy();

    }

}
