package com.siriussoftwares.safety;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.util.ArrayList;

public class TrackLocationActivity extends AppCompatActivity {

    LinearLayout tracking_layout1,tracking_layout2,tracking_layout3,tracker_layout1,tracker_layout2,tracker_layout3,info_layout1,info_layout2;
    Button unfollow1,unfollow2,unfollow3,block1,block2,block3,locate1,locate2,locate3,request_contacts,allow_contacts,allow1,allow2,allow3;
    TextView tracking_tv1,tracking_tv2,tracking_tv3,tracker_tv1,tracker_tv2,tracker_tv3,tracking_tv_phone1,tracking_tv_phone2,tracking_tv_phone3,tracker_tv_phone1,tracker_tv_phone2,tracker_tv_phone3;
    int visibility,a=0,flag=0,show_dialog_flag,allow1_visibility,allow2_visibility,allow3_visibility,unfollow_flag,block_flag,locate_flag,allow_flag,sms_type,tracking_layout1_visibility,tracking_layout2_visibility,tracking_layout3_visibility,tracker_layout1_visibility,tracker_layout2_visibility,tracker_layout3_visibility;
    String name,myName1,myName2,phoneNo,tracking_name1,tracking_name2,tracking_name3,tracking_phone1,tracking_phone2,tracking_phone3,tracker_name1,tracker_name2,tracker_name3,tracker_phone1,tracker_phone2,tracker_phone3;
    String sender_name,sender_number,tracker_name,track_location_message;
    EditText input;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_location);

        tracking_layout1=findViewById(R.id.tracking_layout1);
        tracking_layout2=findViewById(R.id.tracking_layout2);
        tracking_layout3=findViewById(R.id.tracking_layout3);
        tracker_layout1=findViewById(R.id.tracker_layout1);
        tracker_layout2=findViewById(R.id.tracker_layout2);
        tracker_layout3=findViewById(R.id.tracker_layout3);
        info_layout1=findViewById(R.id.info_layout1);
        info_layout2=findViewById(R.id.info_layout2);
        unfollow1=findViewById(R.id.unfollow1);
        unfollow2=findViewById(R.id.unfollow2);
        unfollow3=findViewById(R.id.unfollow3);
        block1=findViewById(R.id.block1);
        block2=findViewById(R.id.block2);
        block3=findViewById(R.id.block3);
        allow1=findViewById(R.id.allow1);
        allow2=findViewById(R.id.allow2);
        allow3=findViewById(R.id.allow3);
        locate1=findViewById(R.id.locate1);
        locate2=findViewById(R.id.locate2);
        locate3=findViewById(R.id.locate3);
        request_contacts=findViewById(R.id.request_contacts);
        allow_contacts=findViewById(R.id.allow_contacts);
        tracker_tv1=findViewById(R.id.tracker_tv1);
        tracker_tv2=findViewById(R.id.tracker_tv2);
        tracker_tv3=findViewById(R.id.tracker_tv3);
        tracker_tv_phone1=findViewById(R.id.tracker_tv1_phone);
        tracker_tv_phone2=findViewById(R.id.tracker_tv2_phone);
        tracker_tv_phone3=findViewById(R.id.tracker_tv3_phone);
        tracking_tv1=findViewById(R.id.tracking_tv1);
        tracking_tv2=findViewById(R.id.tracking_tv2);
        tracking_tv3=findViewById(R.id.tracking_tv3);
        tracking_tv_phone1=findViewById(R.id.tracking_tv1_phone);
        tracking_tv_phone2=findViewById(R.id.tracking_tv2_phone);
        tracking_tv_phone3=findViewById(R.id.tracking_tv3_phone);


        get_values();


        if (show_dialog_flag==1){
            android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(TrackLocationActivity.this);
            builder1.setTitle(R.string.track_location_title);
            builder1.setIcon(R.drawable.ic_location_on_black_24dp);
            builder1.setMessage(R.string.track_location_info);
            builder1.setCancelable(true);
            builder1.setPositiveButton(
                    getString(R.string.ok),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            android.app.AlertDialog alert_dialog1 = builder1.create();
            alert_dialog1.show();
            SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putInt("show_dialog_flag",0);
            editor.apply();
        }

        if (!sender_number.equals("")){
            View parentLayout = findViewById(android.R.id.content);
            if (!track_location_message.equals(""))Snackbar.make(parentLayout, track_location_message, Snackbar.LENGTH_LONG).show();
            SharedPreferences sharedPref = getSharedPreferences("data", MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPref.edit();
            edit.putString("track_location_message", "");
            edit.apply();
            if (sms_type==1) {
                info_layout2.setVisibility(View.GONE);
                if (tracker_layout1_visibility != 1) {
                    tracker_layout1.setVisibility(View.VISIBLE);
                    allow1.setVisibility(View.VISIBLE);
                    tracker_tv1.setText(sender_name);
                    tracker_tv_phone1.setText(sender_number);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name1", sender_name);
                    editor.putString("sender_number","");
                    editor.putString("tracker_phone1", sender_number);
                    editor.putInt("tracker_layout1_visibility",1);
                    tracker_name1=sender_name;
                    tracker_phone1=sender_number;
                    tracker_layout1_visibility=1;
                    editor.putInt("allow1_visibility",1);
                    editor.apply();
                    visibility = 1;
                } else if (tracker_layout2_visibility != 1 && visibility != 1) {
                    tracker_layout2.setVisibility(View.VISIBLE);
                    allow2.setVisibility(View.VISIBLE);
                    tracker_tv2.setText(sender_name);
                    tracker_tv_phone2.setText(sender_number);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name2", sender_name);
                    editor.putString("tracker_phone2", sender_number);
                    editor.putString("sender_number","");
                    editor.putInt("allow2_visibility",1);
                    editor.putInt("tracker_layout2_visibility",1);
                    tracker_name2=sender_name;
                    tracker_phone2=sender_number;
                    tracker_layout2_visibility=1;
                    editor.apply();
                    visibility = 2;
                } else if (tracker_layout3_visibility != 1 && visibility != 1 && visibility != 2) {
                    tracker_layout3.setVisibility(View.VISIBLE);
                    allow3.setVisibility(View.VISIBLE);
                    tracker_tv3.setText(sender_name);
                    tracker_tv_phone3.setText(sender_number);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name3", sender_name);
                    editor.putString("tracker_phone3", sender_number);
                    editor.putInt("allow3_visibility",1);
                    tracker_name3=sender_name;
                    tracker_phone3=sender_number;
                    tracker_layout3_visibility=1;
                    editor.putInt("tracker_layout3_visibility",1);
                    editor.putString("sender_number","");
                    editor.apply();
                    visibility = 3;
                }
            }
            if (sms_type==2){
                info_layout1.setVisibility(View.GONE);
                if (sender_number.equals(tracking_phone1)){
                    tracking_tv1.setText(tracking_name1.substring(0,tracking_name1.length()-15));
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracking_name1",tracking_name1.substring(0,tracking_name1.length()-15));
                    editor.putString("sender_number","");
                    tracking_name1=tracking_name1.substring(0,tracking_name1.length()-15);
                    editor.apply();
                }
                else if (sender_number.equals(tracking_phone2)){
                    tracking_tv2.setText(tracking_name2.substring(0,tracking_name2.length()-15));
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracking_name2",tracking_name2.substring(0,tracking_name2.length()-15));
                    editor.putString("sender_number","");
                    tracking_name2=tracking_name2.substring(0,tracking_name2.length()-15);
                    editor.apply();
                }
                else if (sender_number.equals(tracking_phone3)){
                    tracking_tv3.setText(tracking_name3.substring(0,tracking_name3.length()-15));
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracking_name3",tracking_name3.substring(0,tracking_name3.length()-15));
                    editor.putString("sender_number","");
                    tracking_name3=tracking_name3.substring(0,tracking_name3.length()-15);
                    editor.apply();
                }
                else {
                    if (tracking_layout1_visibility != 1) {
                        tracking_tv1.setText(sender_name);
                        tracking_tv_phone1.setText(sender_number);
                        tracking_layout1.setVisibility(View.VISIBLE);
                        SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        tracking_name1=sender_name;
                        tracking_phone1=sender_number;
                        editor.putString("tracking_name1", sender_name);
                        editor.putString("tracking_phone1", sender_number);
                        editor.putString("sender_number","");
                        editor.putInt("tracking_layout1_visibility",1);
                        editor.apply();
                        tracking_layout1_visibility=1;
                        visibility = 1;
                    } else if (tracking_layout2_visibility != 1 && visibility != 1) {
                        tracking_layout2.setVisibility(View.VISIBLE);
                        tracking_tv2.setText(sender_name);
                        tracking_tv_phone2.setText(sender_number);
                        tracking_name2=sender_name;
                        tracking_phone2=sender_number;
                        tracking_layout2_visibility=1;
                        SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("tracking_name2", sender_name);
                        editor.putString("tracking_phone2", sender_number);
                        editor.putString("sender_number","");
                        editor.putInt("tracking_layout2_visibility",1);
                        editor.apply();
                        visibility = 2;
                    } else if (tracking_layout3_visibility != 1 && visibility != 1 && visibility != 2) {
                        tracking_layout3.setVisibility(View.VISIBLE);
                        tracking_tv3.setText(sender_name);
                        tracking_tv_phone3.setText(sender_number);
                        tracking_name3=sender_name;
                        tracking_phone3=sender_number;
                        tracking_layout3_visibility=1;
                        SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("sender_number","");
                        editor.putString("tracking_name3", sender_name);
                        editor.putString("tracking_phone3", sender_number);
                        editor.putInt("tracking_layout3_visibility",1);
                        editor.apply();
                        visibility = 3;
                    }
                }
            }
            if (sms_type==3) {
                if (sender_number.equals(tracker_phone1)){
                    tracker_layout1.setVisibility(View.GONE);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name1", "");
                    editor.putString("tracker_phone1", "");
                    editor.putString("sender_number","");
                    editor.putInt("tracker_layout1_visibility",0);
                    tracker_layout1_visibility=0;
                    editor.apply();
                }
                else if (sender_number.equals(tracker_phone2)){
                    tracker_layout2.setVisibility(View.GONE);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name2", "");
                    editor.putString("tracker_phone2", "");
                    editor.putString("sender_number","");
                    editor.putInt("tracker_layout2_visibility",0);
                    tracker_layout2_visibility=0;
                    editor.apply();
                }
                else if (sender_number.equals(tracker_phone3)){
                    tracker_layout3.setVisibility(View.GONE);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name3", "");
                    editor.putString("tracker_phone3", "");
                    editor.putString("sender_number","");
                    editor.putInt("tracker_layout3_visibility",0);
                    tracker_layout3_visibility=0;
                    editor.apply();
                }
            }
            if (sms_type==4) {
                if (sender_number.equals(tracking_phone1)){
                    tracking_layout1.setVisibility(View.GONE);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracking_name1", "");
                    editor.putString("tracking_phone1", "");
                    editor.putString("sender_number","");
                    editor.putInt("tracking_layout1_visibility",0);
                    tracking_layout1_visibility=0;
                    editor.apply();
                }
                else if (sender_number.equals(tracking_phone2)){
                    tracking_layout2.setVisibility(View.GONE);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracking_name2", "");
                    editor.putString("tracking_phone2", "");
                    editor.putString("sender_number","");
                    editor.putInt("tracking_layout2_visibility",0);
                    tracking_layout2_visibility=0;
                    editor.apply();
                }
                else if (sender_number.equals(tracking_phone3)){
                    tracking_layout3.setVisibility(View.GONE);
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracking_name3", "");
                    editor.putString("tracking_phone3", "");
                    editor.putString("sender_number","");
                    editor.putInt("tracking_layout3_visibility",0);
                    tracking_layout3_visibility=0;
                    editor.apply();
                }
            }
        }
        if (tracking_layout1_visibility==1) {
            tracking_layout1.setVisibility(View.VISIBLE);
            tracking_tv1.setText(tracking_name1);
            tracking_tv_phone1.setText(tracking_phone1);
        }
        if (tracking_layout2_visibility==1) {
            tracking_layout2.setVisibility(View.VISIBLE);
            tracking_tv2.setText(tracking_name2);
            tracking_tv_phone2.setText(tracking_phone2);
        }
        if (tracking_layout3_visibility==1){
            tracking_layout3.setVisibility(View.VISIBLE);
            tracking_tv3.setText(tracking_name3);
            tracking_tv_phone3.setText(tracking_phone3);
        }
        if (tracking_layout1_visibility!=1 && tracking_layout3_visibility!=1 && tracking_layout3_visibility!=1)info_layout1.setVisibility(View.VISIBLE);

        if (tracker_layout1_visibility==1) {
            if (allow1_visibility==1)allow1.setVisibility(View.VISIBLE);
            tracker_layout1.setVisibility(View.VISIBLE);
            tracker_tv1.setText(tracker_name1);
            tracker_tv_phone1.setText(tracker_phone1);
        }

        if (tracker_layout2_visibility==1) {
            if (allow2_visibility==1)allow2.setVisibility(View.VISIBLE);
            tracker_layout2.setVisibility(View.VISIBLE);
            tracker_tv2.setText(tracker_name2);
            tracker_tv_phone2.setText(tracker_phone2);
        }

        if (tracker_layout3_visibility==1){
            if (allow2_visibility==1)allow2.setVisibility(View.VISIBLE);
            tracker_layout3.setVisibility(View.VISIBLE);
            tracker_tv3.setText(tracker_name3);
            tracker_tv_phone3.setText(tracker_phone3);
        }
        if (tracker_layout1_visibility!=1 && tracker_layout3_visibility!=1 && tracker_layout3_visibility!=1)info_layout2.setVisibility(View.VISIBLE);

        request_contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tracking_layout1_visibility==1 && tracking_layout2_visibility==1 && tracking_layout3_visibility==1){
                    Toast.makeText(getApplicationContext(), R.string.reached_limit, Toast.LENGTH_LONG).show();
                }
                else {
                    pickContact1();
                    a = 1;
                }
            }
        });

        unfollow1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unfollow_flag=1;
                if (tracker_name.equals("")  && (myName1+myName2).equals("")) {
                    flag=2;
                    enter_name_prompt();
                }
                else {
                    if (tracker_name.equals("")) tracker_name=myName1+myName2;
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name", tracker_name);
                    editor.apply();
                    SendMessage2(tracking_phone1,tracking_name1,tracker_name);
                }
            }
        });
        unfollow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unfollow_flag=2;
                SendMessage2(tracking_phone2,tracking_name2,tracker_name);
            }
        });
        unfollow3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unfollow_flag=3;
                SendMessage2(tracking_phone3,tracking_name3,tracker_name);
            }
        });

        allow_contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tracking_layout1_visibility==1 && tracking_layout2_visibility==1 && tracking_layout3_visibility==1){
                    Toast.makeText(getApplicationContext(), getString(R.string.reached_limit), Toast.LENGTH_LONG).show();
                }
                else {
                    pickContact1();
                    a = 2;
                }
            }
        });

        allow1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allow_flag=1;
                if (tracker_name.equals("")  && (myName1+myName2).equals("")) {
                    flag=5;
                    enter_name_prompt();
                }
                else {
                    if (tracker_name.equals("")) tracker_name=myName1+myName2;
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name", tracker_name);
                    editor.apply();
                    SendMessage5(tracker_phone1,tracker_name1,tracker_name);
                }
            }
        });
        allow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allow_flag=2;
                SendMessage5(tracker_phone2,tracker_name2,tracker_name);
            }
        });
        allow3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allow_flag=3;
                SendMessage5(tracker_phone3,tracker_name3,tracker_name);
            }
        });

        locate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tracking_name1.contains("Request Sent")){
                    Toast.makeText(getApplicationContext(), R.string.locate_after_contact_allows, Toast.LENGTH_LONG).show();
                }
                else {
                    locate_flag = 1;
                    if (tracker_name.equals("") && (myName1 + myName2).equals("")) {
                        flag = 6;
                        enter_name_prompt();
                    } else {
                        if (tracker_name.equals("")) tracker_name = myName1 + myName2;
                        SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("tracker_name", tracker_name);
                        editor.apply();
                        SendMessage6(tracking_phone1, tracking_name1, tracker_name);
                    }
                }
            }
        });
        locate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tracking_name2.contains("Request Sent")){
                    Toast.makeText(getApplicationContext(), R.string.locate_after_contact_allows, Toast.LENGTH_LONG).show();
                }
                else {
                    locate_flag = 2;
                    SendMessage6(tracking_phone2, tracking_name2, tracker_name);
                }
            }
        });
        locate3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tracking_name1.contains("Request Sent")){
                    Toast.makeText(getApplicationContext(), R.string.locate_after_contact_allows, Toast.LENGTH_LONG).show();
                }
                else {
                    locate_flag = 3;
                    SendMessage6(tracking_phone3, tracking_name3, tracker_name);
                }
            }
        });

        block1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                block_flag=1;
                if (tracker_name.equals("")  && (myName1+myName2).equals("")) {
                    flag=3;
                    enter_name_prompt();
                }
                else {
                    if (tracker_name.equals("")) tracker_name=myName1+myName2;
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name", tracker_name);
                    editor.apply();
                    SendMessage3(tracker_phone1,tracker_name1,tracker_name);
                }
            }
        });
        block2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                block_flag=2;
                SendMessage3(tracker_phone2,tracker_name2,tracker_name);
            }
        });
        block3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                block_flag=3;
                SendMessage3(tracker_phone3,tracker_name3,tracker_name);
            }
        });
    }

    public void pickContact1 ()
    {
        Intent contactPickerIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(contactPickerIntent, 1);
    }
    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data){
        if (resultCode == RESULT_OK) {
            contactPicked(data);
        } else {
            Log.e("SetupActivity", "Failed to pick contact");
        }
    }

    private void contactPicked (Intent data){
        Cursor cursor = null;
        try {
            Uri uri = data.getData();
            cursor = getContentResolver().query(uri, null, null, null, null);
            cursor.moveToFirst();
            int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
            int nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
            name = cursor.getString(nameIndex);
            phoneNo = cursor.getString(phoneIndex);
            phoneNo=phoneNo.replaceAll(" ","");
            phoneNo=phoneNo.replaceAll("-","");
            if(phoneNo.substring(0,1).equals("+"))
            try {
                PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                Phonenumber.PhoneNumber numberProto = phoneUtil.parse(phoneNo, "");
                phoneNo = String.valueOf(numberProto.getNationalNumber());
            } catch (NumberParseException e) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
                builder1.setTitle(R.string.request_failed);
                builder1.setMessage(R.string.request_failed_desc);
                builder1.setCancelable(true);
                builder1.setPositiveButton(
                        R.string.ok,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                final AlertDialog alert_dialog1 = builder1.create();
                alert_dialog1.show();
            }

            if (a == 1) {
                if (tracker_name.equals("") && (myName1+myName2).equals("")) {
                    flag=1;
                    enter_name_prompt();
                } else {
                    if (tracker_name.equals("")) tracker_name=myName1+myName2;
                    SendMessage1(phoneNo, name, tracker_name);
                }
            }
            if (a == 2) {
                if (tracker_name.equals("")  && (myName1+myName2).equals("")) {
                 flag=4;
                 enter_name_prompt();
                }
                else {
                    if (tracker_name.equals("")) tracker_name=myName1+myName2;
                    SendMessage4(phoneNo, name, tracker_name);
                }            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SendMessage6(String phoneNo,String name,String myName) {
        try {
            String Name="";
            if (!myName.equals("")) Name=" by "+myName;
            if (name.equals("")) name=phoneNo;
            String msg="Safety Track Location-\nYour location is being tried to access"+Name;
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts, null, null);
            if (locate_flag==1){
                pd = new ProgressDialog(TrackLocationActivity.this);
                pd.setMessage(getString(R.string.locating));
                pd.show();
            }
            if (locate_flag==2){
                pd = new ProgressDialog(TrackLocationActivity.this);
                pd.setMessage(getString(R.string.locating));
                pd.show();
            }
            if (locate_flag==3){
                pd = new ProgressDialog(TrackLocationActivity.this);
                pd.setMessage(getString(R.string.locating));
                pd.show();
            }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), getString(R.string.unable_to_locate)+name, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }
    public void SendMessage1(String phoneNo,String name,String myName) {
        try {
            String Name="";
            if (!myName.equals("")) Name=" from "+myName;
            if (name.equals("")) name=phoneNo;
            String msg="Safety Track Location-\nYou received a request"+Name;
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts, null, null);
            Toast.makeText(getApplicationContext(), "Request sent to "+name, Toast.LENGTH_LONG).show();

            visibility = 0;
            info_layout1.setVisibility(View.GONE);
            if (tracking_layout1.getVisibility() == View.GONE) {
                tracking_name1 = name+" (Request Sent)";
                tracking_phone1=phoneNo;
                tracking_layout1.setVisibility(View.VISIBLE);
                tracking_tv1.setText(tracking_name1);
                tracking_tv_phone1.setText(tracking_phone1);
                SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("tracking_name1",tracking_name1);
                editor.putString("tracking_phone1",tracking_phone1);
                editor.putInt("tracking_layout1_visibility",1);
                editor.apply();
                visibility = 1;
            }
            if (tracking_layout2.getVisibility() == View.GONE && visibility != 1) {
                tracking_name2 = name+" (Request Sent)";
                tracking_phone2=phoneNo;
                tracking_layout2.setVisibility(View.VISIBLE);
                tracking_tv2.setText(tracking_name2);
                tracking_tv_phone2.setText(tracking_phone2);
                SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("tracking_name2",tracking_name2);
                editor.putString("tracking_phone2",tracking_phone2);
                editor.putInt("tracking_layout2_visibility",1);
                editor.apply();
                visibility = 2;
            }
            if (tracking_layout3.getVisibility() == View.GONE && visibility != 1 && visibility != 2) {
                tracking_name3 = name+" (Request Sent)";
                tracking_phone3=phoneNo;
                tracking_layout3.setVisibility(View.VISIBLE);
                tracking_tv3.setText(tracking_name3);
                tracking_tv_phone3.setText(tracking_phone3);
                SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("tracking_name3",tracking_name3);
                editor.putString("tracking_phone3",tracking_phone3);
                editor.putInt("tracking_layout3_visibility",1);
                editor.apply();
                visibility = 3;
            }

        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Unable to send request to "+name, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }
    public void SendMessage2(String phoneNo,String name,String myName) {
        try {
            String Name="";
            if (!myName.equals("")) Name=" by "+myName;
            if (name.equals("")) name=phoneNo;
            String msg="Safety Track Location-\nYou are unfollowed"+Name;
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts, null, null);
            Toast.makeText(getApplicationContext(), "You unfollowed "+name, Toast.LENGTH_LONG).show();
            SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if (unfollow_flag==1){
                tracking_layout1.setVisibility(View.GONE);
                editor.putInt("tracking_layout1_visibility",0);
                editor.putString("tracking_phone1","");
                editor.apply();
                if (tracking_layout1.getVisibility()==View.GONE && tracking_layout2.getVisibility()==View.GONE && tracking_layout3.getVisibility()==View.GONE) info_layout1.setVisibility(View.VISIBLE);
            }
            else if (unfollow_flag==2){
                tracking_layout2.setVisibility(View.GONE);
                editor.putInt("tracking_layout2_visibility",0);
                editor.putString("tracking_phone2","");
                editor.apply();
            }
            else if(unfollow_flag==3){
                tracking_layout3.setVisibility(View.GONE);
                editor.putInt("tracking_layout3_visibility",0);
                editor.putString("tracking_phone3","");
                editor.apply();
            }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Unable to unfollow "+name, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }
    public void SendMessage3(String phoneNo,String name,String myName) {
        try {
            String Name="";
            if (!myName.equals("")) Name=" by "+myName;
            if (name.equals("")) name=phoneNo;
            String msg="Safety Track Location-\nYou have been blocked"+Name;
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts, null, null);
            Toast.makeText(getApplicationContext(), "You blocked "+name, Toast.LENGTH_LONG).show();
            SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPreferences.edit();
            if (block_flag==1){
                tracker_layout1.setVisibility(View.GONE);
                edit.putInt("tracker_layout1_visibility",0);
                tracker_layout1_visibility=0;
                edit.apply();
            }
            else if (block_flag==2){
                tracker_layout2.setVisibility(View.GONE);
                tracker_layout2_visibility=0;
                edit.putInt("tracker_layout2_visibility",0);
                edit.apply();
            }
            else if (block_flag==3){
                tracker_layout3_visibility=0;
                tracker_layout3.setVisibility(View.GONE);
                edit.putInt("tracker_layout3_visibility",0);
                edit.apply();
            }
            if (tracker_layout1_visibility!=1 && tracker_layout3_visibility!=1 && tracker_layout3_visibility!=1)info_layout2.setVisibility(View.VISIBLE);
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Unable to block "+name, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    public void SendMessage4(String phoneNo,String name,String myName) {
        try {
            String Name="";
            if (!myName.equals("")) Name=myName;
            if (name.equals("")) name=phoneNo;
            String msg="Safety Track Location-\nYou are allowed to track "+Name;
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts, null, null);
            Toast.makeText(getApplicationContext(), name+" can now locate you without your permission.", Toast.LENGTH_LONG).show();

            visibility = 0;
            info_layout2.setVisibility(View.GONE);
            if (tracker_layout1.getVisibility() == View.GONE) {
                tracker_name1 = name;
                tracker_phone1=phoneNo;
                tracker_phone1 = tracker_phone1.replaceAll(" ", "");
                tracker_phone1 = tracker_phone1.replaceAll("-", "");
                if (!tracker_phone1.substring(0, 1).equals("+")) tracker_phone1 = "+" + tracker_phone1;
                try {
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                    Phonenumber.PhoneNumber numberProto = phoneUtil.parse(tracker_phone1, "");
                    tracker_phone1 = String.valueOf(numberProto.getNationalNumber());
                } catch (NumberParseException e) {
                }
                tracker_layout1.setVisibility(View.VISIBLE);
                tracker_tv1.setText(tracker_name1);
                tracker_tv_phone1.setText(tracker_phone1);
                allow1.setVisibility(View.GONE);
                SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("tracker_name1",tracker_name1);
                editor.putString("tracker_phone1",tracker_phone1);
                editor.putString("sender_number","");
                editor.putInt("tracker_layout1_visibility",1);
                editor.apply();
                visibility = 1;
            }
            if (tracker_layout2.getVisibility() == View.GONE && visibility != 1) {
                tracker_name2 = name;
                tracker_phone2=phoneNo;
                tracker_phone2 = tracker_phone2.replaceAll(" ", "");
                tracker_phone2 = tracker_phone2.replaceAll("-", "");
                if (!tracker_phone2.substring(0, 1).equals("+")) tracker_phone2 = "+" + tracker_phone2;
                try {
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                    Phonenumber.PhoneNumber numberProto = phoneUtil.parse(tracker_phone2, "");
                    tracker_phone2 = String.valueOf(numberProto.getNationalNumber());
                } catch (NumberParseException e) {
                }
                tracker_layout2.setVisibility(View.VISIBLE);
                tracker_tv2.setText(tracker_name2);
                tracker_tv_phone2.setText(tracker_phone2);
                allow2.setVisibility(View.GONE);
                SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("tracker_name2",tracker_name2);
                editor.putString("tracker_phone2",tracker_phone2);
                editor.putInt("tracker_layout2_visibility",1);
                editor.putString("sender_number","");
                editor.apply();
                visibility = 2;
            }
            if (tracker_layout3.getVisibility() == View.GONE && visibility != 1 && visibility != 2) {
                tracker_name3 = name;
                tracker_phone3=phoneNo;
                tracker_phone3 = tracker_phone3.replaceAll(" ", "");
                tracker_phone3 = tracker_phone3.replaceAll("-", "");
                if (!tracker_phone3.substring(0, 1).equals("+")) tracker_phone3 = "+" + tracker_phone3;
                try {
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                    Phonenumber.PhoneNumber numberProto = phoneUtil.parse(tracker_phone3, "");
                    tracker_phone3 = String.valueOf(numberProto.getNationalNumber());
                } catch (NumberParseException e) {
                }
                tracker_layout3.setVisibility(View.VISIBLE);
                tracker_tv3.setText(tracker_name3);
                allow3.setVisibility(View.GONE);
                tracker_tv_phone3.setText(tracker_phone3);
                SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("tracker_name3",tracker_name3);
                editor.putString("tracker_phone3",tracker_phone3);
                editor.putInt("tracker_layout3_visibility",1);
                editor.putString("sender_number","");
                editor.apply();
                visibility = 3;
            }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Unable to allow "+name, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    public void SendMessage5(String phoneNo,String name,String myName) {
        try {
            String Name="";
            if (!myName.equals("")) Name=myName;
            if (name.equals("")) name=phoneNo;
            String msg="Safety Track Location-\nYou are allowed to track "+Name;
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts, null, null);
            Toast.makeText(getApplicationContext(), name+" can now locate you without your permission.", Toast.LENGTH_LONG).show();
            sender_number="";
            SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPreferences.edit();
            if (allow_flag==1){
                edit.putString("sender_number","");
                edit.putInt("allow1_visibility",0);
                allow1.setVisibility(View.GONE);
                edit.apply();
            }
            else if (allow_flag==2){
                edit.putString("sender_number","");
                edit.putInt("allow2_visibility",0);
                edit.apply();
                allow2.setVisibility(View.GONE);
            }
            else if (allow_flag==3){
                edit.putInt("allow3_visibility",0);
                edit.putString("sender_number","");
                edit.apply();
                allow3.setVisibility(View.GONE);
            }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(), "Unable to allow "+name, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    public  void get_values(){
        SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
        show_dialog_flag=sharedPreferences.getInt("show_dialog_flag",1);
        track_location_message=sharedPreferences.getString("track_location_message","");
        tracking_name1=sharedPreferences.getString("tracking_name1","");
        tracking_name2=sharedPreferences.getString("tracking_name2","");
        tracking_name3=sharedPreferences.getString("tracking_name3","");
        tracking_phone1=sharedPreferences.getString("tracking_phone1","");
        tracking_phone2=sharedPreferences.getString("tracking_phone2","");
        tracking_phone3=sharedPreferences.getString("tracking_phone3","");
        tracking_layout1_visibility=sharedPreferences.getInt("tracking_layout1_visibility",0);
        tracking_layout2_visibility=sharedPreferences.getInt("tracking_layout2_visibility",0);
        tracking_layout3_visibility=sharedPreferences.getInt("tracking_layout3_visibility",0);
        tracker_name1=sharedPreferences.getString("tracker_name1","");
        tracker_name2=sharedPreferences.getString("tracker_name2","");
        tracker_name3=sharedPreferences.getString("tracker_name3","");
        tracker_phone1=sharedPreferences.getString("tracker_phone1","");
        tracker_phone2=sharedPreferences.getString("tracker_phone2","");
        tracker_phone3=sharedPreferences.getString("tracker_phone3","");
        tracker_layout1_visibility=sharedPreferences.getInt("tracker_layout1_visibility",0);
        tracker_layout2_visibility=sharedPreferences.getInt("tracker_layout2_visibility",0);
        tracker_layout3_visibility=sharedPreferences.getInt("tracker_layout3_visibility",0);
        allow1_visibility=sharedPreferences.getInt("allow1_visibility",0);
        allow2_visibility=sharedPreferences.getInt("allow2_visibility",0);
        allow3_visibility=sharedPreferences.getInt("allow3_visibility",0);
        myName1=sharedPreferences.getString("name1","");
        myName2=sharedPreferences.getString("name2","");
        tracker_name=sharedPreferences.getString("tracker_name","");
        sender_name=sharedPreferences.getString("sender_name","");
        sender_number=sharedPreferences.getString("sender_number","");
        sms_type=sharedPreferences.getInt("sms_type",0);
    }

    public void enter_name_prompt(){
        if (tracker_name.equals("") && (myName1+myName2).equals("")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(R.string.your_name);
            builder.setCancelable(true);
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(40, 0, 40, 20);
            input = new EditText(TrackLocationActivity.this);
            input.setLayoutParams(lp);
            input.requestFocus();
            container.addView(input);
            builder.setView(container);
            builder.setPositiveButton(R.string.proceed, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    tracker_name = input.getText().toString();
                    SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("tracker_name", tracker_name);
                    editor.apply();
                    if (flag==1){
                        SendMessage1(phoneNo, name, tracker_name);
                        flag=0;
                    }
                    if (flag==2){
                        SendMessage2(tracking_phone1,tracking_name1,tracker_name);
                        flag=0;
                    }
                    if (flag==3){
                        SendMessage3(tracker_phone1,tracker_name1,tracker_name);
                        flag=0;
                    }
                    if (flag==4){
                        SendMessage4(phoneNo, name, tracker_name);
                        flag=0;
                    }
                    if (flag==5){
                        SendMessage5(tracker_phone1,tracker_name1,tracker_name);
                        flag=0;
                    }
                    if (flag==6){
                        SendMessage6(tracking_phone1,tracking_name1,tracker_name);
                        flag=0;
                    }
                }
            });
            builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });
            AlertDialog deactivation_dialog = builder.create();
            deactivation_dialog.show();
            deactivation_dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
            deactivation_dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        }

    @Override
    protected void onStop() {
        if (pd!=null) pd.cancel();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (pd!=null) pd.cancel();
        super.onDestroy();
    }
}
