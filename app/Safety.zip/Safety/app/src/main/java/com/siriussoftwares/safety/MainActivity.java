package com.siriussoftwares.safety;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.telephony.SmsManager;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.location.Location;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.messaging.RemoteMessage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;
import edu.cmu.pocketsphinx.SpeechRecognizerSetup;

import static android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS;
import static android.widget.Toast.makeText;
import static java.lang.Boolean.TRUE;


public class MainActivity extends AppCompatActivity implements RecognitionListener,NavigationView.OnNavigationItemSelectedListener{
    public String phoneNo1, phoneNo2, phoneNo3, myFirstName, myLastName, myMailid,date_of_birth,gender,contact_name1,contact_name2,contact_name3;
    public String message;
    public String address1,address2,address3,address4,address5,address6,medical_info1,medical_info2,medical_info3,medical_info4,medical_info5;
    public String mailid1,mailid2,mailid3;
    public String password,entered_password;
    public String notification_message,notification_title;
    public LinearLayout layout1, activation_layout,activation_layout1;
    public int pos, i,activation_warning_flag=0, dialog_flag, flag, flag_value, flag_value1, message_count, crime_activation_voice,message_count1,cancel_alarm_flag, call_flag = 0, call_flag1;
    public Boolean switch_state2;
    MediaPlayer mp;
    Vibrator v;
    Button accident_activation,crime_activation,fire_activation,medic_activation,alert_activation,disaster_activation,main_button3,main_button1_red,main_button2_red,main_button3_red;
    String police,ambulance,fire;
    long activation_time,deactivation_time;
    public Ringtone ringtone1;
    Timer timer,timer1;
    CountDownTimer countDownTimer;
    public String alarmTone1,alarmTone2,alarmTone3,deactivation_time_seconds;
    public TextView activation_tv;
    WifiManager wifiManager;
    public String FileName = "data";
    SharedPreferences permissionStatus;
    static final int REQUEST_GOOGLE_PLAY_SERVICES = 1002;
    private static final int SMS_PERMISSION_CONSTANT = 100;
    EditText input;
    Button mute_activation_alert,cancel_activation_alert,share_activation,activation_call_police,activation_call_ambulance,activation_call_fire,activation_call_contact1,activation_call_contact2,activation_call_contact3;
    AlertDialog deactivation_dialog,deactivation_dialog1,deactivation_dialog2;


    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 100;
    private static final String KWS_SEARCH = "wakeup";
    private SpeechRecognizer recognizer;

    TextToSpeech t1;



    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        activation_layout = findViewById(R.id.activation_layout);
        layout1 = findViewById(R.id.layout1);
        activation_layout1 = findViewById(R.id.activation_layout1);

        accident_activation=findViewById(R.id.accident_activation);
        fire_activation=findViewById(R.id.fire_activation);
        crime_activation=findViewById(R.id.crime_activation);
        alert_activation=findViewById(R.id.alert_activation);
        medic_activation=findViewById(R.id.medic_activation);
        disaster_activation=findViewById(R.id.disaster_activation);
        main_button3=findViewById(R.id.main_button3);
        main_button1_red=findViewById(R.id.main_button1_red);
        main_button2_red=findViewById(R.id.main_button2_red);
        main_button3_red=findViewById(R.id.main_button3_red);
        mute_activation_alert=findViewById(R.id.mute_activation_alert);
        cancel_activation_alert=findViewById(R.id.cancel_activation_alert);
        share_activation=findViewById(R.id.share_activation);
        activation_call_police=findViewById(R.id.activation_call_police);
        activation_call_ambulance=findViewById(R.id.activation_call_ambulance);
        activation_call_fire=findViewById(R.id.activation_call_fire);
        activation_call_contact1=findViewById(R.id.activation_call_contact1);
        activation_call_contact2=findViewById(R.id.activation_call_contact2);
        activation_call_contact3=findViewById(R.id.activation_call_contact3);

        permissionStatus = getSharedPreferences(FileName, MODE_PRIVATE);

        SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        shared_values();

        deactivation_time=Long.parseLong(deactivation_time_seconds);

        if (getIntent().getExtras() != null ) {
            Object value ;
            for (String key : getIntent().getExtras().keySet()) {
                SharedPreferences.Editor editor=sharedPref.edit();
                if(key.equalsIgnoreCase("t")){
                    value = getIntent().getExtras().get(key);
                    notification_title=String.valueOf(value);
                    editor.putString("notification_title",notification_title);
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("m")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("notification_message",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("n")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_numbers",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("1")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_1",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("i1")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_i1",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("2")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_2",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("i2")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_i2",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("3")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_3",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("i3")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_i3",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("4")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_4",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("i4")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_i4",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("5")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_5",String.valueOf(value));
                    editor.apply();
                }
                else if(key.equalsIgnoreCase("i5")){
                    value = getIntent().getExtras().get(key);
                    editor.putString("disaster_i5",String.valueOf(value));
                    editor.apply();
                }
            }
        }

        if (notification_title==null){
            main_button1_red.setVisibility(View.GONE);
        }
        if(notification_title!=null){
            main_button1_red.setVisibility(View.VISIBLE);
            main_button1_red.setText(notification_title);
        }

        if (switch_state2){
            main_button3.setVisibility(View.VISIBLE);
            main_button3_red.setVisibility(View.GONE);
        }
        else {
            main_button3.setVisibility(View.GONE);
            main_button3_red.setVisibility(View.VISIBLE);
        }

        if (disaster_activation.getHeight()>80){
            disaster_activation.setText("20sp");
            alert_activation.setText("20sp");
            fire_activation.setText("20sp");
            medic_activation.setText("20sp");
            crime_activation.setText("20sp");
            accident_activation.setText("20sp");
        }


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel("Disaster Alert Notifications", "ch", NotificationManager.IMPORTANCE_HIGH,"Enable Disaster Alert notifications with high importance and custom sound",true);
            createNotificationChannel("Emergency Information Notifications", "emergency_information_notifications", NotificationManager.IMPORTANCE_HIGH,"Enable Emergency Information notifications with high importance and lock screen visibility. These are notifications which shows your personal information when you activate Safety.",true);
            createNotificationChannel("Track Location Notifications", "track_location_notifications", NotificationManager.IMPORTANCE_HIGH,"Notifications that will be shown when you receive any updates in Safety Track Location",false);
            createNotificationChannel("Other Notifications", "other_notifications", NotificationManager.IMPORTANCE_DEFAULT,"",false);
        }

        main_button1_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, DisasterAlert.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
        main_button2_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, IncomingAlert.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
        main_button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             main_button3.setVisibility(View.GONE);
                main_button3_red.setVisibility(View.VISIBLE);
                SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean("switch2", false);
                switch_state2=false;
                editor.apply();
                Intent serviceIntent = new Intent(getApplicationContext(), VoiceService.class);
                stopService(serviceIntent);
            }
        });
        main_button3_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                main_button3_red.setVisibility(View.GONE);
                main_button3.setVisibility(View.VISIBLE);
                SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putBoolean("switch2",true);
                editor.apply();
                switch_state2=true;
                Intent serviceIntent = new Intent(getApplicationContext(), VoiceService.class);
                startService(serviceIntent);
            }
        });


        if (switch_state2) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent serviceIntent = new Intent(MainActivity.this, VoiceService.class);
                serviceIntent.setAction(Constants.ACTION.STARTFOREGROUND_ACTION);
                startForegroundService(serviceIntent);
            } else {
                Intent serviceIntent = new Intent(getApplicationContext(), VoiceService.class);
                startService(serviceIntent);
            }
        }
        else{
            Intent serviceIntent = new Intent(getApplicationContext(), VoiceService.class);
            stopService(serviceIntent);
        }

      //  SharedPreferences pref1=getSharedPreferences("activation_data",MODE_PRIVATE);
        //int cancel_alarm_flag1=pref1.getInt("cancel_alarm_flag",0);
        if (cancel_alarm_flag==1){
            CancelAlarm();
            SharedPreferences sharedPref1 = getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPref1.edit();
            editor.putInt("cancel_alarm_flag",0);
            editor.putInt("play_alert_tone_flag",0);
            editor.apply();
            Intent serviceIntent = new Intent(getApplicationContext(), AudioService.class);
            stopService(serviceIntent);
            /**SharedPreferences sharedPref2 = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor2=sharedPref2.edit();
            editor2.putInt("cancel_alarm_flag",0);
            editor2.apply();**/
        }

        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                    t1.setSpeechRate((float) 0.9);
                }
            }
        });


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        startAlert();

        //SharedPreferences pref2=getSharedPreferences("activation_data",MODE_PRIVATE);
        //int flag_value_new=pref2.getInt("activation_tv_flag",0);
        if (flag_value==1) {
            activation_layout.setVisibility(View.VISIBLE);
            layout1.setVisibility(View.GONE);
            SharedPreferences sharedPref1 = getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref1.edit();

            Calendar now = Calendar.getInstance(); // Get time now
            long differenceInMillis = now.getTimeInMillis() - activation_time;
            long differenceInHours = (differenceInMillis) / 1000L / 60L / 60L; // Divide by millis/sec, secs/min, mins/hr
            long differenceInMinutes = (differenceInMillis) / 1000L / 60L; // Divide by millis/sec, secs/min, mins/hr

                if (differenceInHours>=1) {
                activation_layout.setVisibility(View.GONE);
                layout1.setVisibility(View.VISIBLE);
                flag = 0;
                editor.putInt("activation_tv_flag", flag);
                editor.putInt("message_count1", 0);
                editor.apply();
            }
        } else if (flag_value == 0) {
            activation_layout.setVisibility(View.GONE);
            layout1.setVisibility(View.VISIBLE);
        }


        if (switch_state2) {
           // new SetupTask(this).execute();
        }

        SharedPreferences sharedPref_special = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
        int special_flag=sharedPref_special.getInt("voice_service_flag",10);
        if (special_flag==0 || special_flag==1 || special_flag==2 || special_flag==4 || special_flag==5){
            pos=special_flag;
            activation();
            SharedPreferences pref = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = pref.edit();
            edit.putInt("voice_service_flag",10);
            edit.apply();
        }

        else if (special_flag==3){
            pos=3;
            sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt("pos", pos);
            editor.apply();
            SharedPreferences pref = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = pref.edit();
            edit.putInt("voice_service_flag",10);
            edit.apply();
            activation_crime();
        }

        accident_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos=0;
                activation();
            }
        });
        fire_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos=1;
                activation();
            }
        });
        medic_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos=2;
                activation();
            }
        });
        crime_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos=3;
                activation_crime();
            }
        });
        disaster_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos=4;
                activation();
            }
        });
        alert_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pos=5;
                activation();
            }
        });

        mute_activation_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp!=null) mp.stop();
                SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putInt("play_alert_tone_flag",0);
                editor.apply();
                Intent serviceIntent = new Intent(getApplicationContext(), AudioService.class);
                stopService(serviceIntent);
            }
        });
        cancel_activation_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle(getString(R.string.safety_deactivation));
                builder.setMessage(getString(R.string.enter_deactivation_pin));
                builder.setCancelable(true);
                builder.setIcon(R.drawable.ic_lock_black_24dp);
                LinearLayout container = new LinearLayout(MainActivity.this);
                container.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(60, 0, 60, 20);
                input = new EditText(MainActivity.this);
                input.setLayoutParams(lp);
                input.setGravity(Gravity.CENTER);
                InputFilter[] FilterArray = new InputFilter[1];
                FilterArray[0] = new InputFilter.LengthFilter(4);
                input.setFilters(FilterArray);
                input.setInputType(InputType.TYPE_CLASS_PHONE);
                input.requestFocus();
                container.addView(input);
                builder.setView(container);
                builder.setPositiveButton(getString(R.string.deactivate), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        entered_password = input.getText().toString();
                        if (entered_password.equals(password)) {
                            input.setText("");
                            deactivation_dialog1.cancel();
                            CancelAlarm();
                            message_count = 0;
                            SharedPreferences sharedPref1 = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor1 = sharedPref1.edit();
                            editor1.putInt("activation_tv_flag", 0);
                            editor1.putInt("message_count", 0);
                            editor1.putInt("cancel_alarm_flag", 1);
                            editor1.putInt("play_alert_tone_flag",0);
                            if (pos==3) editor1.putInt("crime_activation_voice",0);
                            editor1.apply();
                            Intent serviceIntent = new Intent(getApplicationContext(), AudioService.class);
                            stopService(serviceIntent);
                            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                        } else {
                            Toast.makeText(getApplicationContext(), R.string.incorrect_pin, Toast.LENGTH_LONG).show();
                        }
                    }
                });
                builder.setNegativeButton(getString(R.string.close), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                deactivation_dialog1 = builder.create();
                deactivation_dialog1.show();
                deactivation_dialog1.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
                deactivation_dialog1.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            }
        });


        share_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPref=getSharedPreferences(FileName,MODE_PRIVATE);
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String message=sharedPref.getString("message_to_share",null);
                if (message!=null) {
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(sharingIntent, "Share via"));
                }
                else{
                    Toast.makeText(getApplicationContext(), R.string.share_message_not_received, Toast.LENGTH_LONG).show();
                }
            }
        });
        activation_call_police.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(police);
            }
        });
        activation_call_fire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(fire);
            }
        });
        activation_call_ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(ambulance);
            }
        });

        if (!contact_name1.equals("")) {
            activation_call_contact1.setText(contact_name1);
            activation_call_contact1.setVisibility(View.VISIBLE);
            activation_call_contact1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    call(phoneNo1);
                }
            });
        }
        if (!contact_name2.equals("")) {
            activation_call_contact2.setText(contact_name2);
            activation_call_contact2.setVisibility(View.VISIBLE);
            activation_call_contact2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    call(phoneNo2);
                }
            });
        }
        if (!contact_name3.equals("")) {
            activation_call_contact3.setText(contact_name3);
            activation_call_contact3.setVisibility(View.VISIBLE);
            activation_call_contact3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    call(phoneNo3);
                }
            });
        }

        SharedPreferences sharedPref1 = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref1.edit();
        editor.putInt("pos", pos);
        editor.apply();

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS,Manifest.permission.RECEIVE_SMS, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,Manifest.permission.READ_SMS}, SMS_PERMISSION_CONSTANT);
            SharedPreferences.Editor editor1 = permissionStatus.edit();
            editor1.putBoolean(Manifest.permission.SEND_SMS, true);
            editor1.putBoolean(Manifest.permission.RECEIVE_SMS, true);
            editor1.putBoolean(Manifest.permission.READ_SMS, true);
            editor1.putBoolean(Manifest.permission.ACCESS_FINE_LOCATION, true);
            editor1.putBoolean(Manifest.permission.RECORD_AUDIO, true);
            editor1.putBoolean(Manifest.permission.CALL_PHONE, true);
            editor1.apply();
        }


        if (!isGooglePlayServicesAvailable()) {
            acquireGooglePlayServices();
        }
        }

    private void acquireGooglePlayServices() {
        GoogleApiAvailability apiAvailability =
                GoogleApiAvailability.getInstance();
        final int connectionStatusCode =
                apiAvailability.isGooglePlayServicesAvailable(this);
        if (apiAvailability.isUserResolvableError(connectionStatusCode)) {
            showGooglePlayServicesAvailabilityErrorDialog(connectionStatusCode);
        }
    }
    void showGooglePlayServicesAvailabilityErrorDialog(
            final int connectionStatusCode) {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        Dialog dialog = apiAvailability.getErrorDialog(
                MainActivity.this,
                connectionStatusCode,
                REQUEST_GOOGLE_PLAY_SERVICES);
        dialog.show();
    }

    @SuppressLint("MissingPermission")
    public void call(String number) {
        String uri = "tel:" + number;
        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(uri));
        startActivity(callIntent);
         }
    private PendingIntent createOnDismissedIntent(Context context, int notificationId) {
        Intent intent = new Intent(context, NotificationDismissedReceiver.class);
        intent.putExtra("com.siriussoftwares.safety.notificationId", notificationId);

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(context.getApplicationContext(),
                        notificationId, intent, 0);
        return pendingIntent;
    }
    public void notifications() {
        showNotification(17,"Country",address6);
        showNotification(16,"Postal Code",address5);
        showNotification(15,"County/State",address4);
        showNotification(14,"City/Town/Village",address3);
        showNotification(13,"Street Name/Number",address2);
        showNotification(12,"House Name/Number",address1);
        showNotification(11, "Gender", gender);
        showNotification(10, "Date of Birth", date_of_birth);
        showNotification(9,"Additional Medical Information",medical_info5);
        showNotification(8,"Allergies",medical_info4);
        showNotification(7,"Chronic Medical Conditions",medical_info3);
        showNotification(6,"Current Medication Name & Doses",medical_info2);
        showNotification(5,"Blood Group",medical_info1);
        showNotification(4, "Emergency Contact-3", contact_name3 + "  " + phoneNo3);
        showNotification(3, "Emergency Contact-2", contact_name2 + "  " + phoneNo2);
        showNotification(2, "Emergency Contact-1", contact_name1 + "  " + phoneNo1);
        showNotification(1, "Name", myFirstName + " "+myLastName);
        showNotification(0,"Emergency Information","16 notifications available. Swipe noted notifications to view rest.");
        showNotification1(100, "Mute Alert", "Swipe this notification to mute alert sound.");
    }

    public void activation() {
        if (phoneNo1.equals("") && phoneNo2.equals("") && phoneNo3.equals("")){
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
            builder1.setTitle(R.string.setup_incomplete);
            builder1.setIcon(R.drawable.ic_warning_black_24dp);
            builder1.setMessage(R.string.setup_incomplete_desc);
            builder1.setCancelable(true);
            builder1.setPositiveButton(
                    R.string.ok,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            final AlertDialog alert_dialog1 = builder1.create();
            alert_dialog1.show();
        }
        else {
            if (!isOnline()) {
                wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifiManager.setWifiEnabled(TRUE);
            }
            SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt("message_type", 1);
            editor.apply();
            if (alarmTone2 != null) {
                Uri uri = Uri.parse(alarmTone2);
                ringtone1 = RingtoneManager.getRingtone(getApplicationContext(), uri);
                timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        ringtone1.play();
                    }
                }, 0, 1000);
            } else {
                mp = MediaPlayer.create(getApplicationContext(), R.raw.emergency_tone);
                mp.setLooping(true);
                mp.start();
            }
            v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(deactivation_time, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(deactivation_time);
                }
            }

            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.safety_deactivation));
            builder.setCancelable(true);
            builder.setIcon(R.drawable.ic_lock_black_24dp);
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(60, 0, 60, 20);
            input = new EditText(MainActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.CENTER);
            InputFilter[] FilterArray = new InputFilter[1];
            FilterArray[0] = new InputFilter.LengthFilter(4);
            input.setFilters(FilterArray);
            input.setInputType(InputType.TYPE_CLASS_PHONE);
            input.requestFocus();
            container.addView(input);
            builder.setView(container);
            builder.setPositiveButton(R.string.deactivate, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                }
            });
            builder.setNegativeButton(R.string.close, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                    if (mp != null) mp.stop();
                    if (timer != null) timer.cancel();
                    if (ringtone1 != null) ringtone1.stop();
                    if (countDownTimer != null) countDownTimer.cancel();
                    if (v != null) v.cancel();
                    notifications();
                    new SetupTask(MainActivity.this).execute();
                    call_flag = 1;
                    if (pos == 0) {
                        t1.speak("Safety Activated. Do you want to call ambulance?", TextToSpeech.QUEUE_FLUSH, null);
                    } else if (pos == 1) t1.speak("Safety Activated. Do you want to call fire and rescue service?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 2) t1.speak("Safety Activated. Do you want to call ambulance?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 4) t1.speak("Safety Activated. Do you want to call fire and rescue service?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 5) t1.speak("Safety Activated. Do you want to call police?", TextToSpeech.QUEUE_FLUSH, null);
                    activation_layout.setVisibility(View.VISIBLE);
                    layout1.setVisibility(View.GONE);
                    final SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putInt("activation_tv_flag", 1);
                    editor.putInt("call_flag", 1);
                    editor.putInt("activation_type", 1);
                    editor.putInt("pos", pos);
                    editor.putInt("message_count",0);
                    Date date = new Date(System.currentTimeMillis());
                    editor.putLong("activation_time", date.getTime());
                    editor.putInt("play_alert_tone_flag", 1);
                    editor.apply();
                    /**SharedPreferences sharedPref2 = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
                     SharedPreferences.Editor editor2 = sharedPref2.edit();
                     editor2.putInt("activation_tv_flag",1);
                     editor2.apply();**/
                    startActivation();
                    Intent playbackServiceIntent = new Intent(getApplicationContext(), AudioService.class);
                    startService(playbackServiceIntent);
                    Handler mHandler = new Handler();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            call_flag = 0;
                            SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                            SharedPreferences.Editor editor1 = sharedPreferences.edit();
                            editor1.putInt("call_flag", 0);
                            editor1.apply();
                        }
                    }, 60000);
                }
            });
            deactivation_dialog = builder.create();
            deactivation_dialog.show();
            deactivation_dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
            deactivation_dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            deactivation_dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    entered_password = input.getText().toString();
                    if (entered_password.equals(password)) {
                        input.setText("");
                        deactivation_dialog.dismiss();
                        //if (v != null) v.cancel();
                        if (mp != null) mp.stop();
                        if (timer != null) timer.cancel();
                        if (ringtone1 != null) ringtone1.stop();
                        Toast.makeText(getApplicationContext(), R.string.safety_deactivated, Toast.LENGTH_LONG).show();
                        if (countDownTimer != null) countDownTimer.cancel();
                    } else {
                        dialog_flag = 1;
                        Toast.makeText(getApplicationContext(), R.string.incorrect_pin, Toast.LENGTH_LONG).show();
                        input.setText("");
                    }
                }
            });
            countDownTimer = new CountDownTimer(deactivation_time, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    deactivation_dialog.setMessage(getString(R.string.enter_pin_within) + (millisUntilFinished / 1000) + "s");
                }

                @Override
                public void onFinish() {
                    deactivation_dialog.cancel();
                    if (mp != null) mp.stop();
                    if (ringtone1 != null) ringtone1.stop();
                    if (timer != null) timer.cancel();
                    notifications();
                    call_flag = 1;
                    if (pos == 0) t1.speak("Safety Activated. Do you want to call ambulance?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 1) t1.speak("Safety Activated. Do you want to call fire and rescue service?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 2) t1.speak("Safety Activated. Do you want to call ambulance?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 4) t1.speak("Safety Activated. Do you want to call fire and rescue service?", TextToSpeech.QUEUE_FLUSH, null);
                    else if (pos == 5) t1.speak("Safety Activated. Do you want to call police?", TextToSpeech.QUEUE_FLUSH, null);
                    activation_layout.setVisibility(View.VISIBLE);
                    layout1.setVisibility(View.GONE);
                    SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putInt("activation_tv_flag", 1);
                    editor.putInt("call_flag", call_flag);
                    editor.putInt("activation_type", 1);
                    editor.putInt("pos", pos);
                    editor.putInt("message_count",0);
                    Date date = new Date(System.currentTimeMillis());
                    editor.putLong("activation_time", date.getTime());
                    editor.putInt("play_alert_tone_flag", 1);
                    editor.apply();
                    /**SharedPreferences sharedPref2 = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
                     SharedPreferences.Editor editor2 = sharedPref2.edit();
                     editor2.putInt("activation_tv_flag",1);
                     editor2.apply();**/
                    startActivation();
                    Intent playbackServiceIntent = new Intent(getApplicationContext(), AudioService.class);
                    startService(playbackServiceIntent);
                    Handler mHandler = new Handler();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            call_flag = 0;
                            SharedPreferences sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
                            SharedPreferences.Editor editor1 = sharedPreferences.edit();
                            editor1.putInt("call_flag", 0);
                            editor1.apply();
                        }
                    }, 60000);
                }
            }.start();
        }
}

    public void activation_crime() {
        if (phoneNo1.equals("") && phoneNo2.equals("") && phoneNo3.equals("")){
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
            builder1.setTitle(getString(R.string.setup_incomplete));
            builder1.setIcon(R.drawable.ic_warning_black_24dp);
            builder1.setMessage(getString(R.string.setup_incomplete_desc));
            builder1.setCancelable(true);
            builder1.setPositiveButton(
                    R.string.ok,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            final AlertDialog alert_dialog1 = builder1.create();
            alert_dialog1.show();
        }
        else {
            if (!isOnline()) {
                wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                wifiManager.setWifiEnabled(TRUE);
            }
            SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt("message_type", 2);
            editor.apply();
            if (crime_activation_voice == 1) {
                if (alarmTone2 != null) {
                    Uri uri = Uri.parse(alarmTone2);
                    ringtone1 = RingtoneManager.getRingtone(getApplicationContext(), uri);
                    timer = new Timer();
                    timer.scheduleAtFixedRate(new TimerTask() {
                        @Override
                        public void run() {
                            ringtone1.play();
                        }
                    }, 0, 1000);
                } else {
                    mp = MediaPlayer.create(getApplicationContext(), R.raw.emergency_tone);
                    mp.setLooping(true);
                    mp.start();
                }
                /** v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                 if (v != null) {
                 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                 v.vibrate(VibrationEffect.createOneShot(deactivation_time, VibrationEffect.DEFAULT_AMPLITUDE));
                 } else {
                 v.vibrate(deactivation_time);
                 }
                 }**/
            }

            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.safety_deactivation));
            builder.setCancelable(true);
            builder.setIcon(R.drawable.ic_lock_black_24dp);
            LinearLayout container = new LinearLayout(this);
            container.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(60, 0, 60, 20);
            input = new EditText(MainActivity.this);
            input.setLayoutParams(lp);
            input.setGravity(Gravity.CENTER);
            InputFilter[] FilterArray = new InputFilter[1];
            FilterArray[0] = new InputFilter.LengthFilter(4);
            input.setFilters(FilterArray);
            input.setInputType(InputType.TYPE_CLASS_PHONE);
            input.requestFocus();
            container.addView(input);
            builder.setView(container);
            builder.setPositiveButton(R.string.deactivate, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {

                }
            });
            builder.setNegativeButton(R.string.close, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                    if (mp != null) mp.stop();
                    if (timer != null) timer.cancel();
                    if (ringtone1 != null) ringtone1.stop();
                    if (countDownTimer != null) countDownTimer.cancel();
                    notifications();
                    SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putInt("activation_type", 2);
                    Date date = new Date(System.currentTimeMillis());
                    editor.putLong("activation_time", date.getTime());
                    if (crime_activation_voice==1) editor.putInt("play_alert_tone_flag", 1);
                    editor.apply();
                    /**SharedPreferences sharedPref2 = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
                     SharedPreferences.Editor editor2 = sharedPref2.edit();
                     editor2.putInt("activation_tv_flag",1);
                     editor2.apply();**/
                    if (crime_activation_voice == 1) {
                        Intent playbackServiceIntent = new Intent(getApplicationContext(), AudioService.class);
                        startService(playbackServiceIntent);
                    }
                    Intent myIntent = new Intent(MainActivity.this, CrimeSelection.class);
                    MainActivity.this.startActivity(myIntent);
                }
            });
            deactivation_dialog = builder.create();
            deactivation_dialog.show();
            deactivation_dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
            deactivation_dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            deactivation_dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    entered_password = input.getText().toString();
                    if (entered_password.equals(password)) {
                        input.setText("");
                        deactivation_dialog.dismiss();
                        //if (v != null) v.cancel();
                        if (mp != null) mp.stop();
                        if (timer != null) timer.cancel();
                        if (ringtone1 != null) ringtone1.stop();
                        Toast.makeText(getApplicationContext(), R.string.safety_deactivated, Toast.LENGTH_LONG).show();
                        if (countDownTimer != null) countDownTimer.cancel();
                        if (crime_activation_voice==1){
                            SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
                            SharedPreferences.Editor editor1=sharedPreferences.edit();
                            editor1.putInt("crime_activation_voice",0);
                            editor1.apply();
                        }
                    } else {
                        dialog_flag = 1;
                        Toast.makeText(getApplicationContext(), R.string.incorrect_pin, Toast.LENGTH_LONG).show();
                        input.setText("");
                    }
                }
            });
            countDownTimer = new CountDownTimer(deactivation_time, deactivation_time) {
                @Override
                public void onTick(long millisUntilFinished) {
                    deactivation_dialog.setMessage(getString(R.string.enter_pin_within) + (millisUntilFinished / 1000) + "s");
                }

                @Override
                public void onFinish() {
                    deactivation_dialog.cancel();
                    if (mp != null) mp.stop();
                    if (ringtone1 != null) ringtone1.stop();
                    if (timer != null) timer.cancel();
                    if (timer1 != null) timer1.cancel();
                    notifications();
                    SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putInt("activation_type", 2);
                    Date date = new Date(System.currentTimeMillis());
                    editor.putLong("activation_time", date.getTime());
                    if (crime_activation_voice==1) editor.putInt("play_alert_tone_flag", 1);
                    editor.apply();
                    /**SharedPreferences sharedPref2 = getSharedPreferences("activation_data", Context.MODE_PRIVATE);
                     SharedPreferences.Editor editor2 = sharedPref2.edit();
                     editor2.putInt("activation_tv_flag",1);
                     editor2.apply();**/
                    if (crime_activation_voice == 1) {
                        Intent playbackServiceIntent = new Intent(getApplicationContext(), AudioService.class);
                        startService(playbackServiceIntent);
                    }
                    Intent myIntent = new Intent(MainActivity.this, CrimeSelection.class);
                    MainActivity.this.startActivity(myIntent);
                }
            }.start();
        }
    }

    public void startAlert(){
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this.getApplicationContext(), 10, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(),60000, pendingIntent);
    }
    public void startActivation(){
        Intent intent = new Intent(this, ActivationReceiver.class);
        PendingIntent pendingIntent3 = PendingIntent.getBroadcast(
                this.getApplicationContext(), 10, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(),60000, pendingIntent3);
    }
    public void CancelAlarm() {
        Intent intent = new Intent(this, ActivationReceiver.class);
        PendingIntent sender = PendingIntent.getBroadcast(this.getApplicationContext(), 10, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.cancel(sender);
    }
    public void shared_values() {
        SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        String defaultValue = "";
        myFirstName = sharedPref.getString("name1", defaultValue);
        myLastName = sharedPref.getString("name2", defaultValue);
        myMailid = sharedPref.getString("mail", defaultValue);
        gender = sharedPref.getString("gender", defaultValue);
        date_of_birth = sharedPref.getString("dob", defaultValue);
        address1= sharedPref.getString("address1","Not Available");
        address2= sharedPref.getString("address2","Not Available");
        address3= sharedPref.getString("address3","Not Available");
        address4= sharedPref.getString("address4","Not Available");
        address5= sharedPref.getString("address5","Not Available");
        address6= sharedPref.getString("address6","Not Available");
        medical_info1= sharedPref.getString("medical_info1","Not Available");
        medical_info2= sharedPref.getString("medical_info2","Nil");
        medical_info3= sharedPref.getString("medical_info3","Nil");
        medical_info4= sharedPref.getString("medical_info4","Nil");
        medical_info5= sharedPref.getString("medical_info5","Nil");
        phoneNo1 = sharedPref.getString("contact_number1", defaultValue);
        phoneNo2 = sharedPref.getString("contact_number2", defaultValue);
        phoneNo3 = sharedPref.getString("contact_number3", defaultValue);
        mailid1 = sharedPref.getString("contact_mail1", defaultValue);
        mailid2 = sharedPref.getString("contact_mail2", defaultValue);
        mailid3 = sharedPref.getString("contact_mail3", defaultValue);
        contact_name1 = sharedPref.getString("contact_name1", defaultValue);
        contact_name2 = sharedPref.getString("contact_name2", defaultValue);
        contact_name3 = sharedPref.getString("contact_name3", defaultValue);
        switch_state2 = sharedPref.getBoolean("switch2", true);
        password = sharedPref.getString("password", "");
        flag_value = sharedPref.getInt("activation_tv_flag", 0);
        flag_value1 = sharedPref.getInt("activation_tv_flag1", 0);
        cancel_alarm_flag = sharedPref.getInt("cancel_alarm_flag", 0);
        message_count = sharedPref.getInt("message_count", 0);
        message_count1 = sharedPref.getInt("message_count1", 0);
        alarmTone1 = sharedPref.getString("ringtone1", null);
        alarmTone2 = sharedPref.getString("ringtone2", null);
        alarmTone3 = sharedPref.getString("ringtone3", null);
        activation_time=sharedPref.getLong("activation_time",0);
        police = sharedPref.getString("police", defaultValue);
        ambulance = sharedPref.getString("ambulance", defaultValue);
        fire = sharedPref.getString("fire", defaultValue);
        pos=sharedPref.getInt("pos",10);
        notification_message=sharedPref.getString("notification_message",null);
        notification_title=sharedPref.getString("notification_title",null);
        crime_activation_voice=sharedPref.getInt("crime_activation_voice",0);
        activation_warning_flag=sharedPref.getInt("activation_warning_flag",0);
        deactivation_time_seconds=sharedPref.getString("deactivation_time_seconds","10000");

    }

    @Override
    public void onRestart() {
        super.onRestart();
        shared_values();
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_setup) {
            Intent intent1 = new Intent(this, SetupActivity.class);
            startActivity(intent1);
            return true;
        }
        else if (id==R.id.action_settings){
            Intent intent2 = new Intent(this, SettingsActivity.class);
            startActivity(intent2);
            return true;
        }
        else if (id==R.id.action_disaster_alerts){
            Intent intent2 = new Intent(this, DisasterAlert.class);
            startActivity(intent2);
            return true;
        }
        else if (id==R.id.action_received_alerts){
            Intent intent2 = new Intent(this, IncomingAlert.class);
            startActivity(intent2);
            return true;
        }
        else if (id==R.id.action_track_location){
            Intent intent2 = new Intent(this, TrackLocationActivity.class);
            startActivity(intent2);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_setup) {
            Intent intent1 = new Intent(this, SetupActivity.class);
            startActivity(intent1);
            }

        if (id == R.id.nav_settings) {
            Intent intent1 = new Intent(this, SettingsActivity.class);
            startActivity(intent1);
        }
        if (id == R.id.nav_notifications) {
            Intent intent1 = new Intent(this, IncomingAlert.class);
            startActivity(intent1);
        }
        if (id == R.id.nav_disaster_alert) {
           Intent intent1 = new Intent(this, DisasterAlert.class);
           startActivity(intent1);
        }
        if (id == R.id.nav_track_location) {
            Intent intent1 = new Intent(this, TrackLocationActivity.class);
            startActivity(intent1);
        }
        if (id == R.id.nav_about) {
            Intent intent1 = new Intent(this, AboutActivity.class);
            startActivity(intent1);
        }
        if (id==R.id.nav_donate){
            String url= "https://www.siriussoftwares.com";
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(browserIntent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    private boolean isGooglePlayServicesAvailable() {
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            Toast.makeText(getApplicationContext(), R.string.google_play_not_available, Toast.LENGTH_LONG).show();
            GooglePlayServicesUtil.getErrorDialog(status, this, 0).show();
            return false;
        }
    }

      public boolean isOnline() {
      ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
      NetworkInfo netInfo = cm.getActiveNetworkInfo();
      if (netInfo != null && netInfo.isConnectedOrConnecting()) {
      return true;
      } else {
      return false;
      }
      }

    @SuppressLint("RestrictedApi")
    public void showNotification(int id,String title,String value) {
        NotificationCompat.Builder mBuilder = null;
        mBuilder = new NotificationCompat.Builder(this)
                .setContentTitle(title)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setChannelId("emergency_information_notifications")
                .setStyle(new NotificationCompat.BigTextStyle().bigText(value))
                .setGroup("emergency_information_group")
                .setContentText(value);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(id, mBuilder.build());
        }


    public void showNotification1(int id,String title,String value) {
        NotificationCompat.Builder mBuilder = null;
        mBuilder = new NotificationCompat.Builder(this)
                .setAutoCancel(false)
                .setContentTitle(title)
                .setPriority(2)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setDeleteIntent(createOnDismissedIntent(this, id))
                .setStyle(new NotificationCompat.BigTextStyle().bigText(value))
                .setContentText(value);

            NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.notify(id, mBuilder.build());
        }

    private static class SetupTask extends AsyncTask<Void, Void, Exception> {
        WeakReference<MainActivity> activityReference;

        SetupTask(MainActivity activity) {
            this.activityReference = new WeakReference<>(activity);
        }

        @Override
        protected Exception doInBackground(Void... params) {
            try {
                Assets assets = new Assets(activityReference.get());
                File assetDir = assets.syncAssets();
                activityReference.get().setupRecognizer(assetDir);
            } catch (IOException e) {
                return e;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Exception result) {
            if (result != null) {

            } else {
                activityReference.get().switchSearch(KWS_SEARCH);
            }
        }
    }





@Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                new SetupTask(this).execute();
            }
        }
    }

    private boolean isMyServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (VoiceService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.shutdown();
        }
    }


    @Override
    public void onPartialResult(Hypothesis hypothesis) {
        if (hypothesis == null)
            return;
        String text = hypothesis.getHypstr();
        if (text.equals("yes")){
            SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
            call_flag = sharedPref.getInt("call_flag",0);
            call_flag1 = sharedPref.getInt("call_flag1",0);
            if (call_flag==1 || call_flag1==1) {
                if (pos==0 || pos==2) {
                    t1.speak("Calling ambulance..", TextToSpeech.QUEUE_FLUSH, null);
                    call(ambulance);
                }
                else if (pos==1 || pos==4) {
                    t1.speak("Calling fire and rescue..", TextToSpeech.QUEUE_FLUSH, null);
                    call(fire);
                }
                else if (pos==5) {
                    t1.speak("Calling police..", TextToSpeech.QUEUE_FLUSH, null);
                    call(police);
                }
                call_flag = 0;
                call_flag1 = 0;
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putInt("call_flag",0);
                editor.putInt("call_flag1",0);
                editor.apply();
            }
            }

        switchSearch(KWS_SEARCH);
    }
    @Override
    public void onResult(Hypothesis hypothesis) {

    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onEndOfSpeech() {
        if (!recognizer.getSearchName().equals(KWS_SEARCH))
            switchSearch(KWS_SEARCH);
    }

    public void switchSearch(String searchName) {
        recognizer.stop();
        recognizer.startListening(searchName);
    }

    public void setupRecognizer(File assetsDir) throws IOException {
        recognizer = SpeechRecognizerSetup.defaultSetup()
                .setAcousticModel(new File(assetsDir, "en-us-ptm"))
                .setDictionary(new File(assetsDir, "cmudict-en-us.dict"))
                .getRecognizer();
        recognizer.addListener(this);

        try {
            FileOutputStream fileout=openFileOutput("threshold.list", MODE_PRIVATE);
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);
            outputWriter.write("accident accident/1e-40/\n" + "fire fire/0.5/\n" + "medic medic/1e-20/\n" + "crime crime/1e-20/\n" + "disaster disaster/1e-40/\n" + "alert alert/1e-10/\n" + "yes/0.5/");
            outputWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        File file1 = new File(getApplicationContext().getFilesDir(), "threshold.list");
        recognizer.addKeywordSearch(KWS_SEARCH, file1);

    }

    @Override
    public void onError(Exception error) {
    }

    @Override
    public void onTimeout() {
        switchSearch(KWS_SEARCH);
    }

   /** public void play_sound(){
        mp = MediaPlayer.create(this, R.raw.emergency_tone);
        if (alarmTone2!=null) {
            Uri uri = Uri.parse(alarmTone2);
            ringtone1 = RingtoneManager.getRingtone(getApplicationContext(), uri);
            final Timer timer = new Timer();
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    ringtone1.play();
                }
            }, 0, 1000);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (ringtone1!=null)ringtone1.stop();
                    timer.cancel();
                }
            }, 10000);
        }
        else {
            mp=MediaPlayer.create(getApplicationContext(),R.raw.emergency_tone);
            final Timer timer1 = new Timer();
            timer1.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    mp.start();
                }
            }, 0, 1000);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    timer1.cancel();
                    mp.stop();
                }
            }, 10000);
        }
    }**/
    private void createNotificationChannel(String channel_name,String channel_id, int importance,String description,Boolean dnd) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channel_id, channel_name, importance);
            if (!description.equals(""))channel.setDescription(description);
            channel.setBypassDnd(dnd);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            NotificationManager notificationManager =getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
