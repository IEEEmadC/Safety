package com.siriussoftwares.safety;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AlertDialog;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;

import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;

import static java.lang.Boolean.TRUE;

public class ActivationReceiver extends BroadcastReceiver implements LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener {
    private boolean bound = false;
    public String phoneNo1, phoneNo2, phoneNo3, myFirstName, myLastName, myMailid,medical_info,date_of_birth,myPhoneNo,gender,contact_name1,contact_name2,contact_name3;
    public String message, cityName, addressline,emergency_message,sharemsg,his_or_her;
    public String address1,address2,address3,address4,address5,address6,medical_info1,medical_info2,medical_info3,medical_info4,medical_info5;
    public String mailmsg,mailid1,mailid2,mailid3;
    public int emergency_type,common_flag;
    public String police,ambulance,fire;
    public LinearLayout layout1, activation_layout;
    public int pos,pos1,activation_type, i,autostart_flag, flag, flag_value, flag_value1, message_count, message_count1,voice_service_flag;
    public Boolean switch_state2;
    public String city,address;
    MediaPlayer mp,mp1;
    Uri uri;
    Vibrator v;
    Context update_context;
    long activation_time;
    public Ringtone ringtone1;
    public String alarmTone1,alarmTone2,alarmTone3;
    public TextView activation_tv;
    public String FileName = "data";
    SharedPreferences permissionStatus;
    private boolean sentToSettings = false;
    private static final int SMS_PERMISSION_CONSTANT = 100;
    private static final String TAG = "LocationActivity";
    private static final long EXPIRY_DURATION = 1000 * 3000;
    private static final long INTERVAL = 1000 * 240 ;
    EditText input;
    AlertDialog deactivation_dialog,autostart_dialog;

    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;
    Location mCurrentLocation;
    String mLastUpdateTime;


    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        shared_values(context);

        if (gender.equalsIgnoreCase("male")){
             his_or_her="his";
        }
        else if (gender.equalsIgnoreCase("female")){
             his_or_her="her";
        }
        else{
             his_or_her="his or her";
        }


       mGoogleApiClient = new GoogleApiClient.Builder(context).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
        createLocationRequest();
        mGoogleApiClient.connect();
        update_context=context;
        }

    public void shared_values(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences(FileName, Context.MODE_PRIVATE);
        String defaultValue = "";
        myFirstName = sharedPref.getString("name1", defaultValue);
        myLastName = sharedPref.getString("name2", defaultValue);
        myMailid = sharedPref.getString("mail", defaultValue);
        myPhoneNo = sharedPref.getString("phone", defaultValue);
        gender = sharedPref.getString("gender", defaultValue);
        date_of_birth = sharedPref.getString("dob", defaultValue);
        address1= sharedPref.getString("address1","Not Available");
        address2= sharedPref.getString("address2","Not Available");
        address3= sharedPref.getString("address3","Not Available");
        address4= sharedPref.getString("address4","Not Available");
        address5= sharedPref.getString("address5","Not Available");
        address6= sharedPref.getString("address6","Not Available");
        medical_info1= sharedPref.getString("medical_info1","Not Available");
        medical_info2= sharedPref.getString("medical_info2","Nil");
        medical_info3= sharedPref.getString("medical_info3","Nil");
        medical_info4= sharedPref.getString("medical_info4","Nil");
        medical_info5= sharedPref.getString("medical_info5","Nil");
        phoneNo1 = sharedPref.getString("contact_number1", defaultValue);
        phoneNo2 = sharedPref.getString("contact_number2", defaultValue);
        phoneNo3 = sharedPref.getString("contact_number3", defaultValue);
        mailid1 = sharedPref.getString("contact_mail1", defaultValue);
        mailid2 = sharedPref.getString("contact_mail2", defaultValue);
        mailid3 = sharedPref.getString("contact_mail3", defaultValue);
        police = sharedPref.getString("police", defaultValue);
        ambulance = sharedPref.getString("ambulance", defaultValue);
        fire = sharedPref.getString("fire", defaultValue);
        contact_name1 = sharedPref.getString("contact_name1", defaultValue);
        contact_name2 = sharedPref.getString("contact_name2", defaultValue);
        contact_name3 = sharedPref.getString("contact_name3", defaultValue);
        switch_state2 = sharedPref.getBoolean("switch2", true);
        flag_value = sharedPref.getInt("activation_tv_flag", 0);
        flag_value1 = sharedPref.getInt("activation_tv_flag1", 0);
        message_count = sharedPref.getInt("message_count", 0);
        message_count1 = sharedPref.getInt("message_count1", 0);
        voice_service_flag= sharedPref.getInt("voice_service_flag", 10);
        autostart_flag=sharedPref.getInt("autostart_flag", 0);
        alarmTone1 = sharedPref.getString("ringtone1", null);
        alarmTone2 = sharedPref.getString("ringtone2", null);
        alarmTone3 = sharedPref.getString("ringtone3", null);
        activation_time=sharedPref.getLong("activation_time",0);
        pos=sharedPref.getInt("pos",5);
        pos1=sharedPref.getInt("pos1",8);
        activation_type=sharedPref.getInt("activation_type",0);

    }

    public void SendMessage(Context context,String phoneNo, String msg,String name) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(msg);
            smsManager.sendMultipartTextMessage(phoneNo, null, parts,
                    null, null);
            Toast.makeText(context, "Message sent to "+name, Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(context, "Unable to send message to "+name, Toast.LENGTH_SHORT).show();
            ex.printStackTrace();
        }
    }

    protected void startLocationUpdates() {
        @SuppressLint("MissingPermission") com.google.android.gms.common.api.PendingResult<Status> pendingResult = LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
    }
    @Override
    public void onConnected(Bundle bundle) {
        startLocationUpdates();
    }


    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
    }

    @Override
    public void onLocationChanged(Location location) {
        mCurrentLocation = location;
        mLastUpdateTime = DateFormat.getTimeInstance().format(new Date());
        if (activation_type==1) {
            updateUI(update_context);
        }
        else if (activation_type==2){
            updateUI1(update_context);
        }
    }

    public void updateUI(Context context) {
        shared_values(context);
        if (null != mCurrentLocation) {
            String lat = String.valueOf(mCurrentLocation.getLatitude());
            String lng = String.valueOf(mCurrentLocation.getLongitude());
            Double lat1 = mCurrentLocation.getLatitude();
            Double lng1 = mCurrentLocation.getLongitude();
            Geocoder gcd = new Geocoder(context.getApplicationContext(), Locale.getDefault());
            try {
                List<Address> addresses = gcd.getFromLocation(lat1, lng1, 1);//lat and lon is the latitude and longitude in double
                if (addresses.size() > 0) {
                    cityName = addresses.get(0).getLocality();
                    addressline = addresses.get(0).getAddressLine(0);
                }
            } catch (IOException e) {
            } catch (NullPointerException e) {
            }

            if (cityName != null && addressline!=null) {
                city=" at "+cityName;
                address=addressline+".";
            } else {
                city="";
                address="";
            }
            if (message_count == 0 && pos == 0) {
                message = myFirstName + " has met with an accident" +city + ".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + " has met with an accident"+city + " and requires your immediate help.\nLocation: " + address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " has met with an accident" +city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_type=1;
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Accident\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            } else if (message_count == 0 && pos == 1) {
                message = myFirstName + " is in a dangerous situation"+city + " and requires Fire & Rescue help\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + " is in a dangerous situation"+ city + " and is trying to call Fire & Rescue for help.\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is in a dangerous situation" + city + " and is trying to call Fire & Rescue for help.\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_type=2;
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Fire & Rescue\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            } else if (message_count == 0 && pos == 2) {
                message = myFirstName + " is facing a medical emergency" + city + "\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + " is facing a medical emergency" + city + " and requires your immediate help.\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing a medical emergency" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_type=3;
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Medical\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            } else if (message_count == 0 && pos == 4) {
                message = myFirstName + " is facing a disaster" + city + "\nLocation:" + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + " is facing a disaster" + city + " and requires your immediate help.\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing a disaster" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_type=2;
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Accident\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            } else if (message_count == 0 && pos == 5) {
                message = myFirstName + " is facing some problem" + city + " & needs public attention.\nLocation:" + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+".Please help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + " is facing some problems" + city + " and requires your immediate help.\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing some problems" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
            } else if (message_count == 1 || message_count == 2) {
                message = myFirstName+ "'s updated location:\n" + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng+" .";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + "'s updated location:\n" + address + ".\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
            } else if (message_count == 3) {
                message = myFirstName + "'s updated location:\n" + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\nThis was the last update,thanks for your help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n " + myFirstName + " " + myLastName + "'s updated location:\n" + address + ".\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nKindly note that this was the last update for this incident. We thank you for all your efforts and help.";
            }
            SendMessage(context,phoneNo1, message,contact_name1);
            SendMessage(context,phoneNo2, message,contact_name2);
            SendMessage(context,phoneNo3, message,contact_name3);
            if (emergency_type==1){
                SendMessage(context,police, emergency_message,"Police");
                SendMessage(context,ambulance, emergency_message,"Ambulance");
            }
            else if (emergency_type==2){
                SendMessage(context,fire,emergency_message,"Fire");
            }
            else if (emergency_type==3){
                SendMessage(context,ambulance,emergency_message,"Ambulance");
            }

            if (isOnline(context)) {
                new Thread() {
                    public void run() {
                        String sub = "Emergency Alert for " + myFirstName + " " + myLastName;
                        String body = mailmsg;
                        String send = myMailid;
                        String receive = mailid1 + "," + mailid2 + "," + mailid3;
                        try {
                            Sender sender = new Sender("alert.safetyapp@gmail.com", "pvtwcesliivgqaxz");
                            sender.sendMail(sub, body, send, receive);
                        } catch (Exception e) {
                        }
                    }
                }.start();
            }
            SharedPreferences sharedPref = context.getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            message_count += 1;
            editor.putInt("message_count", message_count);
            if (message_count==1) {
                editor.putString("message_to_share",sharemsg);
            }
            editor.apply();

            if (message_count == 4) {
                message_count = 0;
                SharedPreferences sharedPref1 = context.getSharedPreferences(FileName, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor1 = sharedPref1.edit();
                editor1.putInt("activation_tv_flag", 0);
                editor1.putInt("message_count", message_count);
                editor1.putInt("cancel_alarm_flag",1);
                editor1.apply();
                Intent i = new Intent(context,MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(i);            }
        }
    }

    private void updateUI1(Context context) {
        shared_values(context);
        if (null != mCurrentLocation) {
            String lat = String.valueOf(mCurrentLocation.getLatitude());
            String lng = String.valueOf(mCurrentLocation.getLongitude());
            Double lat1 = mCurrentLocation.getLatitude();
            Double lng1 = mCurrentLocation.getLongitude();
            Geocoder gcd = new Geocoder(context.getApplicationContext(), Locale.getDefault());
            try{
                List<Address> addresses = gcd.getFromLocation(lat1, lng1, 1);//lat and lon is the latitude and longitude in double
                if (addresses.size() > 0) {
                    cityName=addresses.get(0).getLocality();
                    addressline=addresses.get(0).getAddressLine(0);
                }
            }
            catch (IOException e) {}
            catch (NullPointerException e) {}
            if (cityName != null && addressline!=null) {
                city=" at "+cityName;
                address=addressline+".";
            } else {
                city="";
                address="";
            }

            if (message_count1==0 && pos1==0) {
                message = myFirstName+ " is facing some fraud" + city + ".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is affected by some kind of fraud" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is affected by some kind of fraud" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Fraud\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==1){
                message=myFirstName+" is facing kidnapping"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName +" is in a kidnapping situation"+city+" and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is in a kidnapping situation" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Kidnapping\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==2){
                message=myFirstName+" is facing domestic abuse"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing domestic abuse" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing domestic abuse" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Domestic Abuse\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==3) {
                message = myFirstName +" is facing rape" + city + ".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing a rape situation" + city+ " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing a rape situation" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Rape\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==4){
                message=myFirstName+" is facing sexual harassment"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing sexual harassment" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing sexual harassment" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Sexual Harassment\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==5){
                message=myFirstName+" is facing assault"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing an assault situation" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing an assault" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Assault\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==6){
                message=myFirstName+" is facing gang violence"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng + " .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing gang violence" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing gang vioence" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Gang Violence\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==7){
                message=myFirstName+" is facing robbery"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng +" .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing robbery" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing robbery" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Robbery\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if (message_count1==0 && pos1==8){
                message=myFirstName+" is facing a crime"+city+".\nLocation:\nhttps://www.google.com/maps/?q=" + lat + "," + lng +" .\n"+address+"Please inform police & help the victim.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + " is facing a crime situation" + city + " and requires your immediate help.\nLocation: "+address+ "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease inform police and take necessary actions at the earliest.\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
                sharemsg = "This is an emergency alert shared from Safety App.\n " + myFirstName + " " + myLastName + " is facing a crime situation" + city + ".\nLocation: " + address + "\nhttps://www.google.com/maps/?q=" + lat + "," + lng + "\nPlease don't try to call or message "+myFirstName+ " right now, as "+his_or_her+" device will be too busy doing emergency operations. If necessary, you may communicate with "+his_or_her+" closest contacts.";
                emergency_message="Name:"+myFirstName+myLastName+"\nType:Crime\nLocation:"+address+" https://www.google.com/maps/?q=" + lat + "," + lng+"\nICE:"+phoneNo1;
            }
            else if(message_count1==1 || message_count1==2){
                message=myFirstName+"'s updated location:\n"+address+"\nhttps://www.google.com/maps/?q=" + lat + "," + lng+" .";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + "'s updated location:"+address+".\nhttps://www.google.com/maps/?q=" + lat + "," + lng+"\nThank You.\n\nNote: Next location updates will be provided after 15 minutes.";
            }
            else if (message_count1==3){
                message=myFirstName+"'s updated location:\n"+address+"\nhttps://www.google.com/maps/?q=" + lat + "," + lng +" .\nThis was the last update,thanks for your help.";
                mailmsg = "This is an automated emergency alert from Safety App.\n "+myFirstName + " " + myLastName + "'s updated location:"+address+".\nhttps://www.google.com/maps/?q=" + lat + "," + lng+"\nKindly note that this was the last update for this incident. We thank you for all your efforts and help.";
            }

            SendMessage(context,phoneNo1, message,contact_name1);
            SendMessage(context,phoneNo2, message,contact_name2);
            SendMessage(context,phoneNo3, message,contact_name3);
            SendMessage(context,police,emergency_message,"Police");

            if (isOnline(context)) {
                new Thread() {
                    public void run() {
                        String sub = "Emergency Alert for " + myFirstName + " " + myLastName;
                        String body = mailmsg;
                        String send = myMailid;
                        String receive = mailid1 + "," + mailid2 + "," + mailid3;
                        try {
                            Sender sender = new Sender("alert.safetyapp@gmail.com", "#03SafetyAlert17/");
                            sender.sendMail(sub, body, send, receive);
                        } catch (Exception e) {
                            Log.e("SendMail", e.getMessage(), e);
                        }
                    }
                }.start();
            }

            message_count1+=1;
            SharedPreferences sharedPref = context.getSharedPreferences(FileName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPref.edit();
            editor.putInt("message_count1",message_count1);
            if (message_count1==1){
                editor.putString("message_to_share",sharemsg);
            }
            editor.apply();

            if (message_count1==4){
                message_count1=0;
                editor.putInt("message_count1",message_count1);
                editor.putString("timer1_text","");
                editor.putString("crime_selection_tv1_text","Select type of Crime ");
                editor.putInt("activation_tv_flag", 0);
                editor.putInt("cancel_alarm_flag",1);
                editor.apply();
                Intent i = new Intent(context,MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(i);
            }
        }

        else {
            Log.d(TAG, "location is null ...............");
        }

    }
    public boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
}
