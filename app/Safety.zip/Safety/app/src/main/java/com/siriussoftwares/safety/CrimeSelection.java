package com.siriussoftwares.safety;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.ref.WeakReference;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimerTask;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;
import edu.cmu.pocketsphinx.SpeechRecognizerSetup;

import static android.speech.tts.TextToSpeech.QUEUE_FLUSH;

public class CrimeSelection extends AppCompatActivity implements RecognitionListener {
    String[] crime_types = {getString(R.string.fraud), getString(R.string.kidnapping), getString(R.string.domestic_abuse), getString(R.string.rape), getString(R.string.sexual_harassment), getString(R.string.assault), getString(R.string.gang_violence), getString(R.string.robbery)};
    ListView list2;
    public int flag=0,call_flag1,pos1,message_count1=0,crime_activation_voice;
    String contact_name1,contact_name2,contact_name3,police,fire,ambulance,phoneNo1,phoneNo2,phoneNo3,myFirstName,myLastName,myMailid,timer1_text,crime_selection_tv1_text;
    String message,password,entered_password;
    String mailid1,mailid2,mailid3;
    MediaPlayer mp;
    String FileName = "data";
    SharedPreferences permissionStatus;
    TextView timer1,crime_selection_tv1;
    TextToSpeech t1;
    Button mute_activation_alert,cancel_activation_alert,share_activation,activation_call_police,activation_call_ambulance,activation_call_fire,activation_call_contact1,activation_call_contact2,activation_call_contact3;
    EditText input;
    AlertDialog deactivation_dialog;
    LinearLayout activation_layout1,layout2;
    SharedPreferences sharedPref;


    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 100;
    private static final String KWS_SEARCH = "wakeup";
    private SpeechRecognizer recognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crime_selection);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        timer1= findViewById(R.id.timer);
        crime_selection_tv1= findViewById(R.id.crime_selection_tv);
        activation_layout1=findViewById(R.id.activation_layout1);
        layout2=findViewById(R.id.layout2);
        mute_activation_alert=findViewById(R.id.mute_activation_alert);
        cancel_activation_alert=findViewById(R.id.cancel_activation_alert);
        share_activation=findViewById(R.id.share_activation);
        activation_call_police=findViewById(R.id.activation_call_police);
        activation_call_ambulance=findViewById(R.id.activation_call_ambulance);
        activation_call_fire=findViewById(R.id.activation_call_fire);
        activation_call_contact1=findViewById(R.id.activation_call_contact1);
        activation_call_contact2=findViewById(R.id.activation_call_contact2);
        activation_call_contact3=findViewById(R.id.activation_call_contact3);


        new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (flag != 1) {
                    timer1.setTextColor(Color.parseColor("#FF0000"));
                    timer1.setText(getString(R.string.time_left)+millisUntilFinished / 1000 + "s");
                }
            }
            public void onFinish() {
            }
        }.start();

        MyListAdapter1 adapter1 = new MyListAdapter1(this, crime_types);
        list2 = findViewById(R.id.crime_list);
        list2.setAdapter(adapter1);
        permissionStatus = getSharedPreferences(FileName, MODE_PRIVATE);

        String defaultValue = "";
        sharedPref=getSharedPreferences(FileName,MODE_PRIVATE);
        myFirstName=sharedPref.getString("name1",defaultValue);
        myLastName=sharedPref.getString("name2",defaultValue);
        myMailid=sharedPref.getString("mail",defaultValue);
        contact_name1 = sharedPref.getString("contact_name1", defaultValue);
        contact_name2 = sharedPref.getString("contact_name2", defaultValue);
        contact_name3 = sharedPref.getString("contact_name3", defaultValue);
        phoneNo1 = sharedPref.getString("contact_number1", defaultValue);
        phoneNo2 =sharedPref.getString("contact_number2", defaultValue);
        phoneNo3 =sharedPref.getString("contact_number3", defaultValue);
        police = sharedPref.getString("police", defaultValue);
        ambulance = sharedPref.getString("ambulance", defaultValue);
        fire = sharedPref.getString("fire", defaultValue);
        mailid1 = sharedPref.getString("contact_mail1",defaultValue);
        mailid2 = sharedPref.getString("contact_mail2",defaultValue);
        mailid3 = sharedPref.getString("contact_mail3",defaultValue);
        message_count1 = sharedPref.getInt("message_count1",0);
        timer1_text=sharedPref.getString("timer1_text",defaultValue);
        crime_selection_tv1_text=sharedPref.getString("crime_selection_tv1_text",defaultValue);
        password = sharedPref.getString("password", "");
        crime_activation_voice=sharedPref.getInt("crime_activation_voice",0);

        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });

        list2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                pos1=position;
                SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putInt("pos1", pos1);
                editor.apply();
                activation1();
            }


        });
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (flag==0){
                    SharedPreferences sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putInt("pos1", 8);
                    editor.apply();
                    activation1();
                }
                else{
                    flag=0;
                }
            }
        }, 5000);

        mute_activation_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putInt("crime_activation_voice",0);
                editor.putInt("play_alert_tone_flag",0);
                editor.apply();
                Intent serviceIntent = new Intent(getApplicationContext(), AudioService.class);
                stopService(serviceIntent);
            }
        });
        cancel_activation_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(CrimeSelection.this);
                builder.setTitle(R.string.safety_deactivation);
                builder.setMessage(R.string.enter_deactivation_pin);
                builder.setCancelable(true);
                builder.setIcon(R.drawable.ic_lock_black_24dp);
                LinearLayout container = new LinearLayout(CrimeSelection.this);
                container.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(60, 0, 60, 20);
                input = new EditText(CrimeSelection.this);
                input.setLayoutParams(lp);
                input.setGravity(Gravity.CENTER);
                InputFilter[] FilterArray = new InputFilter[1];
                FilterArray[0] = new InputFilter.LengthFilter(4);
                input.setFilters(FilterArray);
                input.setInputType(InputType.TYPE_CLASS_PHONE);
                input.requestFocus();
                container.addView(input);
                builder.setView(container);
                builder.setPositiveButton(R.string.deactivate, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        entered_password = input.getText().toString();
                        if (entered_password.equals(password)) {
                            input.setText("");
                            deactivation_dialog.cancel();
                            CancelAlarm();
                            SharedPreferences sharedPref1 = getSharedPreferences(FileName, Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor1 = sharedPref1.edit();
                            editor1.putInt("activation_tv_flag", 0);
                            editor1.putInt("crime_activation_voice",0);
                            editor1.putInt("message_count", 0);
                            editor1.putInt("cancel_alarm_flag", 1);
                            editor1.putInt("play_alert_tone_flag",0);
                            editor1.apply();
                            Intent serviceIntent = new Intent(getApplicationContext(), AudioService.class);
                            stopService(serviceIntent);
                            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                        } else {
                            Toast.makeText(getApplicationContext(), "Incorrect PIN", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                builder.setNegativeButton(R.string.close, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                deactivation_dialog = builder.create();
                deactivation_dialog.show();
                deactivation_dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
                deactivation_dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);


            }
        });

        share_activation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPref=getSharedPreferences(FileName,MODE_PRIVATE);
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String message=sharedPref.getString("message_to_share",null);
                if (message!=null) {
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(sharingIntent, "Share via"));
                }
                else{
                    Toast.makeText(getApplicationContext(), "Message content not yet processed. Try again in a minute.", Toast.LENGTH_LONG).show();
                }
            }
        });
        activation_call_police.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(police);
            }
        });
        activation_call_fire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(fire);
            }
        });
        activation_call_ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(ambulance);
            }
        });

        if (!contact_name1.equals("")) {
            activation_call_contact1.setText(contact_name1);
            activation_call_contact1.setVisibility(View.VISIBLE);
            activation_call_contact1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    call(phoneNo1);
                }
            });
        }
        if (!contact_name2.equals("")) {
            activation_call_contact2.setText(contact_name2);
            activation_call_contact2.setVisibility(View.VISIBLE);
            activation_call_contact2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    call(phoneNo2);
                }
            });
        }
        if (!contact_name3.equals("")) {
            activation_call_contact3.setText(contact_name3);
            activation_call_contact3.setVisibility(View.VISIBLE);
            activation_call_contact3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    call(phoneNo3);
                }
            });
        }
    }
    public void CancelAlarm() {
        Intent intent = new Intent(this, ActivationReceiver.class);
        PendingIntent sender = PendingIntent.getBroadcast(this.getApplicationContext(), 10, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.cancel(sender);
    }

    public void activation1(){
        activation_layout1.setVisibility(View.VISIBLE);
        layout2.setVisibility(View.GONE);
        SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPref.edit();
        editor.putInt("activation_tv_flag",1);
        editor.putInt("message_count1",0);
        if (crime_activation_voice==1) editor.putInt("play_alert_tone_flag",1);
        editor.apply();
        startActivation();
        if (crime_activation_voice==1) {
            Intent playbackServiceIntent = new Intent(getApplicationContext(), AudioService.class);
            startService(playbackServiceIntent);
            t1.speak("Do you want to call police?",QUEUE_FLUSH,null);
        }
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                call_flag1=0;
                SharedPreferences sharedPreferences=getSharedPreferences("data",MODE_PRIVATE);
                SharedPreferences.Editor editor1=sharedPreferences.edit();
                editor1.putInt("call_flag1",0);
                editor1.apply();
            }
        }, 60000);
    }

    public void startActivation(){
        Intent intent = new Intent(this, ActivationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this.getApplicationContext(), 10, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC, System.currentTimeMillis(),120000, pendingIntent);
    }

    @SuppressLint("MissingPermission")
    public void call(String number) {
        String uri = "tel:" + number;
        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(uri));
        startActivity(callIntent);
    }

    private static class SetupTask extends AsyncTask<Void, Void, Exception> {
        WeakReference<CrimeSelection> activityReference;

        SetupTask(CrimeSelection activity) {
            this.activityReference = new WeakReference<>(activity);
        }

        @Override
        protected Exception doInBackground(Void... params) {
            try {
                Assets assets = new Assets(activityReference.get());
                File assetDir = assets.syncAssets();
                activityReference.get().setupRecognizer(assetDir);
            } catch (IOException e) {
                return e;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Exception result) {
            if (result != null) {

            } else {
                activityReference.get().switchSearch(KWS_SEARCH);
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                new CrimeSelection.SetupTask(this).execute();
            }
        }
    }

    private boolean isMyServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (VoiceService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.shutdown();
        }
    }


    @Override
    public void onPartialResult(Hypothesis hypothesis) {
        if (hypothesis == null)
            return;
        String text = hypothesis.getHypstr();
        if (text.equals("yes")){
            SharedPreferences sharedPref = getSharedPreferences(FileName,Context.MODE_PRIVATE);
            call_flag1 = sharedPref.getInt("call_flag1",0);
            if (call_flag1==1) {
                t1.speak("Calling police..", QUEUE_FLUSH, null);
                call(police);
                call_flag1 = 0;
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putInt("call_flag1",call_flag1);
                editor.apply();
            }
        }

        switchSearch(KWS_SEARCH);
    }
    @Override
    public void onResult(Hypothesis hypothesis) {

    }

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onEndOfSpeech() {
        if (!recognizer.getSearchName().equals(KWS_SEARCH))
            switchSearch(KWS_SEARCH);
    }

    public void switchSearch(String searchName) {
        recognizer.stop();
        recognizer.startListening(searchName);
    }

    public void setupRecognizer(File assetsDir) throws IOException {
        recognizer = SpeechRecognizerSetup.defaultSetup()
                .setAcousticModel(new File(assetsDir, "en-us-ptm"))
                .setDictionary(new File(assetsDir, "cmudict-en-us.dict"))
                .getRecognizer();
        recognizer.addListener(this);

        try {
            FileOutputStream fileout=openFileOutput("threshold.list", MODE_PRIVATE);
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);
            outputWriter.write("accident accident/1e-40/\n" + "fire fire/0.5/\n" + "medic medic/1e-20/\n" + "crime crime/1e-20/\n" + "disaster disaster/1e-40/\n" + "alert alert/1e-10/\n" + "yes/0.5/");
            outputWriter.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        File file1 = new File(getApplicationContext().getFilesDir(), "threshold.list");
        recognizer.addKeywordSearch(KWS_SEARCH, file1);

    }

    @Override
    public void onError(Exception error) {
    }

    @Override
    public void onTimeout() {
        switchSearch(KWS_SEARCH);
    }


}
