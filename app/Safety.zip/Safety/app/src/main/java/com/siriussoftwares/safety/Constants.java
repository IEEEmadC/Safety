package com.siriussoftwares.safety;


import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;

public class Constants {


    public interface ACTION {
        public static String MAIN_ACTION = "com.siriussoftwares.safety.action.main";
        public static String STARTFOREGROUND_ACTION = "com.siriussoftwares.safety.action.startforeground";
        public static String STOPFOREGROUND_ACTION = "com.siriussoftwares.safety.action.stopforeground";
    }

    public interface NOTIFICATION_ID {
        public static int FOREGROUND_SERVICE = 101;
    }


}

