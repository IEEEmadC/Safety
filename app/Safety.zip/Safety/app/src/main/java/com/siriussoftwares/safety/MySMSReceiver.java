package com.siriussoftwares.safety;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import static android.Manifest.permission_group.CALENDAR;
import static java.lang.Boolean.TRUE;

public class MySMSReceiver extends BroadcastReceiver  implements LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener{
    private static final String TAG = MySMSReceiver.class.getSimpleName();
    public static final String pdu_type = "pdus";
    public MediaPlayer mp;
    public String alarmTone1;
    String name,date_of_birth,strMessage="",sender_number,sender_name="",tracker_phone1,tracker_phone2,tracker_phone3,latitude,longitude;
    int message_number,location_flag;
    Date date;
    SharedPreferences sharedPref;
    public String FileName="data";
    public Ringtone ringtone1;
    WifiManager wifiManager;

    LocationRequest mLocationRequest;
    GoogleApiClient mGoogleApiClient;
    Location mCurrentLocation;
    String mLastUpdateTime;


    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        sharedPref = context.getSharedPreferences(FileName, Context.MODE_PRIVATE);
        alarmTone1 = sharedPref.getString("ringtone1", null);
        message_number=sharedPref.getInt("message_number",0);
        tracker_phone1 = sharedPref.getString("tracker_phone1", "");
        tracker_phone2 = sharedPref.getString("tracker_phone2", "");
        tracker_phone3 = sharedPref.getString("tracker_phone3", "");

        mGoogleApiClient = new GoogleApiClient.Builder(context).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
        createLocationRequest();
        mGoogleApiClient.connect();


        Bundle bundle = intent.getExtras();
        SmsMessage[] msgs;
        String format = bundle.getString("format");
        Object[] pdus = (Object[]) bundle.get(pdu_type);
        if (pdus != null) {
            msgs = new SmsMessage[pdus.length];
            for (int i = 0; i < msgs.length; i++) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i], format);
                }
                 else {
                    msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                }
                strMessage += msgs[i].getMessageBody();
                sender_number = msgs[i].getOriginatingAddress();
                sender_number = sender_number.replaceAll(" ", "");
                sender_number = sender_number.replaceAll("-", "");
                if (!sender_number.substring(0, 1).equals("+")) sender_number = "+" + sender_number;
                try {
                    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
                    Phonenumber.PhoneNumber numberProto = phoneUtil.parse(sender_number, "");
                    sender_number = String.valueOf(numberProto.getNationalNumber());
                } catch (NumberParseException e) {
                }
            }

            if (strMessage.contains("'s updated location:\n")|| strMessage.contains(".\nLocation:\nhttps")) {
                int index = strMessage.indexOf(" ");
                String name = strMessage.substring(0, index);
                if (name.contains("'s")) {
                    name = name.substring(0, (name.length() - 2));
                }
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("alert_contact_name", name);
                editor.putString("alert_message", strMessage);
                editor.putInt("alert_message_flag", 1);
                Date date1 = new Date(System.currentTimeMillis());
                editor.putLong("received_time", date1.getTime());
                DateFormat dateFormat = new SimpleDateFormat("hh:mm a",Locale.ENGLISH);
                DateFormat dateFormat1 = new SimpleDateFormat("hh:mm a, dd/MM/yyyy",Locale.ENGLISH);
                message_number+=1;
                editor.putInt("message_number",message_number);
                editor.apply();
                String time1=dateFormat.format(new Date());
                String time2=dateFormat1.format(new Date());
                editor.putString("alert_message_date", time2);
                if (message_number==1)editor.putString("message_time1",time1);
                if (message_number==2)editor.putString("message_time2",time1);
                if (message_number==3)editor.putString("message_time3",time1);
                if (message_number==4){
                    editor.putString("message_time4",time1);
                }
                editor.apply();
                Intent intent1 = new Intent(context, IncomingAlert.class);
                context.startActivity(intent1);
            }

            if (strMessage.contains("Safety Track Location-\nYou received a request")){
                if (strMessage.length()>=51)sender_name=strMessage.substring(51,strMessage.length());
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("sender_name",sender_name);
                editor.putString("track_location_message",strMessage.substring(23,strMessage.length()));
                editor.putString("sender_number",sender_number);
                editor.putInt("sms_type",1);
                editor.apply();
                notifications(context,1);
            }

            if (strMessage.contains("Safety Track Location-\nYou are allowed to track ")){
                if (strMessage.length()>=48)sender_name=strMessage.substring(48,strMessage.length());
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("sender_name",sender_name);
                editor.putString("sender_number",sender_number);
                editor.putString("track_location_message",strMessage.substring(23,strMessage.length()));
                editor.putInt("sms_type",2);
                editor.apply();
                notifications(context,2);
            }

            if (strMessage.contains("Safety Track Location-\nYou are unfollowed")){
                if (strMessage.length()>=47)sender_name=strMessage.substring(47,strMessage.length());
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("sender_name",sender_name);
                editor.putString("track_location_message",strMessage.substring(23,strMessage.length()));
                editor.putString("sender_number",sender_number);
                editor.putInt("sms_type",3);
                editor.apply();
                notifications(context,3);
            }

            if (strMessage.contains("Safety Track Location-\nYou have been blocked")){
                if (strMessage.length()>=48)sender_name=strMessage.substring(48,strMessage.length());
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("sender_name",sender_name);
                editor.putString("sender_number",sender_number);
                editor.putString("track_location_message",strMessage.substring(23,strMessage.length()));
                editor.putInt("sms_type",4);
                editor.apply();
                notifications(context,4);
            }

            if (strMessage.contains("Safety Track Location-\nYour location is being tried to access")){
                if (sender_number.equals(tracker_phone1) || sender_number.equals(tracker_phone2) || sender_number.equals(tracker_phone3)) {
                    location_flag=1;
                    if(!isOnline(context)){
                        wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        assert wifiManager != null;
                        wifiManager.setWifiEnabled(TRUE);
                    }
                    if (strMessage.length() >= 65) sender_name = strMessage.substring(65, strMessage.length());
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("sender_name", sender_name);
                    editor.putString("sender_number", sender_number);
                    editor.putString("track_location_message", strMessage.substring(23, strMessage.length()));
                    editor.putInt("sms_type", 5);
                    editor.apply();
                }
            }

            if (strMessage.contains("Safety Track Location-\nlatitude:")){
                latitude=strMessage.substring(32,strMessage.indexOf("\nlongitude")-1);
                longitude=strMessage.substring(strMessage.indexOf("longitude:")+10,strMessage.length());
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("track_location_latitude", latitude);
                editor.putString("track_location_longitude", longitude);
                Toast.makeText(context,"latitude"+latitude+"   longitude"+longitude , Toast.LENGTH_LONG).show();
                editor.apply();
                Intent intent1 = new Intent(context, MapsActivity2.class);
                context.startActivity(intent1);
            }
        }
    }

    protected void startLocationUpdates() {
        @SuppressLint("MissingPermission") com.google.android.gms.common.api.PendingResult<Status> pendingResult = LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
    }
    @Override
    public void onConnected(Bundle bundle) {
        startLocationUpdates();
    }


    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
    }

    @Override
    public void onLocationChanged(Location location) {
        mCurrentLocation = location;
        mLastUpdateTime = DateFormat.getTimeInstance().format(new Date());
        if (location_flag==1){
            String lat = String.valueOf(mCurrentLocation.getLatitude());
            String lng = String.valueOf(mCurrentLocation.getLongitude());
            try {
                String msg="Safety Track Location-\nlatitude:"+lat+"\nlongitude:"+lng;
                SmsManager smsManager = SmsManager.getDefault();
                ArrayList<String> parts = smsManager.divideMessage(msg);
                smsManager.sendMultipartTextMessage(sender_number, null, parts, null, null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            location_flag=0;
        }
    }
    public boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }
    public void notifications(Context context,int id){
        Intent notificationIntent = new Intent(context, TrackLocationActivity.class);
        notificationIntent.setAction(Constants.ACTION.MAIN_ACTION);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                .setContentTitle("Safety Track Location")
                .setContentText(strMessage.substring(23,strMessage.length()))
                .setAutoCancel(true)
                .setChannelId("track_location_notifications")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(strMessage.substring(23,strMessage.length())))
                .setContentIntent(pendingIntent);
        Notification notification = builder.build();
        NotificationManager mNotificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(id , notification);
    }
        }

