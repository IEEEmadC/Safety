package com.siriussoftwares.safety;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;

public class IncomingAlert extends AppCompatActivity {
    public MediaPlayer mp;
    public String alarmTone1;
    public String FileName = "data";
    String alert_contact_name, message, alert_message,alert_message_date;
    public Ringtone ringtone1,r;
    public TextView alert_name_tv, msg_tv;
    Timer timer,timer1;
    public int alert_message_flag,message_number;
    public String link, police, fire, ambulance;
    SharedPreferences sharedPref;
    Long received_time;
    public Button mute_alert, view_location, call_police, call_ambulance, call_fire;
    RelativeLayout layout1;
    LinearLayout layout2;
    String latitude,longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incoming_alert);

        sharedPref = getSharedPreferences(FileName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        alarmTone1 = sharedPref.getString("ringtone1", null);
        alert_contact_name = sharedPref.getString("alert_contact_name", null);
        alert_message = sharedPref.getString("alert_message", "");
        alert_message_date = sharedPref.getString("alert_message_date", "");
        message = sharedPref.getString("complete_message", "");
        alert_message_flag = sharedPref.getInt("alert_message_flag", 0);
        police = sharedPref.getString("police", "");
        ambulance = sharedPref.getString("ambulance", "");
        fire = sharedPref.getString("fire", "");
        received_time=sharedPref.getLong("received_time",0);
        message_number = sharedPref.getInt("message_number", 0);

        alert_name_tv = findViewById(R.id.alert_name_tv);
        msg_tv = findViewById(R.id.msg_tv);
        mute_alert = findViewById(R.id.mute_alert);
        view_location = findViewById(R.id.view_location);
        call_police = findViewById(R.id.call_police);
        call_ambulance = findViewById(R.id.call_ambulance);
        call_fire = findViewById(R.id.call_fire);
        layout1=findViewById(R.id.received_alert_layout1);
        layout2=findViewById(R.id.received_alert_layout2);

        if (received_time==0){
            layout2.setVisibility(View.VISIBLE);
            layout1.setVisibility(View.GONE);
        }
        if (received_time!=0) {
            layout2.setVisibility(View.GONE);
            layout1.setVisibility(View.VISIBLE);
        }
        if (alert_message_flag == 1) {
            if (alarmTone1 != null) {
                Uri uri = Uri.parse(alarmTone1);
                ringtone1 = RingtoneManager.getRingtone(getApplicationContext(), uri);
                timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        ringtone1.play();
                    }
                }, 0, 1000);
            } else {
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (notification==null) notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                timer1 = new Timer();
                timer1.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        r.play();
                    }
                }, 0, 1000);
            }
            editor.putInt("alert_message_flag", 0);
        }
        if (alert_contact_name!=null)alert_name_tv.setText(getString(R.string.alert_from) + alert_contact_name);

        Calendar now = Calendar.getInstance();
        long differenceInMillis = now.getTimeInMillis() - received_time;
        long differenceInHours = (differenceInMillis) / 1000L / 60L / 60L; // Divide by millis/sec, secs/min, mins/hr
        if (differenceInHours>24) {
            layout2.setVisibility(View.VISIBLE);
            layout1.setVisibility(View.GONE);
            editor.putLong("received_time",0);
        }


        mute_alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (timer != null) {
                    timer.cancel();
                    ringtone1.stop();
                }
                if (timer1 != null) {
                    timer1.cancel();
                    r.stop();
                }
            }
        });

        if (alert_message.contains("https:")) {
            int index_start = alert_message.indexOf("https:");
            int index_end = alert_message.indexOf(" .");
            link = alert_message.substring(index_start, index_end);
            latitude=link.substring(link.indexOf("=")+1, link.indexOf(","));
            longitude=link.substring(link.indexOf(",")+1, link.length());
            if (message_number==1) {
                editor.putString("latitude1", latitude);
                editor.putString("longitude1", longitude);
                editor.apply();
            }
            else if (message_number==2) {
                editor.putString("latitude2", latitude);
                editor.putString("longitude2", longitude);
                editor.apply();
            }
            else if (message_number==3) {
                editor.putString("latitude3", latitude);
                editor.putString("longitude3", longitude);
                editor.apply();
            }
            else if (message_number==4) {
                editor.putString("latitude4", latitude);
                editor.putString("longitude4", longitude);
                editor.apply();
            }
        }

        if (alert_message_flag == 1) {
            int index_start = alert_message.indexOf("https:");
            int index_end = alert_message.indexOf(" .");
            if (message_number==1) {
                String alert_message1 = alert_message.substring(0, index_start);
                alert_message1 += alert_message.substring(index_end + 3, alert_message.length());
                message = alert_message1 + "\nReceived on " + alert_message_date + ". Next update will be received 15 minutes later.\n\n\n" + message;
            }
            if (message_number==2||message_number==3) {
                String alert_message1 = alert_message.substring(0, index_start);
                message = alert_message1+"Received on " + alert_message_date + ". Next update will be received 15 minutes later.\n\n\n" + message;
            }
            if (message_number==4) {
                String alert_message1 = alert_message.substring(0, index_start);
                message = alert_message1+ "Received on " + alert_message_date + ". This was the last update for this incident. Thank you for your help.\n\n\n" + message;
            }
            editor.putInt("alert_message_flag", 0);

        }
        msg_tv.setText(message);
        editor.putString("complete_message", message);
        editor.apply();

        view_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(intent);
            }
        });
        call_police.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(police);
            }
        });
        call_ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(ambulance);
            }
        });
        call_fire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call(fire);
            }
        });
    }

    public void call(String phone) {
        String uri = "tel:" + phone;
        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(uri));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }
        }


