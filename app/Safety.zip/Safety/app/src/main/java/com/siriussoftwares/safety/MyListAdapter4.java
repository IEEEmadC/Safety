package com.siriussoftwares.safety;


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MyListAdapter4 extends ArrayAdapter<String> {
    RelativeLayout disaster_layout2;
    private final Activity context;
    private final String[] maintitle;
    private final String[] subtitle;


    MyListAdapter4(Activity context, String[] maintitle, String[] subtitle) {
        super(context, R.layout.mylist5, maintitle);

        this.context=context;
        this.maintitle=maintitle;
        this.subtitle=subtitle;


    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.mylist5, null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.title5);
        TextView subtitleText = (TextView) rowView.findViewById(R.id.subtitle5);

        titleText.setText(maintitle[position]);
        subtitleText.setText(subtitle[position]);
        return rowView;

    };
}