package com.siriussoftwares.safety;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.speech.tts.Voice;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static android.content.Context.ACTIVITY_SERVICE;

public class NotificationReceiver extends BroadcastReceiver {
    String date_of_birth,reminder_time1,reminder_frequency,name1,setup_reminder_time;
    Long activation_time;
    String FileName="data";
    int setup_activity_running,play_alert_tone_flag;
    Boolean switch_state2;
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences sharedPref = context.getSharedPreferences(FileName, Context.MODE_PRIVATE);
        String defaultValue = "";
        date_of_birth = sharedPref.getString("dob", defaultValue);
        reminder_time1 = sharedPref.getString("reminder_time1", defaultValue);
        reminder_frequency = sharedPref.getString("reminder_frequency", defaultValue);
        name1 = sharedPref.getString("name1", defaultValue);
        activation_time=sharedPref.getLong("activation_time",0);
        setup_reminder_time=sharedPref.getString("setup_reminder_time",defaultValue);
        switch_state2 = sharedPref.getBoolean("switch2", true);
        setup_activity_running=sharedPref.getInt("setup_activity_running",0);
        play_alert_tone_flag=sharedPref.getInt("play_alert_tone_flag",0);
        DateFormat sdf1 = new SimpleDateFormat("dd/MM", Locale.ENGLISH);
        DateFormat sdf3 = new SimpleDateFormat("EEEE",Locale.ENGLISH);
        DateFormat sdf4 = new SimpleDateFormat("dd",Locale.ENGLISH);
        DateFormat sdf5 = new SimpleDateFormat("yyyy",Locale.ENGLISH);

        Calendar now = Calendar.getInstance(); // Get time now
        long differenceInMillis = now.getTimeInMillis() - activation_time;
        long differenceInHours = (differenceInMillis) / 1000L / 60L / 60L; // Divide by millis/sec, secs/min, mins/hr
        long differenceInMinutes = (differenceInMillis) / 1000L / 60L; // Divide by millis/sec, secs/min, mins/hr



        if (switch_state2) {
            Boolean result = isMyServiceRunning(context);
            if (!result && setup_activity_running==0) {
                try {
                    Intent serviceIntent = new Intent(context, VoiceService.class);
                    context.startService(serviceIntent);
                } catch (IllegalStateException e){

                }
            }
        }

        if (play_alert_tone_flag==1){
            Boolean result = isMyServicePlaying(context);
            if (!result) {
                Intent serviceIntent = new Intent(context, AudioService.class);
                context.startService(serviceIntent);
            }
        }

        Date date = new Date();
        String current_date = sdf1.format(date);
        String dayOfTheWeek = sdf3.format(date);
        String simple_date = sdf4.format(date);
        String current_year = sdf5.format(date);

        int currentTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int currentTime1 = Calendar.getInstance().get(Calendar.MINUTE);
        String current_time=currentTime+"."+currentTime1;
        if (!date_of_birth.equals("")) {
            String yourDate = date_of_birth.substring(0,5);
            int age=Integer.parseInt(current_year)-Integer.parseInt(date_of_birth.substring(date_of_birth.length()-4));
            if (current_date.equals(yourDate) && current_time.equals("0.0")) {
                Notification notification = new NotificationCompat.Builder(context, "id")
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle("Happy Birthday,"+name1)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText("Happy "+age+"th Birthday, "+name1+". May this wonderful day fill up your heart with happiness. Wishing you all the very best for your goals and ambitions to succeed. Good Luck!!! "))
                        .setContentText("Happy "+age+"th Birthday, "+name1+". May this wonderful day fill up your heart with happiness. Wishing you all the very best for your goals and ambitions to succeed. Good Luck!!! ")
                        .setChannelId("other_notifications")
                        .build();

                NotificationManager notificationManager =
                        (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(1, notification);
            }
        }
        if(current_date.equals("01/01") && current_time.equals("0.0")){
            Notification notification = new NotificationCompat.Builder(context, "id")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Happy New Year,"+name1)
                    .setContentText("Wishing you a happy new year. May you have a fabulous "+current_year+" with full of great achievements and experiences.")
                    .setStyle(new NotificationCompat.BigTextStyle().bigText("Wishing you a happy new year. May you have a fabulous "+current_year+" with full of great achievements and experiences."))
                    .setChannelId("other_notifications")
                    .build();

            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(2, notification);
        }
        if (!setup_reminder_time.equals("")) {
            if (current_time.equals(setup_reminder_time)) {
                Intent myIntent = new Intent(context, SetupActivity.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, myIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                Notification notification = new NotificationCompat.Builder(context, "id")
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle("Finish Safety Setup")
                        .setContentText("Please note that you haven't finished the Safety Setup yet. Please complete it right now. It will take only few minutes.")
                        .setContentIntent(pendingIntent)
                        .setChannelId("other_notifications")
                        .setAutoCancel(true)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText("Please note that you haven't finished the Safety Setup yet. Please complete it right now. It will take only few minutes."))
                        .build();

                NotificationManager notificationManager =
                        (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(3, notification);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("setup_reminder_time", "");
                editor.apply();
            }
        }
        if (!reminder_frequency.equals("") && !reminder_time1.equals("")) {
            switch (reminder_frequency) {
                case "Daily":
                    if (current_time.equals(reminder_time1)) {
                        showNotification(context);
                    }
                    break;
                case "Weekly":
                    if (dayOfTheWeek.equals("Sunday") && current_time.equals(reminder_time1)) {
                        showNotification(context);
                    }
                    break;
                case "Monthly":
                    if (simple_date.equals("15") && current_time.equals(reminder_time1)) {
                        showNotification(context);
                    }
                    break;
                case "Quarter-yearly":
                    if ((current_date.equals("15/01") || current_date.equals("15/04") || current_date.equals("15/07") || current_date.equals("15/10")) && current_time.equals(reminder_time1)) {
                        showNotification(context);
                    }
                    break;
                case "Half-yearly":
                    if ((current_date.equals("15/04") || current_date.equals("15/10")) && current_time.equals(reminder_time1)) {
                        showNotification(context);
                    }
                    break;
                case "Yearly":
                    if (current_date.equals("15/06") && current_time.equals(reminder_time1)) {
                        showNotification(context);
                    }
                    break;
            }
        }
    }

    private boolean isMyServiceRunning(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (VoiceService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private boolean isMyServicePlaying(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (AudioService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void showNotification(Context context){
        Intent myIntent = new Intent(context, SetupActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, myIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new NotificationCompat.Builder(context, "id")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Update Medical Information")
                .setContentText("Please update your medical information in Safety Setup. Thank you, have a nice day!")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Please update your medical information in Safety Setup. Thank you, have a nice day!"))
                .setChannelId("other_notifications")
                .setAutoCancel(true)
                .setContentIntent(pendingIntent).build();

        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(4, notification);
    }



}
