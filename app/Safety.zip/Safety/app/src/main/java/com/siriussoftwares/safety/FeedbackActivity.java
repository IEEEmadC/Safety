package com.siriussoftwares.safety;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class FeedbackActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner category_spinner;
    String[] category={getString(R.string.report_an_issue),getString(R.string.suggest_an_idea),getString(R.string.need_help),getString(R.string.other)};
    String mail_id,subject,message;
    Button clear_message,send_mail;
    EditText feedback_message,feedback_email;
    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        category_spinner = findViewById(R.id.category_spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(FeedbackActivity.this, android.R.layout.simple_spinner_item, category);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category_spinner.setAdapter(adapter);
        category_spinner.setOnItemSelectedListener(this);

        sharedPref = getSharedPreferences("data", MODE_PRIVATE);

        feedback_message = (EditText) findViewById(R.id.feedback_message);
        feedback_email=findViewById(R.id.feedback_email);
        send_mail = (Button) findViewById(R.id.send_mail);
        clear_message=findViewById(R.id.clear_message);

        mail_id = sharedPref.getString("mail", "");
        if (!mail_id.equals("")){
            feedback_email.setText(mail_id);
        }

        send_mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String sub = subject;
                final String body = feedback_message.getText().toString();
                final String send = feedback_email.getText().toString();
                final String receive = "support.safety@siriussoftwares.com";
                if (send.equals("")){
                    Toast.makeText(FeedbackActivity.this,"Please enter your E-Mail id.",Toast.LENGTH_LONG).show();
                }
                else if (body.equals("")){
                    Toast.makeText(FeedbackActivity.this,"Please type your feedback message.",Toast.LENGTH_LONG).show();
                }
                else {
                    new Thread() {
                        public void run() {
                            try {
                                Sender sender = new Sender("feedback.safetyapp@gmail.com", "hsqqckzoofepfzaq");
                                sender.sendMail(sub, sub+"\n\n"+body+"\nBy,\n"+send,send,receive);
                            } catch (Exception e) {
                                Toast.makeText(FeedbackActivity.this, "Feedback doesn't sent. An error occured while sending the message.", Toast.LENGTH_LONG).show();
                            }
                        }
                    }.start();
                    Toast.makeText(FeedbackActivity.this,"Thank you for your feedback. The team will get back to you shortly.",Toast.LENGTH_LONG).show();

                }
            }
        });

        clear_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                feedback_message.setText("");
                feedback_email.setText("");
                category_spinner.setSelection(0);

            }
        });

    }


        @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
            subject= parent.getItemAtPosition(position).toString();
    }
    public void onNothingSelected(AdapterView<?> arg0) {
    }


}

