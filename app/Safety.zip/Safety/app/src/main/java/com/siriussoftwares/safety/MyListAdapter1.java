package com.siriussoftwares.safety;

import android.app.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyListAdapter1 extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] crime_types;

    public MyListAdapter1(Activity context, String[] crime_types) {
        super(context, R.layout.mylist2,crime_types );
        // TODO Auto-generated constructor stub

        this.context=context;
        this.crime_types=crime_types;


    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.mylist2, null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.crime_text);

        titleText.setText(crime_types[position]);


        return rowView;

    };
}