package com.siriussoftwares.safety;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap1,mMap;
    SharedPreferences sharedPref;
    String latitude1,longitude1,latitude2,longitude2,latitude3,longitude3,latitude4,longitude4,message_time1,message_time2,message_time3,message_time4;
    int message_number;
    Marker marker1,marker2,marker3,marker4;
    Double lat1,lat2,lat3,lat4,lng1,lng2,lng3,lng4;
    LatLng latlng1,latlng2,latlng3,latlng4;
    String FileName="data";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        values();
    }

    public void values(){
        sharedPref=getSharedPreferences(FileName, Context.MODE_PRIVATE);
        latitude1=sharedPref.getString("latitude1","");
        longitude1=sharedPref.getString("longitude1","");
        latitude2=sharedPref.getString("latitude2","");
        longitude2=sharedPref.getString("longitude2","");
        latitude3=sharedPref.getString("latitude3","");
        longitude3=sharedPref.getString("longitude3","");
        latitude4=sharedPref.getString("latitude4","");
        longitude4=sharedPref.getString("longitude4","");
        message_number=sharedPref.getInt("message_number",0);
        message_time1 = sharedPref.getString("message_time1", "");
        message_time2 = sharedPref.getString("message_time2", "");
        message_time3 = sharedPref.getString("message_time3", "");
        message_time4 = sharedPref.getString("message_time4", "");
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        values();
        mMap1 = googleMap;
        lat1=Double.parseDouble(latitude1);
        lng1=Double.parseDouble(longitude1);
        latlng1=new LatLng(lat1, lng1);
        if (!latitude2.equals("")) {
            lat2 = Double.parseDouble(latitude2);
            lng2 = Double.parseDouble(longitude2);
            latlng2 = new LatLng(lat2, lng2);
        }
        if (!latitude3.equals("")) {
            lat3 = Double.parseDouble(latitude3);
            lng3 = Double.parseDouble(longitude3);
            latlng3 = new LatLng(lat3, lng3);
        }
        if (!latitude4.equals("")) {
            lat4 = Double.parseDouble(latitude4);
            lng4 = Double.parseDouble(longitude4);
            latlng4 = new LatLng(lat4, lng4);
        }

        if (message_number==1) {
            showMap(latlng1,marker1,BitmapDescriptorFactory.HUE_GREEN,message_time1);
            }
        if (message_number==2) {
            showMap(latlng1,marker1,BitmapDescriptorFactory.HUE_AZURE,message_time1);
            showMap(latlng2,marker2,BitmapDescriptorFactory.HUE_GREEN,message_time2);
        }
        if (message_number==3) {
            showMap(latlng1,marker1,BitmapDescriptorFactory.HUE_AZURE,message_time1);
            showMap(latlng2,marker2,BitmapDescriptorFactory.HUE_AZURE,message_time2);
            showMap(latlng3,marker3,BitmapDescriptorFactory.HUE_GREEN,message_time3);
        }
        if (message_number==4) {
            showMap(latlng1,marker1,BitmapDescriptorFactory.HUE_AZURE,message_time1);
            showMap(latlng2,marker2,BitmapDescriptorFactory.HUE_AZURE,message_time2);
            showMap(latlng3,marker3,BitmapDescriptorFactory.HUE_AZURE,message_time3);
            showMap(latlng4,marker4,BitmapDescriptorFactory.HUE_GREEN,message_time4);
        }
    }

    public void showMap(LatLng latlng,Marker marker,Float color,String message_time){
        values();
        mMap=mMap1;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setZoomGesturesEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);
        mMap.animateCamera(CameraUpdateFactory.zoomTo(16));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng,16));
        marker=mMap.addMarker(new MarkerOptions()
                .position(latlng)
                .title(message_time)
                .icon(BitmapDescriptorFactory.defaultMarker(color)));
        marker.showInfoWindow();
        }

}
