package com.siriussoftwares.safety;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.text.SpannableString;
import android.text.style.AlignmentSpan;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

import static android.widget.Toast.makeText;

public class SettingsActivity extends AppCompatActivity {
    public ListView list3,list4,list6;
    String[] maintitle1 = {getString(R.string.received_alert), getString(R.string.deactivation_alert), getString(R.string.disaster_alert),getString(R.string.safety_alert_ringtone)};
    String[] maintitle2 = {getString(R.string.remind_me_to_update), getString(R.string.reminder_time)};
    String[] maintitle3={getString(R.string.language),getString(R.string.deactivation_time)};
    public String FileName="data";
    public String[] subtitle1=null;
    public String[] subtitle2=null;
    public String[] subtitle3=null;


    public String name1,name2,name3,name4,name5,name6,name7,ringtone_title,show_time,str1,str2,app_language,lang,deactivation_time,deactivation_time_seconds;
    Ringtone ringTone;
    Ringtone ringTone1;
    public int pos,play_flag=0;
    ImageButton play_btn;
    SharedPreferences sharedPref;
    final int RQS_RINGTONEPICKER = 1;
    MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        get_alert_values();

        app_language="English";
        subtitle1= new String[]{name1, name2, name3,getString(R.string.tap_to_play)};
        subtitle2= new String[]{name5,name7};
        subtitle3= new String[]{app_language,deactivation_time};
        MyListAdapter2 adapter = new MyListAdapter2(this, maintitle1, subtitle1);
        final MyListAdapter3 adapter1 = new MyListAdapter3(this, maintitle2, subtitle2);
        final MyListAdapter6 adapter2 = new MyListAdapter6(this, maintitle3, subtitle3);

        list6 = findViewById(R.id.general_settings);
        list6.setAdapter(adapter2);
        setListViewHeightBasedOnChildren(list6);
        list6.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                    final SharedPreferences.Editor editor = settings.edit();
                    final AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                    builder.setTitle(R.string.select_language);
                    final String[] language = {getString(R.string.daily), getString(R.string.weekly), getString(R.string.monthly), getString(R.string.quarterly), getString(R.string.half_yearly),getString(R.string.yearly),getString(R.string.never)};
                    builder.setItems(language, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case 0: lang="English"; break;
                                case 1: lang="Hindi"; break;
                            }

                            editor.apply();
                            list4 = findViewById(R.id.reminder_list);
                            list4.setAdapter(adapter1);
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else if (position == 1) {
                    SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                    final SharedPreferences.Editor editor = settings.edit();
                    final AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                    builder.setTitle(getString(R.string.deactivation_time));
                    final String[] language = {"5 seconds", "10 seconds", "15 seconds", "20 seconds", "30 seconds","45 seconds","1 minute"};
                    builder.setItems(language, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case 0: deactivation_time_seconds="5000"; deactivation_time="5 seconds"; break;
                                case 1: deactivation_time_seconds="10000"; deactivation_time="10 seconds"; break;
                                case 2: deactivation_time_seconds="15000"; deactivation_time="15 seconds"; break;
                                case 3: deactivation_time_seconds="20000"; deactivation_time="20 seconds"; break;
                                case 4: deactivation_time_seconds="30000"; deactivation_time="30 seconds"; break;
                                case 5: deactivation_time_seconds="45000"; deactivation_time="45 seconds"; break;
                                case 6: deactivation_time_seconds="60000"; deactivation_time="1 minute"; break;
                            }

                            subtitle3[1]=deactivation_time;
                            editor.putString("deactivation_time_seconds",deactivation_time_seconds);
                            editor.putString("deactivation_time",deactivation_time);
                            editor.apply();
                            list6 = findViewById(R.id.general_settings);
                            list6.setAdapter(adapter2);
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });



        mp=MediaPlayer.create(this,R.raw.emergency_tone);

        list3 = findViewById(R.id.alert_sounds_list);
        list3.setAdapter(adapter);
        setListViewHeightBasedOnChildren(list3);
        list3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pos=position;
                if (pos == 0) {
                    startRingTonePicker();
                } else if (pos == 1) {
                    startRingTonePicker();
                } else if (pos == 2) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        Intent intent = new Intent();
                        String channel="ch";
                        intent.setAction(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                        intent.putExtra(Settings.EXTRA_CHANNEL_ID, channel);
                        intent.putExtra(Settings.EXTRA_APP_PACKAGE, getApplicationContext().getPackageName());
                        getApplicationContext().startActivity(intent);

                    }
                    else{
                        AlertDialog.Builder builder1 = new AlertDialog.Builder(SettingsActivity.this);
                        builder1.setTitle(R.string.version_incompatible);
                        builder1.setIcon(R.drawable.ic_info_black_24dp);
                        builder1.setMessage(R.string.version_incompatible_desc);
                        builder1.setCancelable(true);
                        builder1.setPositiveButton(
                                R.string.ok,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                       dialog.cancel();
                                    }
                                });

                        AlertDialog alert_dialog1 = builder1.create();
                        alert_dialog1.show();
                    }
                }
                else if (pos == 3) {
                    SharedPreferences sharedPref=getSharedPreferences(FileName, Context.MODE_PRIVATE);
                    play_flag=sharedPref.getInt("play_flag",0);
                    if (play_flag==0) {
                        mp.setLooping(true);
                        mp.start();
                        SharedPreferences.Editor editor=sharedPref.edit();
                        editor.putInt("play_flag",1);
                        editor.apply();
                        subtitle1[3]=getString(R.string.tap_to_stop);
                        MyListAdapter2 adapter = new MyListAdapter2(SettingsActivity.this, maintitle1, subtitle1);
                        list3 = findViewById(R.id.alert_sounds_list);
                        list3.setAdapter(adapter);
                    }
                    else if (play_flag==1){
                        mp.pause();
                        SharedPreferences.Editor editor=sharedPref.edit();
                        editor.putInt("play_flag",0);
                        editor.apply();
                        subtitle1[3]=getString(R.string.tap_to_play);
                        MyListAdapter2 adapter = new MyListAdapter2(SettingsActivity.this, maintitle1, subtitle1);
                        list3 = findViewById(R.id.alert_sounds_list);
                        list3.setAdapter(adapter);
                    }
                }
            }
        });

        list4 = findViewById(R.id.reminder_list);
        list4.setAdapter(adapter1);
        setListViewHeightBasedOnChildren(list4);
        list4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(final AdapterView<?> parent, final View view, int position, long id) {
                pos = position;
                if (pos == 0) {

                    SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                    final SharedPreferences.Editor editor = settings.edit();
                    final AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                    builder.setTitle(R.string.choose_reminder_frequency);
                    final String[] reminders = {getString(R.string.daily), getString(R.string.weekly), getString(R.string.monthly), getString(R.string.quarterly), getString(R.string.half_yearly),getString(R.string.yearly),getString(R.string.never)};
                    builder.setItems(reminders, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case 0:
                                    editor.putString("reminder_frequency","Daily");
                                    subtitle2[0]="Daily";
                                    break;
                                case 1:
                                    editor.putString("reminder_frequency","Weekly");
                                    subtitle2[0]="Weekly";
                                    break;
                                case 2:
                                    editor.putString("reminder_frequency","Monthly");
                                    subtitle2[0]="Monthly";
                                    break;
                                case 3:
                                    editor.putString("reminder_frequency","Quarter-yearly");
                                    subtitle2[0]="Quarter-yearly";
                                    break;
                                case 4:
                                    editor.putString("reminder_frequency","Half-yearly");
                                    subtitle2[0]="Half-yearly";
                                    break;
                                case 5:
                                    editor.putString("reminder_frequency","Yearly");
                                    subtitle2[0]="Yearly";
                                    break;
                                case 6:
                                    editor.putString("reminder_frequency","Never");
                                    subtitle2[0]="Never";
                                    break;
                            }

                            editor.apply();
                            list4 = findViewById(R.id.reminder_list);
                            list4.setAdapter(adapter1);
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else if (pos == 1) {

                    SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
                    final SharedPreferences.Editor editor = settings.edit();
                    final Calendar c = Calendar.getInstance();
                    final int mHour = c.get(Calendar.HOUR_OF_DAY);
                    final int mMinute = c.get(Calendar.MINUTE);
                    TimePickerDialog timePickerDialog = new TimePickerDialog(SettingsActivity.this,
                            new TimePickerDialog.OnTimeSetListener() {

                                @Override
                                public void onTimeSet(TimePicker view, int hourOfDay,
                                                      int minute) {
                                    String format;
                                    int hourOfDay1=hourOfDay;
                                    if (hourOfDay == 0) {
                                        hourOfDay += 12;
                                        format = "AM";
                                    } else if (hourOfDay == 12) {
                                        format = "PM";
                                    } else if (hourOfDay > 12) {
                                        hourOfDay -= 12;
                                        format = "PM";
                                    } else {
                                        format = "AM";
                                    }
                                    String time=hourOfDay+":"+minute+" "+format;
                                    String time1=hourOfDay1+"."+minute;
                                    editor.putString("reminder_time",time);
                                    editor.putString("reminder_time1",time1);
                                    if ((time.substring(time.indexOf(":"),time.indexOf(" "))).length()==3){
                                        show_time=time;
                                    }
                                    else{
                                        show_time=time.substring(0,time.indexOf(":")+1)+"0"+time.substring(time.indexOf(":")+1,time.length());
                                    }
                                    subtitle2[1]=show_time;
                                    editor.putString("show_time",show_time);
                                    editor.apply();
                                    list4 = findViewById(R.id.reminder_list);
                                    list4.setAdapter(adapter1);
                                }

                            }, mHour, mMinute, false);
                    timePickerDialog.show();

                }
            }});
        list4 = findViewById(R.id.reminder_list);
        list4.setAdapter(adapter1);
    }
   private void startRingTonePicker(){
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        startActivityForResult(intent, RQS_RINGTONEPICKER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == RQS_RINGTONEPICKER && resultCode == RESULT_OK){
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            ringTone = RingtoneManager.getRingtone(getApplicationContext(), uri);
            ringtone_title=ringTone.getTitle(SettingsActivity.this);

            if (pos==0)subtitle1[0]=ringtone_title;
            else if (pos==1)subtitle1[1]=ringtone_title;

            SharedPreferences settings = getSharedPreferences(FileName, MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            if (pos==0) {
                editor.putString("ringtone1", String.valueOf(uri));
                editor.putString("alert_sound1", ringtone_title);
            }
            if (pos==1){
                editor.putString("ringtone2", uri.toString());
                editor.putString("alert_sound2", ringtone_title);
            }

            editor.apply();
            MyListAdapter2 adapter = new MyListAdapter2(this, maintitle1, subtitle1);
            list3 = findViewById(R.id.alert_sounds_list);
            list3.setAdapter(adapter);
        }
    }

    public void get_alert_values(){
        SharedPreferences sharedPref=getSharedPreferences(FileName, Context.MODE_PRIVATE);
        String alarm_ringtone=getString(R.string.default_alarm_ringtone);
        if (RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)==null) alarm_ringtone=getString(R.string.default_ringtone);
        name1=sharedPref.getString("alert_sound1",alarm_ringtone);
        name2=sharedPref.getString("alert_sound2",getString(R.string.safety_alert_ringtone));
        name3=sharedPref.getString("alert_sound3",getString(R.string.default_notification_ringtone));
        name5=sharedPref.getString("reminder_frequency",getString(R.string.monthly));
        name6=sharedPref.getString("reminder_time","7.00 PM");
        name7=sharedPref.getString("show_time","7.00 PM");
        deactivation_time=sharedPref.getString("deactivation_time","10 seconds");
        deactivation_time_seconds=sharedPref.getString("deactivation_time_seconds","10000");
    }

    @Override
    public void onRestart(){
        super.onRestart();
        get_alert_values();
        MyListAdapter2 adapter = new MyListAdapter2(this, maintitle1, subtitle1);
        list3 = findViewById(R.id.alert_sounds_list);
        list3.setAdapter(adapter);
    }

    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null)
            return;

        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
        int totalHeight = 0;
        View view = null;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            view = listAdapter.getView(i, view, listView);
            if (i == 0)
                view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT));

            view.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += view.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }
}
