package com.siriussoftwares.safety;



import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


public class DisasterAlert extends AppCompatActivity {

    ListView list5;
    String FileName="data";
    String[] maintitle,subtitle;
    String title,message,numbers,num1,id1,num2,id2,num3,id3,num4,id4,num5,id5,fire,fire_title;
    int pos;
    MediaPlayer mp;
    TextView disaster_tv1,disaster_tv2;
    LinearLayout disaster_alert_layout1;
    LinearLayout disaster_alert_layout2;
    Button disaster_safety_tips,ignore_alert_btn,inform_contacts,disaster_tips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disaster_alert);

        get_alert_values();

        disaster_safety_tips=findViewById(R.id.disaster_safety_tips);
        disaster_safety_tips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences settings = getSharedPreferences("data", MODE_PRIVATE);
                final SharedPreferences.Editor editor = settings.edit();
                final AlertDialog.Builder builder = new AlertDialog.Builder(DisasterAlert.this);
                builder.setTitle(R.string.select_disaster);
                final String[] reminders = {getString(R.string.blizzard), getString(R.string.cold_waves), getString(R.string.cyclonic_storm), getString(R.string.earthquake), getString(R.string.epidemic),getString(R.string.flood),getString(R.string.hail),getString(R.string.heat_waves),getString(R.string.ice_storm),getString(R.string.landslide),getString(R.string.limnic),getString(R.string.nuclear),getString(R.string.thunderstorm),getString(R.string.tsunami),getString(R.string.volcanic),getString(R.string.wildfire)};
                builder.setItems(reminders, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                editor.putString("disaster_safety_tips","Blizzard");
                                break;
                            case 1:
                                editor.putString("disaster_safety_tips","Cold Waves");
                                break;
                            case 2:
                                editor.putString("disaster_safety_tips","Cyclonic Storm");
                                break;
                            case 3:
                                editor.putString("disaster_safety_tips","Earthquake");
                                break;
                            case 4:
                                editor.putString("disaster_safety_tips","Epidemic Hazard");
                                break;
                            case 5:
                                editor.putString("disaster_safety_tips","Flood");
                                break;
                            case 6:
                                editor.putString("disaster_safety_tips","Hail Storm");
                                break;
                            case 7:
                                editor.putString("disaster_safety_tips","Heat Waves");
                                break;
                            case 8:
                                editor.putString("disaster_safety_tips","Ice Storm");
                                break;
                            case 9:
                                editor.putString("disaster_safety_tips","Landslide");
                                break;
                            case 10:
                                editor.putString("disaster_safety_tips","Limnic Eruption");
                                break;
                            case 11:
                                editor.putString("disaster_safety_tips","Nuclear Explosion");
                                break;
                            case 12:
                                editor.putString("disaster_safety_tips","Thunderstorm");
                                break;
                            case 13:
                                editor.putString("disaster_safety_tips","Tsunami");
                                break;
                            case 14:
                                editor.putString("disaster_safety_tips","Volcanic Eruption");
                                break;
                            case 15:
                                editor.putString("disaster_safety_tips","Wildfire");
                                break;
                        }
                        Intent myIntent = new Intent(DisasterAlert.this, DisasterTips.class);
                        startActivity(myIntent);
                        editor.apply();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        disaster_tips=findViewById(R.id.disaster_tips);
        disaster_tips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(DisasterAlert.this, DisasterTips.class);
                startActivity(myIntent);
            }
        });

        if (fire.equals("")){
            fire_title=getString(R.string.no_contacts_available);
        }
        else{
            fire_title=getString(R.string.fire_and_rescue);
        }
        disaster_alert_layout1 = findViewById(R.id.disaster_alert_layout1);
        disaster_alert_layout2 = findViewById(R.id.disaster_alert_layout2);

        disaster_tv1 = findViewById(R.id.disaster_tv1);
        disaster_tv2 = findViewById(R.id.disaster_tv2);
        disaster_tv1.setText(title);
        disaster_tv2.setText(message);
        if (!fire.equals("")) {
            switch (numbers) {
                case "0":
                    maintitle = new String[]{getString(R.string.fire_and_rescue)};
                    subtitle = new String[]{fire};
                    break;
                case "1":
                    maintitle = new String[]{getString(R.string.fire_and_rescue), id1};
                    subtitle = new String[]{fire, num1};
                    break;
                case "2":
                    maintitle = new String[]{getString(R.string.fire_and_rescue), id1, id2};
                    subtitle = new String[]{fire, num1, num2};
                    break;
                case "3":
                    maintitle = new String[]{getString(R.string.fire_and_rescue), id1, id2, id3};
                    subtitle = new String[]{fire, num1, num2, num3};
                    break;
                case "4":
                    maintitle = new String[]{getString(R.string.fire_and_rescue), id1, id2, id3, id4};
                    subtitle = new String[]{fire, num1, num2, num3, num4};
                    break;
                case "5":
                    maintitle = new String[]{getString(R.string.fire_and_rescue), id1, id2, id3, id4, id5};
                    subtitle = new String[]{fire, num1, num2, num3, num4, num5};
                    break;
            }
        }
        else if (fire.equals("") && numbers.equals("0")){
            maintitle = new String[]{getString(R.string.not_available)};
            subtitle = new String[]{fire};
        }
        else if (fire.equals("") && !numbers.equals("0")){
            switch (numbers) {
                case "1":
                    maintitle = new String[]{id1};
                    subtitle = new String[]{num1};
                    break;
                case "2":
                    maintitle = new String[]{id1, id2};
                    subtitle = new String[]{num1, num2};
                    break;
                case "3":
                    maintitle = new String[]{id1, id2, id3};
                    subtitle = new String[]{num1, num2, num3};
                    break;
                case "4":
                    maintitle = new String[]{id1, id2, id3, id4};
                    subtitle = new String[]{num1, num2, num3, num4};
                    break;
                case "5":
                    maintitle = new String[]{id1, id2, id3, id4, id5};
                    subtitle = new String[]{num1, num2, num3, num4, num5};
                    break;
            }
        }
        MyListAdapter4 adapter = null;
        if (title.equals("")) {
            disaster_alert_layout1.setVisibility(View.VISIBLE);
            disaster_alert_layout2.setVisibility(View.GONE);
        } else {
            disaster_alert_layout1.setVisibility(View.GONE);
            adapter = new MyListAdapter4(this, maintitle, subtitle);
            disaster_alert_layout2.setVisibility(View.VISIBLE);
        }


        list5 = findViewById(R.id.disaster_contacts);
        list5.setAdapter(adapter);
        setListViewHeightBasedOnChildren(list5);
        list5.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pos = position;
                if (fire.equals(""))pos=pos+1;
                if (pos == 0) {
                    if (!fire.equals(""))call(fire);
                } else if (pos == 1) {
                    if (!num1.equals(""))call(num1);
                } else if (pos == 2) {
                    call(num2);
                } else if (pos == 3) {
                    call(num3);
                } else if (pos == 4) {
                    call(num4);
                } else if (pos == 5) {
                    call(num5);
                }
            }
        });

        ignore_alert_btn = findViewById(R.id.ignore_alert_btn);
        ignore_alert_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disaster_alert_layout2.setVisibility(View.GONE);
                disaster_alert_layout1.setVisibility(View.VISIBLE);
                SharedPreferences sharedPref=getSharedPreferences(FileName,MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPref.edit();
                editor.putString("notification_title",null);
                editor.apply();
            }
        });

        inform_contacts = findViewById(R.id.inform_contacts);
        inform_contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(DisasterAlert.this, DisasterInform.class);
                DisasterAlert.this.startActivity(myIntent);
            }
        });


    }
    public void get_alert_values(){
        SharedPreferences sharedPref=getSharedPreferences(FileName, Context.MODE_PRIVATE);
        title=sharedPref.getString("notification_title","");
        message=sharedPref.getString("notification_message","");
        numbers=sharedPref.getString("disaster_numbers","");
        num1=sharedPref.getString("disaster_1","");
        num2=sharedPref.getString("disaster_2","");
        num3=sharedPref.getString("disaster_3","");
        num4=sharedPref.getString("disaster_4","");
        num5=sharedPref.getString("disaster_5","");
        id1=sharedPref.getString("disaster_i1","");
        id2=sharedPref.getString("disaster_i2","");
        id3=sharedPref.getString("disaster_i3","");
        id4=sharedPref.getString("disaster_i4","");
        id5=sharedPref.getString("disaster_i5","");
        fire = sharedPref.getString("fire", "");
    }
    public void call(String phone) {
        String uri = "tel:" + phone;
        Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(uri));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        startActivity(callIntent);
    }
    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null)
            return;

        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
        int totalHeight = 0;
        View view = null;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            view = listAdapter.getView(i, view, listView);
            if (i == 0)
                view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT));

            view.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += view.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }
}
